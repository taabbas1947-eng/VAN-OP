/* VAN Ops v2 — shared UI primitives (consumed by all screens). */
const { useState, useEffect } = React;
const cx = (...a) => a.filter(Boolean).join(' ');
const fmt = n => (typeof n === 'number' ? n.toLocaleString('en-US') : n);

const TONE = { teal:'p-teal', blue:'p-blue', amber:'p-amber', red:'p-red', grey:'p-grey', done:'p-done', navy:'p-navy', green:'p-green' };
const Pill = ({ tone='grey', children }) => <span className={cx('pill', TONE[tone]||'p-grey')}>{children}</span>;

const RISK = {
  late:   { t:'red',   l:'Late' },
  rm:     { t:'amber', l:'RM-blocked' },
  watch:  { t:'amber', l:'Watch' },
  ontrack:{ t:'teal',  l:'On-track' },
  done:   { t:'done',  l:'Closed ✓' },
};
const RiskPill = ({ risk }) => { const r = RISK[risk]||RISK.ontrack; return <Pill tone={r.t}>{r.l}</Pill>; };

const Bar = ({ pct, tone }) => (
  <div className={cx('bar', tone)}><span style={{ width: Math.max(0, Math.min(100, pct)) + '%' }} /></div>
);

const Kpi = ({ eyebrow, val, unit, foot, delta, dir }) => (
  <div className="kpi">
    <div className="keyebrow">{eyebrow}</div>
    <div className="kval">{val}{unit && <span className="u">{unit}</span>}</div>
    <div className="kfoot">
      {delta && <span className={cx('delta', dir)}>{dir==='up'?'▲':dir==='down'?'▼':''} {delta}</span>}
      <span>{foot}</span>
    </div>
  </div>
);

const SectionTitle = ({ children, count }) => (
  <div className="sectit"><h2>{children}</h2><div className="sl" />{count!=null && <span className="sc">{count}</span>}</div>
);

const Card = ({ title, hint, rule, pad=true, children, foot }) => (
  <div className="card">
    {title && <div className="card-head"><h3>{title}</h3>{hint && <span className="hint">{hint}</span>}</div>}
    <div className={pad ? 'card-pad' : ''}>{children}</div>
    {foot}
  </div>
);

/* Pipeline stepper — stage index 1..7 (1-based on STAGES) */
const Stepper = ({ stage }) => (
  <div className="stepper">
    {window.STAGES.map((s, i) => {
      const n = i + 1, st = n < stage ? 'done' : n === stage ? 'curr' : '';
      return (
        <div key={s} className={cx('step', st)}>
          <div className="sdot2">{n < stage ? <Ic name="check" size={12} /> : n}</div>
          <div className="stxt"><div className="sn">{s}</div>
            <div className="ss">{n < stage ? 'done' : n === stage ? 'in progress' : 'waiting'}</div></div>
        </div>
      );
    })}
  </div>
);

const StageRail = ({ stages, active, onPick }) => (
  <div className="stagerail">
    {stages.map(s => (
      <button key={s.id} className={cx('stage-pill', active===s.id && 'on')} onClick={() => onPick(s.id)}>
        <span className="sp-n">{s.label}</span><span className="sp-v mono">{s.n}</span>
      </button>
    ))}
  </div>
);

const Drawer = ({ title, eyebrow, onClose, children, footer }) => {
  useEffect(() => {
    const k = e => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, []);
  return (<>
    <div className="scrim" onClick={onClose} />
    <aside className="drawer">
      <div className="drawer-h">
        <div>{eyebrow && <div className="tb-crumb">{eyebrow}</div>}<h2>{title}</h2></div>
        <button className="x" onClick={onClose}><Ic name="x" size={16} /></button>
      </div>
      <div className="drawer-b">{children}</div>
      {footer && <div className="drawer-f">{footer}</div>}
    </aside>
  </>);
};

const Toast = ({ msg, onDone }) => {
  useEffect(() => { const t = setTimeout(onDone, 2200); return () => clearTimeout(t); }, [msg]);
  return <div className="toast"><span className="ic"><Ic name="check" size={16} /></span>{msg}</div>;
};

const Empty = ({ icon='check', children }) => (
  <div style={{ textAlign:'center', padding:'40px 20px', color:'var(--ink-3)' }}>
    <div style={{ width:46, height:46, borderRadius:12, background:'var(--teal-50)', color:'var(--teal)',
      display:'grid', placeItems:'center', margin:'0 auto 12px' }}><Ic name={icon} size={22} /></div>
    <div style={{ fontSize:13 }}>{children}</div>
  </div>
);

/* ---- Stage color-flow (PO Tracker) ---- */
const STAGE_COLORS = ['var(--st-po)','var(--st-rm)','var(--st-prod)','var(--st-lab)','var(--st-qa)','var(--st-ship)','var(--st-deliv)'];
const stageColor = idx => STAGE_COLORS[Math.max(0, Math.min(STAGE_COLORS.length-1, idx))];
const StageChip = ({ stage }) => {
  const idx = window.STAGES.indexOf(stage);
  return <span className="stchip" style={{ '--sc': stageColor(idx) }}><span className="sd" />{stage}</span>;
};
const StageFlow = ({ stageIdx, label }) => (
  <div style={{ display:'flex', alignItems:'center' }}>
    <div className="flow">
      {window.STAGES.map((s,i) => (
        <span key={s} className="fseg" title={s}
          style={{ background: i<=stageIdx-1 ? stageColor(i) : 'var(--line-2)', opacity: i===stageIdx-1?1:(i<stageIdx-1?.85:1) }} />
      ))}
    </div>
    {label && <span className="flbl">{label}</span>}
  </div>
);

Object.assign(window, { cx, fmt, Pill, RiskPill, Bar, Kpi, SectionTitle, Card, Stepper, StageRail, Drawer, Toast, Empty, STAGE_COLORS, stageColor, StageChip, StageFlow });
