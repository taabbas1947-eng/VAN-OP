/* VAN Ops v2 — PO Tracker. Risk strip · stage rail · Matrix/List/Board · drawer. */
function ScreenTracker({ openDrawer, focusPo, clearFocus }) {
  const [view, setView] = useState('matrix');
  const [stage, setStage] = useState('all');
  const [channel, setChannel] = useState('all');
  const orders = window.ORDERS, STAGES = window.STAGES;

  useEffect(() => { if (focusPo) { setView('matrix'); } }, [focusPo]);

  const railStages = [{ id:'all', label:'All', n:orders.length },
    ...STAGES.map((s,i) => ({ id:String(i+1), label:s, n:orders.filter(o=>o.stage===i+1).length }))];
  const channels = ['all', ...new Set(orders.map(o=>o.channel))];

  let rows = orders.filter(o => (stage==='all'||o.stage===+stage) && (channel==='all'||o.channel===channel));
  if (focusPo) rows = orders.filter(o => o.po===focusPo);

  const openPOs = orders.filter(o=>o.risk!=='done').length;
  const atRisk = orders.filter(o=>o.risk==='late'||o.risk==='rm').length;
  const rmBlocked = orders.filter(o=>o.risk==='rm').length;
  const kgLeft = orders.reduce((s,o)=>s+(o.remaining||0),0);

  const riskRow = o => o.risk==='late'?'row-risk':o.risk==='rm'||o.risk==='watch'?'row-warn':'';

  return (
    <div className="well">
      {/* risk strip */}
      <div className="grid g-kpi" style={{ marginBottom:16 }}>
        <Kpi eyebrow="Open POs" val={openPOs} foot="active orders" />
        <Kpi eyebrow="At risk" val={atRisk} unit=" POs" foot="late or RM-blocked" delta={String(rmBlocked)} dir="down" />
        <Kpi eyebrow="RM-blocked" val={rmBlocked} unit=" POs" foot="awaiting receipt" />
        <Kpi eyebrow="KG remaining" val={(kgLeft/1000).toFixed(0)+'k'} unit=" KG" foot="undelivered balance" />
      </div>

      <StageRail stages={railStages} active={stage} onPick={s=>{ setStage(s); clearFocus&&clearFocus(); }} />

      {/* controls */}
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:14, flexWrap:'wrap' }}>
        {focusPo && <button className="chip on" onClick={clearFocus}>PO {focusPo} <Ic name="x" size={12} /></button>}
        <select className="inp" style={{ width:'auto', minWidth:150 }} value={channel} onChange={e=>setChannel(e.target.value)}>
          {channels.map(c => <option key={c} value={c}>{c==='all'?'All channels':c}</option>)}
        </select>
        <div className="tb-spacer" />
        <span className="mono" style={{ fontSize:11, color:'var(--ink-3)' }}>{rows.length} of {orders.length} · stage = blocking</span>
        <div className="seg">
          {[['matrix','columns','Matrix'],['list','list','List'],['board','grid','Board']].map(([k,ic,l]) => (
            <button key={k} className={cx(view===k && 'on')} onClick={()=>setView(k)}><Ic name={ic} size={13} /> {l}</button>
          ))}
        </div>
      </div>

      {view==='matrix' && (
        <div className="card" style={{ overflow:'hidden' }}>
          <div className="tbl-wrap">
          <table className="tbl">
            <thead><tr>
              <th>PO</th><th>Customer</th><th>Channel</th><th>Stage</th>
              <th className="r">Prod%</th><th className="r">Pack%</th><th className="r">Del%</th>
              <th className="r">Remaining</th><th>Owner</th><th>Next</th><th>Promise</th><th>Risk</th>
            </tr></thead>
            <tbody>
              {rows.map(o => (
                <tr key={o.po} className={cx('clk', riskRow(o))} onClick={()=>openDrawer(o)}>
                  <td className="mono lead">{o.po}</td>
                  <td>{o.client}</td>
                  <td><span className="tag">{o.channel}</span></td>
                  <td><StageChip stage={STAGES[o.stage-1]} /></td>
                  <td className="r mono">{o.prod}%</td><td className="r mono">{o.pack}%</td><td className="r mono">{o.del}%</td>
                  <td className="r mono">{fmt(o.remaining)} {o.unit}</td>
                  <td style={{ color:'var(--ink-2)' }}>{o.owner}</td>
                  <td style={{ color:'var(--ink-2)' }}>{o.next}</td>
                  <td className="mono">{o.promise}</td>
                  <td><RiskPill risk={o.risk} /></td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {view==='list' && (<>
        <div className="flowleg" style={{ display:'flex', alignItems:'center', gap:14, flexWrap:'wrap', marginBottom:12, fontSize:11, color:'var(--ink-2)' }}>
          <span className="mono" style={{ fontSize:9.5, letterSpacing:'.1em', textTransform:'uppercase', color:'var(--ink-3)' }}>Flow</span>
          {STAGES.map((s,i) => (
            <span key={s} style={{ display:'flex', alignItems:'center', gap:6 }}>
              <span style={{ width:9, height:9, borderRadius:3, background:stageColor(i) }} />{s}</span>
          ))}
        </div>
        <div className="grid" style={{ gap:7 }}>
          {rows.map(o => (
            <div key={o.po} className="trow" style={{ '--sc': stageColor(o.stage-1) }} onClick={()=>openDrawer(o)}>
              <div style={{ minWidth:0, width:248, flex:'none' }}>
                <div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{o.po} · {o.channel}</div>
                <div style={{ fontWeight:600, fontSize:13, marginTop:1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{o.client}</div>
                <div style={{ fontSize:11, color:'var(--ink-2)', marginTop:1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{o.product}</div>
              </div>
              <div style={{ flex:1, minWidth:120 }}>
                <StageFlow stageIdx={o.stage} label={STAGES[o.stage-1]} />
                <div style={{ fontSize:11, color:'var(--ink-3)', marginTop:5, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{o.next} · {o.owner}</div>
              </div>
              <div style={{ width:150, flex:'none' }}>
                <div style={{ display:'flex', justifyContent:'space-between', fontSize:10.5, color:'var(--ink-2)', marginBottom:4 }}>
                  <span>{fmt(o.remaining)} {o.unit} left</span><span className="mono">{o.del}%</span></div>
                <Bar pct={o.del} tone={o.del===0?'grey':''} />
              </div>
              <div style={{ textAlign:'right', width:96, flex:'none' }}>
                <RiskPill risk={o.risk} />
                <div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)', marginTop:4 }}>{o.promise}</div>
              </div>
            </div>
          ))}
        </div>
      </>)}

      {view==='board' && (
        <div className="lanes" style={{ gridTemplateColumns:'repeat(7,minmax(180px,1fr))', overflowX:'auto' }}>
          {STAGES.map((s,i) => {
            const list = rows.filter(o=>o.stage===i+1);
            return (
              <div className="lane" key={s} style={{ borderTop:'2px solid '+stageColor(i) }}>
                <div className="lane-h"><span className="sdot" style={{ background:stageColor(i) }} /><span className="ln" style={{ fontSize:11.5 }}>{s}</span><span className="lc mono">{list.length}</span></div>
                {list.map(o => (
                  <div key={o.po} className="bcard" onClick={()=>openDrawer(o)} style={{ borderLeft: o.risk==='late'?'3px solid var(--red)':o.risk==='rm'||o.risk==='watch'?'3px solid var(--amber)':'' }}>
                    <div className="bc-h"><span className="bc-b mono">{o.po}</span><RiskPill risk={o.risk} /></div>
                    <div className="bc-p">{o.product}</div>
                    <div style={{ fontSize:11, color:'var(--ink-2)' }}>{o.client}</div>
                    <div className="bc-f"><span>{fmt(o.remaining)} {o.unit}</span><span className="mono">{o.promise}</span></div>
                  </div>
                ))}
                {list.length===0 && <div style={{ fontSize:11, color:'var(--ink-3)', padding:'6px 5px' }}>—</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function OrderDrawer({ o, onClose }) {
  return (
    <Drawer eyebrow={o.po+' · '+o.channel} title={o.client} onClose={onClose}
      footer={<button className="btn btn-pri" style={{ flex:1, justifyContent:'center' }} onClick={onClose}>Open full PO <Ic name="arrow" size={14} /></button>}>
      <div style={{ display:'flex', gap:8, marginBottom:16 }}><RiskPill risk={o.risk} /><Pill tone="grey">{o.product}</Pill></div>
      <div className="kv" style={{ marginBottom:20 }}>
        <dt>Stage</dt><dd>{window.STAGES[o.stage-1]}</dd>
        <dt>Channel</dt><dd>{o.channel}</dd>
        <dt>KAM</dt><dd>{o.kam}</dd>
        <dt>Owner</dt><dd>{o.owner}</dd>
        <dt>Promise</dt><dd className="mono">{o.promise}</dd>
        <dt>Next</dt><dd>{o.next}</dd>
        <dt>Ordered</dt><dd className="mono">{fmt(o.qty)} {o.unit}</dd>
        <dt>Remaining</dt><dd className="mono">{fmt(o.remaining)} {o.unit}</dd>
      </div>
      {[['Produced',o.prod,''],['Packed',o.pack,'blue'],['Delivered',o.del,'grey']].map(([l,v,t]) => (
        <div key={l} style={{ marginBottom:13 }}>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:5 }}><span style={{ color:'var(--ink-2)' }}>{l}</span><span className="mono" style={{ fontWeight:600 }}>{v}%</span></div>
          <Bar pct={v} tone={v===0?'grey':t} />
        </div>
      ))}
      <div className="banner teal" style={{ marginTop:18 }}><span className="ic"><Ic name="info" size={16} /></span>
        <span>View-only. Updates are entered from {o.owner}'s own screen.</span></div>
    </Drawer>
  );
}
window.ScreenTracker = ScreenTracker; window.OrderDrawer = OrderDrawer;
