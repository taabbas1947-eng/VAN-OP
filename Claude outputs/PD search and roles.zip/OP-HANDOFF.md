# VAN Order Control Tower — OP Handoff

> **STATUS ADD — 2026-09-01 (cloud session, later same day): PD · §B RULINGS (B8/B19/C1/C2/C5), THE PROTOTYPE, AND B5/B9–B12 DRAFTS. STILL NO SCHEMA CODE. NOT PUSHED.**
>
> **Module worked in: PD.** Docs only — `pd/` untouched. Files changed this round: `docs/pd-model/PENDING-DECISIONS.md`, `docs/pd-model/MODEL.md` §5, `docs/pd-model/REUSE-RULES.md` §5, `docs/pd-model/combination-bank/RULES.md` (§2, §4.1, §4.2, §7.1, §9, §11), new file `docs/pd-model/PILOT-001-fermentation-source.md`. `OP-HANDOFF.md` (this entry).
>
> **Rulings this round (Tahir):**
> - **B8** — Problem dossier is its own screen, browsable across every Problem. This is the explicit sign-off `REUSE-RULES.md` §5 requires for a 3rd screen.
> - **B19** — a leadership/portfolio Report view, needed now, not deferred. 4th screen, sign-off given. Aggregate-only KPI tiles + needs-attention feed + recently-closed feed — **never a per-person breakdown**, same guardrail as `RECLASSIFICATION-RULES.md`.
> - **C1** — `Sulfur` is the correct spelling; `Sulphur` entries are the same substance, merge.
> - **C2** — MAP is 4 grades (12-61, 10-61, 10-52, 11-44); DAP is 1 grade (18-46).
> - **C5** — evidence base is "light native + link": a real lightweight Claim lives in PD; deep source material (e.g. `E:\NP`) stays where it is, pointed to, not duplicated.
> - **Engine-first, Claims are memory — not a gatekeeper**, and the **backfill principle** (retrospective-only, invited only on an actively reopened Problem) both recorded in `PENDING-DECISIONS.md` §D, tested against the bio-boiler fly-ash MOP-recovery case Tahir reopened this session.
>
> **A clickable prototype was built** (Cowork artifact, not committed to this repo — throwaway HTML/JS, not a schema). It went through real critique and rebuild, not just one pass: renamed "Leadership Report" to "Report"; added a Source/reference field on Bet and Claim so a document, folder or paper attaches as a pointer, matching C5; fixed the Combination Engine's candidate scoring, which had been showing a ₨/kg cost figure — a direct contradiction of the settled A3 ruling (cost is out of PD) — now scored on mass-balance/design-space fit only. Then, in response to "this app is still a data entry app": built the three doors (Challenge/Observation/Request) into "What came in" as real intake objects with owner, status and a triage action — previously the prototype only let people log Problems directly, which was the actual substance behind "no direction, no visibility, no clarity of who's asking, who's replying"; made the Combination Engine the front door for placing a Bet instead of a buried toggle; added a Related-from-Dossier panel that surfaces matching past Claims automatically on the Question screen.
>
> **B5, the paper pilot, is started, not finished.** `PILOT-001-fermentation-source.md` writes down the fermentation-source Question, both hypotheses (molasses / amino acids), and both kill criteria — transcribed from Himmayat's own words in `WORKED-CASE-V-GERMINATOR-PRO.md` §4.1, nothing invented. Waiting on Himmayat to correct it and write the next real observation directly into the file. **Still the cheapest, most overdue move on the whole page** — writing it down is not the same as running it.
>
> **B9–B12 vocabularies drafted into `combination-bank/RULES.md`**, not ruled on by Tahir: technique (§4.1, seven values, now a 6th duplicate-check signal at §7.1), material role + phase (§4.2), mechanism/intent (§9.1), and the sentence-answer search spec with the honest-negative and ours-vs-the-world's rules (§9.2). All drafted directly from Maleeha's own session language (recorded in `PENDING-DECISIONS.md` B9–B12), not invented from nothing — but explicitly flagged as unconfirmed, same status as the crop/soil/problem vocabularies (B4). Also caught and fixed in the same pass: `combination-bank/RULES.md` §2 still read the tenth-object question as open after A2 had already settled it — corrected so the two documents cannot be read as disagreeing.
>
> **Documentation debt closed this round:** `MODEL.md` §5 rewritten from "TWO screens" to the actual four, with both sign-offs cited; `REUSE-RULES.md` §5's drift table now shows the actual screen count (4) against the target (2) rather than silently going stale.
>
> **Not done:** no schema, no code against the real app, B2/B3/B4 (real material list, assays, controlled vocabularies) still entirely owed by Tahir, B9–B12 vocabularies still need his confirmation, B13's reclassification capability (fully designed, `RECLASSIFICATION-RULES.md`) has no representation anywhere in the prototype, B14/B16/B17/B18 (Run lineage, cross-product material signal, Claims writable directly against a Problem, Observations arising inside a Run) remain designed-but-unbuilt requirements from the worked case, not yet touched this session.


> **STATUS ADD — 2026-09-01 (cloud session, latest): PD · THE FOUR SCHEMA-BLOCKING DECISIONS (§A) — ALL RULED. NO CODE. NOT PUSHED.**
>
> **Module worked in: PD.** Docs only — `pd/` untouched (no schema, no route, no migration). Files changed: `docs/pd-model/PENDING-DECISIONS.md` (A1–A4 moved to §D, dated), `docs/pd-model/MODEL.md` §3/§4/§7, `docs/pd-model/REUSE-RULES.md` §2 whitelist + §1, `CLAUDE.md` §2. `OP-HANDOFF.md` (this entry).
>
> **The four rulings (Tahir, 1 Sept 2026):**
> 1. **Gates — reduced to the two hard rules** in `MODEL.md` §0 (write the question before work starts, write the result before it closes). No G1–G6 committee/gate machinery in the rebuild.
> 2. **Combination Bank is a register beneath Bet/Run**, not a tenth object. The nine-object model is unchanged.
> 3. **Cost is OUT of PD.** Ground-rule 0 applies platform-wide, no PD exception. The candidate cost engine (`pd/pd-lib.js:188–232`, ex-works cost, ranked by rupees/kg P₂O₅) does **not** carry into the rebuild — removed from the `REUSE-RULES.md` §2 whitelist (was item #1).
> 4. **Concept-first is allowed, not just Problem-first.** A stated product concept ("100% nutrition with Fe and Mn") is a valid starting point without a fabricated Problem on top. **Not yet designed:** the concrete mechanism — a lightweight concept object, or a Bet/Question with a null Problem parent. Flagged as a new open item; do not schema `Question —belongs_to→ Problem` until it lands.
>
> **§A of `PENDING-DECISIONS.md` is now fully answered.** Schema work may proceed except where a §B item bears directly on it (read §B first, same rule as always) — and except A4's mechanism, which is real design work still outstanding despite the principle being settled.
>
> **Not done this session:** no schema written, no pilot run (§B5 — the paper pilot, e.g. the V Germinator Pro fermentation question — is still the flagged cheapest next move and is untouched), A4's mechanism undesigned.

> **ADD — same session, later:** A4's mechanism also ruled. **Recommended and accepted:** broaden Problem itself with a `kind` flag (`field_problem` | `product_concept`) rather than add a tenth object or a nullable Problem parent with an inline text field. A concept keeps Problem's shape — few, long-lived, the single parent every Question/Bet/Run hangs off — which is what the V Germinator Pro case actually needed (one concept, three chained formulations, months of Runs, `WORKED-CASE-V-GERMINATOR-PRO.md` §1). Registering a Problem of either kind is a direct action, not a fourth door — the three doors (Challenge/Observation/Request) are unchanged. Object count stays at nine. `MODEL.md` §3/§4/§7 and `PENDING-DECISIONS.md` §A4/§D updated. **A4 is now fully schema-ready — the last open item in §A is closed.** Still open and still the flagged cheapest next move: §B5, the paper pilot.


> **STATUS ADD — 2026-08-18 (cloud session, latest): PD · COMBINATION BANK — DESIGN AGREED AND WRITTEN DOWN. NO CODE. NOT PUSHED.**
>
> **Module worked in: PD.** Nothing under `pd/` was opened for edit. No schema, no route, no migration. `server.js`, `o2s/`, `launcher.html` untouched.
>
> **What this was.** Tahir asked for a searchable place to dump every combination anyone has ever thought of — tagged by the problem it answers and what it was thought up against — so nobody walks the same dead end twice ("like we did in case of NP"). The whole session was design, driven by Tahir's decisions one at a time. Six demo iterations were built and reviewed; only v6 was kept.
>
> **Where it lives:** `docs/pd-model/combination-bank/` — `RULES.md` (the rules, in words, not code — it wins over any code that disagrees), `README.md`, and `combination-bank-demo-v6.html` (standalone, opens in a browser, wired to nothing). **Read `RULES.md` before writing a line of this.**
>
> **The decisions, in brief:** composition is **one row per material**, never free text · the material register is held at **grade** level (MAP 11-52 is not MAP 10-50), **supplier is not part of grade identity** · **only moderators add materials**, but nobody is ever blocked — request it and the row saves flagged · every material carries a **"grade not yet decided"** placeholder · **analysis is computed by mass balance, never typed** · entry is a form or a template file, **free paste removed** (both file shapes accepted) · duplicates: **hard stop only on clear evidence** (same grades, same inclusions ±0.5%, same form, same route, **same problem**, and both records fully graded), everything else **saves flagged pending review and stays searchable** · moderator group is **configurable**, unactioned items **escalate into My Work after 3 days, never auto-accept** · **nothing is ever deleted**.
>
> **Data reality check (RULES.md §10):** the 51 raw materials read from `data/state.json` are real and were read verbatim, spellings included. Their assays **do not exist anywhere** — Tahir is supplying them. Every other grade in the demo is **invented by Claude and marked as such**. Tahir's instruction: leave them in place, he will say which grades and materials to add. The bank starts **empty** — the 46 real recipes in O2S masters are deliberately not loaded.
>
> **Two findings in the real master needing Tahir's word:** `Sulfur` and `Sulphur` both exist as separate substances, so recipes using one will never match recipes using the other; and `MAP` / `DAP` are listed with **no grade at all**.
>
> **Housekeeping:** `docs/pd-audit/README.md` was **replaced** and the original moved to `_to_delete/README-pd-audit-SUPERSEDED-2026-08-18.md` — it instructed the `.patch` / `git apply` workflow that `CLAUDE.md` §3.1 now forbids, pointed at four `.patch` files that no longer exist in the repo, and stated a branch status contradicting `CLAUDE.md` §3. No finding or document was lost; only the dead instructions. Three other docs that mention patches were **deliberately kept** — reasons in `_to_delete/WHY-THESE-ARE-HERE.md`.
>
> **OPEN — blocks the schema:** is a Combination a **tenth object**, or a register beneath Bet/Run? `MODEL.md` §3 fixes the model at nine without Tahir's sign-off. Also open: the real material/grade list, the assays, the controlled vocabularies (crops/soils/problems — all invented today), and the similarity weights (Claude's, untested against real data). Full list: `RULES.md` §11.
>
> **Pushed?** No. Files are in the working tree for Tahir to commit via GitHub Desktop. Changed: `docs/pd-audit/README.md` (modified), `docs/pd-model/` (new, untracked), `_to_delete/` (gitignored).
>
> **Next:** Tahir sends the material/grade additions and the assay figures; then rule on the tenth-object question; then, and only then, a schema.
>
> **ADD — same session, later:** Tahir ruled: **build on the existing app, do not delete `pd/`.** Reuse is **component-level and whitelisted**, never an extension of the old spine — six items only (candidate arithmetic engine `pd-lib.js:188–232`, Library file storage + auth-gated serve `pd-routes.js:1291/1435`, drop box + `/api/pd/similar` `:1658`, `pd_materials` + line-row shape, the `pdAuth`/`pdSurface`/`pdAuditLogger` plumbing, and the `/pd`-before-catch-all route rule). Everything else in `pd/` is opened only to delete it. Rules, vocabulary ban, reading rule and the **drift metrics** (old system measured 7 screens · 16 actions · ~95 fields · 19–21 menu items — targets and the stop-rule) are in **`docs/pd-model/REUSE-RULES.md`**. Everything the rebuild is waiting on is in **`docs/pd-model/PENDING-DECISIONS.md`** — §A is the three that **block the schema**: do the gates survive, is a Combination a tenth object, and is cost in or out of PD. Tahir confirmed **PD holds no real data** (which is what makes a core rebuild cheap — it stops being true the moment the team enters anything) and that **security/access findings are out of scope** for this rebuild per `CLAUDE.md` §2A. **Team review of the new rules and layout has not landed. No PD code is to be written until §A is answered.**

> **STATUS ADD — 2026-07-30 (cloud session, latest): "ACTIONS RETURN BACK" BUG — ROOT CAUSE FOUND, FIXED & TESTED, READY TO PUSH (not yet pushed).**
>
> **Symptom reported by Plant Manager / Supply Chain:** taking an action in My Actions, issuing a Gate Pass, or approving/releasing a shipment would sometimes silently undo itself — the button/prompt reappeared, forcing the user to redo it.
>
> **Confirmed live, same day:** Supply Chain issued a Gate Pass for 3 different DCs, and each one silently reverted to blank ~40–60 seconds later, so he issued a second (different) number for each: DC 42 (GP-0023 → **GP-0030**), DC 49 (GP-0017 → **GP-0027**), DC 52 (GP-0019 → **GP-0028**). All 3 were still sitting in "Loading" (not yet approved/released) when found — no dispatch was double-counted — but **the first (now-orphaned) number may already be on a printed gate slip; check DC 42/49/52 physically and use the current numbers.** Per Tahir's decision, no code/data change was made to reconcile these 3 — just flagged for the team.
>
> **Root cause — a real defect in the save/sync engine (`saveNow()`), not user error.** The app debounces saves and, on a 409 (someone/something else saved first), 3-way-merges local vs. server using `_baseSnapshot` as the common ancestor. The bug: on a **plain, non-conflicting** save success, the old code called `_snapBase()`, which re-reads whatever is **live** in `state` at that instant to refresh `_baseSnapshot`. If an **earlier-dispatched, slower** save (e.g. from an unrelated shipment row, minutes into a rapid multi-DC processing session) finishes **after** a newer edit (e.g. Issue Gate Pass) has already been applied locally, that live re-read silently "absorbs" the newer edit into the baseline — even though the server was never actually sent it. When that earlier save's own still-in-flight sibling then comes back as a 409, the merge sees `local === (poisoned) base` for that field and — per the 3-way rule ("unchanged from base → take server's") — takes the server's **stale, pre-edit** value, silently reverting the just-issued Gate Pass / approval back to blank. This needs no second user and no genuine simultaneous click — it reproduces from ONE person processing many shipments back-to-back in one tab (exactly what both the 2026-07-29 ~23-DC batch and this morning's ~20-DC batch looked like), whenever network timing lets an older in-flight save land after a newer one.
>
> **Fix (`saveNow()`, 1 line changed + comments, ~line 1640):** capture the exact wire payload as a string (`_bodyStr = JSON.stringify(dataOnly(state))`) synchronously before the fetch goes out (same as before), but on success, pin `_baseSnapshot = JSON.parse(_bodyStr)` — **exactly what was sent and confirmed** — instead of `_snapBase()`'s fresh live re-read. The baseline can then never claim more than the server actually has. The two OTHER `_snapBase()` call sites (409-merge resolution in `saveNow`, and the periodic background-sync merge) were left untouched — both run synchronously right after computing a fresh 3-way merge, so there's no gap for an unconfirmed edit to leak in; only the plain-success path had the gap.
>
> **Verified empirically, not just reasoned about:** extracted the real `merge3`/`saveNow`/`_snapBase`/`dataOnly` functions verbatim and ran them against a mock guarded server (mirrors `server.js`'s atomic `UPDATE...WHERE rev=?`) in Node. (1) Reproduced the exact bug with the **original** code — a controlled two-overlapping-saves scenario silently reverted a Gate Pass field. (2) Confirmed the **fixed** code preserves it in the identical scenario. (3) Confirmed the fix does **not** regress ordinary two-user merging — a genuine concurrent edit by another user (different field, different record) still survives alongside our own edit. (4) Confirmed successive plain saves from the same session still accumulate correctly. All `node --check` clean; diff is 3 small hunks (+40/-3 total incl. comments), line 1310 untouched.
>
> **Not done (by Tahir's choice):** no reconciliation of the 3 orphaned Gate Pass numbers (DC 42/49/52) — team handles that manually; this was purely a "tell the team" item, not a code/data fix.
>
> **STATUS ADD — 2026-07-28 (cloud session, latest):** **CHARTER SET · DEPLOY VERIFIED · DEAD-CODE AUDIT DONE · 3-PHASE PLAN AGREED.**
>
> **SYSTEM CHARTER (Tahir, 2026-07-28 — governs all future work):** This system does **NOT manage cost** (no product costing, no RM cost tracking, no cost attribution, no financial analysis). Its purpose: **track every task from order to shipment**, ensure each process step is handled **timely and carefully**, track **quality and production**, and build **clean data for future learning and modelling**. The **batch ID is the CORE key** — it traces production, packing, shipment, logistics and supply chain end-to-end. All cost-related backlog items are DROPPED (marked below). Existing cost fields/functions in code are dormant — candidates for the dead-code removal pass, build nothing new on them. (Sales-side data — invoice price on POs, sales targets — is order data, not costing, and stays.)
>
> **DEPLOY VERIFIED LIVE (2026-07-28):** Tahir pushed; served code confirmed to carry `nid()` random-suffix ids + `bumpSeqV1` + `healDupBatchIdsV1` + `fixVB26003LotRenameV1`. The rename migration FIRED on live (rev 1173): batch VB26003 lot is now **VB26003-L1**, COA SF0256 batchNo updated, flag `_fixVB26003LotRenameV1` set. Remaining operational step: **AQCM review → QCM approve COA SF0256** (status is back at "analysed" by design after the repair), then the batch can pack. Also still pending from §0q: the multi-PO **live click-through**, and the **divert/rework live functional test** (low-stakes batch, snapshot first).
>
> **3-PHASE PLAN (Tahir, 2026-07-28):**
> - **Phase 1 — build one by one:** (a) **New PO Entry P1: hardcoded catalog → master data** (seed from `VAN-Product-Master-FINAL.csv`, Admin Product/Client Master UI; then P2 quality-of-life); (b) production-group **rates tuning in Admin** as real output accrues (Tahir, ongoing — placeholders stand until then); (c) grant **Supply Chain Officer / Finance** custom-role screen access via the Admin access matrix.
> - **Phase 2 — settle the backlog:** #18 concurrent-save merge hardening (largely covered by the new id guards — still verify the `_NNNN` order-id artifact), #19 Ready-to-ship column alignment, monthly sales-budget data model + Master Data UI (#15, sales-side), relational DB + API (off-prod first), dynamic roles Stage 2 (only on concrete need), PO Tracker §0b enhancements (stalled tiering, debounce, "+N more", dispatch clear-date), Action Center deferred items (Cards view, bulk-select, Today-bucket split), and the **dead-code removal pass** (list below).
> - **Phase 3 — full system test:** logic, bugs, concurrency (multi-tab/409 merge), database integrity, end-to-end batch traceability.
>
> **DEAD-CODE AUDIT (2026-07-28, read-only — NOTHING removed yet; removal is a Phase-2 task).** Method: every declared function/const counted across the whole file (includes onclick strings in templates); no dynamic dispatch (`window[...]`/name-concat) exists in the app, so 0 extra references = genuinely unreachable. **~48 dead functions found:**
> - _Old screens/renderers superseded by redesigns:_ `screenShipOLD`, `renderShipModal`, `journeyCard`, `orderCard`, `renderProdLifecycle` (live path calls `renderProdLifecycleBatch`), `tkMatrixTable` (Matrix now = `t2matrix`), `rowS`.
> - _Old Action Center helpers:_ `acChipsHTML`, `acGroupBarHTML`, `acRoleBarHTML`, `acViewBarHTML`, `acMini`.
> - _Old Reports tab renderers (Reports is now Builder · Documents · RM chain):_ `rpTabsBar`, `rpMonthly`, `rpTrends`, `rpTrace`, `rpQCReports`, `rpShip`, `rpDelay`, `rpPOStatus`, `rpLog`, `rpExplorer`, `rpFilterBar`, `rpDrawChart` (+ `RP_TABS` transitively — its only reference is inside dead `rpTabsBar`).
> - _Dashboard / Production-Center leftovers:_ `drawDash`, `dashMyTodos`, `dashTargetsPanel`, `dashTrendStrip`, `trDrawChart`, `prodKpiStrip`, `prodCompletedThisMonth`, `prodLeavingList`, `qcGrpApproved`, `_pcBars`, `_pcCard`, `_pcKpi`, `_pcResult`, `batchPairsForLine`, `prodUndefer` (un-snooze is handled inline in `acDeferSubmit`).
> - _Misc:_ `dismissHint`, `hintHidden`, `showAllHints` (tip banners were removed 06-22), `addDealer`, `onDlrCity`, `onDlrRegion` (⚠ verify the dealer-add path moved to the Customers card before removing), `custParents`, `recAddItem`, `recDelItem`, `mpCapWarnHtml`, `raisePR` (PRs ride `rmSubmit`), `ACT_META`, `FIELD_LABEL`, `LIFE_GROUPS`, `LS_KEY`, `VAN_LOGO` (`VAN_LOGO_REAL` is the live one), `PROD_ICONS`.
> - _Corrections to older notes:_ `fld`/`editField`/`canEditField` are **NOT dead** (referenced by the order-drawer field grid, ~line 2930) — §0b item 2.5 is outdated on those; `myOpenFields`/`priorityPill`/`actCard`/`lastPackDate` are already gone. Line field `qcPass` is alive (in `AUTO_FIELDS`, written by Shipments, read by reports/drawer).
> - _Cost-touching functions (dormant under the no-cost charter, fold into the removal pass after Tahir confirms scope):_ `baseCost`, `rmMasterCost`, cost columns in masters/reports.


_Updated: 2026-06-19 · COO: Tahir · Single code file: `index.html` (4308 lines, vanilla JS). Backend: `server.js` (Node/Express + MySQL on HostGator, one `app_state` JSON blob + rev counter). Deploys never touch the DB. Pushes go via GitHub Desktop (Claude cannot push). Render auto-deploys on push; rollback restores prior code only, never the DB._

> **STATUS ADD — 2026-07-29 (cloud session):** **VL-MICRO MIX + VL-POTASH ADDED TO BULK MANUFACTURING — BUILT, READY TO PUSH (not pushed).** Floor request (via Production): both products often carry several POs that are each *below the minimum batch size*, so the plant needs to make one bulk run, QC it once, then pack out against POs as they come and **keep the batch open** until the bulk is consumed. This is a **deliberate, documented exception to the 2026-07-28 decision** (§0q: "multi-PO only — the ~40 own-base products do NOT get speculative Bulk → stock"). The exception covers **2 products only**; the other ~38 own-base products keep make-to-order discipline unchanged.
>
> **Changes (code-only — no master-data change, no migration, no data touched, nothing written to state):**
> 1. `BULK_BASES` (line ~3047) += `'VL-Micro Mix','VL-Potash'` → the "Bulk → stock" tab now offers them. 14 → 16 entries. The stale duplicate inside the `ProductionCenter` IIFE (~line 7757, currently dead code — no consumer) was kept in sync so it cannot drift.
> 2. New `isHybridBulkLine(l)` (after `isPODirectLine`, line ~3060): true when a line's product is **own-base AND a bulk base**. Today that is exactly **VL-Micro Mix, VL-Potash, Nitro Sulfur**.
> 3. **"To make" hybrid row** (`prodStageList`, `f==='tomake'`): for hybrid lines the row now shows the PO/multi batch state **and** the bulk state together, instead of one hiding the other. Appended states: `· Bulk ready` (+ **Pack from bulk**), `· Bulk in production`, `· Bulk awaiting QC` (made but not QC-cleared — deliberately offers **no** "Make in bulk" button, so nobody opens a second bulk batch on top of one sitting in QC), or, when no bulk exists at all, a ghost **Make in bulk ›** button. Pure compute + display (Rule 4): reads state, writes nothing.
> 4. Blocked-classifier: a hybrid line with **packable bulk** is no longer marked Blocked on an RM-check alone — packing from cleared bulk needs no RM. Prevents a false Blocked signal (Rule 3).
>
> **Why `isPODirectLine` was NOT simply flipped** (the obvious one-line fix, and it is wrong): its two branches are mutually exclusive — flipping it to `false` for these products would have **hidden running PO and multi-PO batches** from "To make" and shown *"Base short · none ready"* while a batch was actually running on the floor. Hence the additive hybrid row.
>
> **All three routes verified open for both products:** *Against a PO* (guard at ~3873 keys on `brandMap` base≠brand, never on `BULK_BASES`, so own-base passes — unchanged), *Multiple POs* (product list at ~3565 is built from `brandMap`, so both were **already** available before this change — unchanged), *Bulk → stock* (newly enabled). Adding to `BULK_BASES` is purely additive and cannot disturb the other two.
>
> **Rules held:** one run = one batch = one COA · batch-id traceability (base ▸ brand link on pack) · batch # FY-unique on all three routes · **QC before packing** (`batchPackableKg` counts only QCM-approved certified qty) · packing still requires a PO and caps to what that PO needs · no inventory module — bulk shows as *available for packing*, not as stock · no new Actions Center / My Actions entries.
> **Rule deliberately relaxed (Tahir, 2026-07-29):** the Bulk → stock path enforces **no RM check** (no `rmAllows`, no recipe check, no cap) — same as all 14 pre-existing bulk bases. Via the bulk route these two products can now bypass the RM Check → PR → CFO gate that the PO and multi-PO routes still enforce. Accepted knowingly for consistency; revisit if it is abused. Same applies to the reconcile back-date form ("Add missing production → Bulk base", ~line 2275), which now lists them.
> **Expect on the RM-chain report:** VL-Micro Mix / VL-Potash demand starts counting against their raw materials (Copper Sulfate sits in both recipes). That demand is real and was previously missing — it is a **correction**, but it will read as a new shortage to whoever watches that screen. Warn Supply Chain before the push.
>
> **Verification:** all 5 `<script>` blocks `node --check` clean · 38/38 logic tests pass (bulk-base membership; hybrid classification incl. negative cases VL-NPK / Fusion Potash / Crop Star; PO route visible; multi route visible; bulk surfacing alongside PO; QC gate blocks un-approved bulk; partial-pack keeps batch **open** 1000→700→450→0; no false Blocked) · **regression against live-shaped data** (21 orders / 104 batches from `data/state.json`): the entire "To make" screen diff is **three added ghost buttons and nothing else** — Nitro Sulfur ×2 and VL-Micro Mix ×1 (VL-Potash has no open line). Row count 33 → 33; filter counts All 33 / Ready 22 / Blocked 11 / Late 33 **identical before and after**.
>
> **State:** built locally on `2469453`, working tree otherwise clean, backup at `/tmp/index.html.pre-vlbulk.bak`. **Not pushed** — Tahir pushes via GitHub Desktop.
>
> **Not done (not asked):** no minimum-batch-size field — planned quantity stays free-form.
>
> **STATUS ADD — 2026-07-29 (cloud session — SESSION HANDOFF, resume from here):**
>
> ### 0. TWO SESSIONS ARE SHARING THIS WORKING TREE — READ FIRST
> While this session was running, a **separate concurrent session** was porting **PD (Product Development)** into O2S in the same folder. Its uncommitted work as of 11:08: modified `launcher.html`, `server.js`; new `PORTING_STATUS.md`, `pd.html`, `pd-lib.js`, `migrations/001_pd_foundation.sql`. **Do not touch those files, and do not `git checkout`/restore anything wholesale — you will destroy that session's work.** Check `git status` before any file operation. This session's own work is confined to `index.html` and `OP-HANDOFF.md`.
>
> ### A. DONE AND PUSHED — Boron duplicate-product fix (commit `f87dd05` "VL Boron")
> **The problem (found on live 2026-07-29):** one physical product carried two names in `SEED.brandMap` — `'VL Boron'` (correctly based on `Boron 5%`, but used by nobody: no orders, no batches, no packing, no production group) and `'V-Boron Liquid'` (wrongly registered as its **own base**, with only a placeholder recipe `"(recipe pending — set in app)"`). The client catalog offers V-Boron Liquid to BKK / Dealers / Vital Agri / Vgreen, so every PO said V-Boron Liquid — but `brandsForBase('Boron 5%')` returned only `['Max Boron','VL Boron']`. Production made batch **`VBO26001`** (base `Boron 5%`, 250 produced, **QC-approved, 250 certified, 0 packed, open**) and then could not select V-Boron Liquid in the pack dialog. **5 open PO lines, 97 units** (VG-VC-2607-1160 / -7630 / -8715 / -1345 and FRM-2607-6790), all 0 produced / 0 packed. **Nothing was mis-packed** — there were zero packing records for boron.
>
> **Tahir's decision:** canonical name **`VL-Boron`** (hyphenated, matching VL-NPK / VL-Micro Mix / VL-Potash), packed from base **`Boron 5%`**.
>
> **What shipped — 4 parts, all reusing mechanisms already in the file (+36 / −2, 5 hunks, line 1310 untouched):**
> 1. `BRAND_ALIAS` += `'V-Boron Liquid':'VL-Boron'`, `'VL Boron':'VL-Boron'`. The existing `migrateBrandNames(s)` then renames across orders / packingLog / batches / shipments / inspections each load. It deliberately does **not** walk `audit` or `actionLog`, so history reads as it happened (verified).
> 2. `BRANDMAP_FIX` += `'VL-Boron':{base:'Boron 5%',owner:'VAN',client:'VAN'}` — applied *before* the BRAND_ALIAS copy, so that copy's `!SEED.brandMap[...]` guard cannot overwrite it.
> 3. A retire block after the alias copy: deletes `V-Boron Liquid` / `VL Boron` from `SEED.brandMap` and `SEED.baseRecipes`, and rewrites `SEED.catalog.brandsByClient` for the 4 clients to brand `VL-Boron` / base `Boron 5%`. **In-memory SEED only — never the DB.**
> 4. `normalizeBoronBase(s)` — direct copy of the existing `normalizeVZincBase` pattern; sets `base='Boron 5%'` on VL-Boron order lines / packing / batches and carries `masters.groupOfBrand` across to the new name. Called at load right after `normalizeVZincBase(s)`. Idempotent.
>
> **Verified 22/22** against a fixture built from the real live records (all 5 lines rename + rebase, quantities untouched, `brandsForBase('Boron 5%')` → `Max Boron | VL-Boron`, both old names retired, Max Boron / V-Zinc / VL-NPK untouched, audit + actionLog preserved, groupOfBrand carried over, catalog fixed for all 4 clients, idempotent over 3 runs). VL-bulk suite still 38/38; all 5 `<script>` blocks `node --check` clean.
>
> **>>> OPEN ITEM — NOT YET VERIFIED ON LIVE.** The push happened at the very end of the session and the browser tab closed before confirmation. **First job next session:** open live, confirm (a) `typeof normalizeBoronBase === 'function'` (deploy landed), (b) the 5 PO lines now read brand `VL-Boron` / base `Boron 5%`, (c) `brandsForBase('Boron 5%')` includes `VL-Boron`, (d) the floor can pack `VBO26001`'s 250 against those POs. Also confirm a snapshot was taken before the push — this change rewrites `brand` and `base` on 5 live order lines on first load. And check with Tahir whether printed packaging says "V-Boron Liquid", since the rename changes what paperwork shows.
>
> ### B. PARKED — FY 2026-27 budget (all decisions made; code was built, tested 132/132, then deliberately REVERTED)
> Rolled back at Tahir's request because the diff was unreadable (see C). **Every decision is settled — the rebuild is mechanical:**
> - **FY 2026-27 = 1 Jul 2026 → 30 Jun 2027**, exactly what `fyKey()` already computes. Live confirmed `salesTargets` still holds only the ten `2025-26` entries and `salesTargetsMonthly` is `{}` — the current-year budget is genuinely blank.
> - **`BUDGET_BUCKETS = {Dealer:'Dealers', VGreen:'Vgreen', COBO:'COBO', 'Direct Farmer':'Direct Farmer', Distributor:'Distributors'}`** — target sits on the parent, children's POs contribute (how `Dealers` always worked). White-label alone is budgeted per client. **One constant** read by `budgetKey`, `budgetClients`, `budgetCategory` and the drill-down so they cannot drift — adding `Distributor` later was literally a one-word change. Bucket strings keep the **existing** spellings (`'Vgreen'`, not the master's `'VGreen'`) so FY25-26 history and `SEED.catalog.clients` stay aligned.
> - **Do NOT simply flip `isPODirectLine`** — its two branches are mutually exclusive; flipping it hides running PO/multi batches. The hybrid row must show both.
> - **`budgetClients()` must also read `state.customers`** — without it a client added on the Customers page is invisible in both target cards until its first PO. **Live proved this: `FMC Pakistan` is unselectable today.** Children of a bucket must be excluded so this year's figure cannot land on a superseded key (`VITAL AGRI`, `BKK`, individual farmers).
> - **Quarters are an ENTRY SHORTCUT ONLY, never stored.** Type a quarter → spreads into its 3 months in even thirds, remainder on the last month; the quarter displayed is always recomputed from the months. Months (`salesTargetsMonthly`) stay the single stored truth, so nothing can disagree.
> - **Category is DERIVED, never stored** — via the existing `_chanToSeg()`, falling back to `catalog.channelByClient`, then the customer master's own `segment`.
> - **VGreen child attribution:** every VGreen PO is raised against the parent (`o.client` is always `'Vgreen'`); the outlet is in **`o.vgreenSub`** (`VC`/`FM`/`DP`), the end customer in **`o.destinationPartner`**. All 5 live VGreen POs are `VC`. A generic child label shows nothing for VGreen — needs a `bgtChildLabel(o,c)` helper.
> - **Agreed figures — PKR 1,053,000,000 across 13 keys** (Tahir 2026-07-29; the 2 m Direct Farmer is **on top of** his 1,051 m table and covers all five farmers): Syngenta 424m · Rudolf 135m · Maxim 128m · LCI 71m · COBO 65m · UDPL 42m · Arysta **(= UPL, same account, no rename)** 32m · Dealers 40m · Distributors **(BKK + Kashmir Sugar Mills - Shorkot)** 40m · Kisan 40m · Vgreen 18m · **FMC Pakistan** 16m · Direct Farmer 2m. By category: White-label 888m (84.3%) · COBO 65m · Dealer 40m · Distributor 40m · VGreen 18m · Direct Farmer 2m.
> - Deliverable **`VAN_Budget_FY2026-27.xlsx`** (annual + 4 quarters + 12 months per client, category rollup, O2S entry steps) was sent to Tahir and is live-verified. **Tahir enters the figures himself; Claude writes no target data.**
> - **Rebuild plan agreed: 3 separate small pushes** — (1) parent/child buckets ~35 lines, (2) quarter shortcut ~90 lines, (3) category rollup ~40 lines. None touch line 1310. Review and push each before starting the next.
> - **Dropped for good:** adding `'Farmer'` to `SEED.channels`. It was the only thing dragging line 1310 into a diff, and live shows 6 farmer POs already raised fine, so it blocks nobody.
>
> ### C. LESSON — line 1310, and why diffs looked terrifying
> `SEED` is **98,220 characters on ONE line** (line 1310) — the only line in the file over 20,000 chars; the next longest is 7,610. Git diffs by line, so changing one word there prints the whole 96 KB line twice: a one-word edit produced a ~196 KB diff and GitHub Desktop showed a wall of red. **Rule: do not touch line 1310.** Everything else sits on 80–800 char lines and diffs cleanly. A reformat of `SEED` onto 6,279 lines was built and verified data-identical four ways (Python deep-equal, key order, canonical hash, JS `JSON.stringify` match) then **reverted unpushed** — Tahir judged a 6,279-line push not worth the trust cost when it can simply be avoided. Available as a standalone housekeeping job if ever wanted.
>
> ### D. LESSON — `data/state.json` is NOT live
> It is the gitignored file-mode fallback, dated 16 Jul. Live (read 29 Jul) had **25 orders / 27 customers / 55 batches / 0 shipments** vs the file's 21 / 21 / 104, plus **5 Direct Farmers** (file: 1), **2 Distributors** (file: 1) and **FMC Pakistan** (absent). **Read live instead:** `van-control-tower.onrender.com/o2s`, sign in as COO, then read `state` / `SEED` in the page context — **bare names, not `window.state`** (they are top-level `const`/`let`, not on `window`). Several early conclusions this session came from the stale file and had to be corrected.
>
> ### E. Restore points
> `/tmp/vanop-rollback/` on the device holds `index.html.budgetwork`, `OP-HANDOFF.md.budgetwork`, `index.html.before-seed-reformat`, `index.html.pre-boron`. **These are temporary — the real restore point is git.** The reverted budget code exists only in `index.html.budgetwork`; if that is gone, rebuild from the decisions in section B, which are complete enough to do so.
>
> **STATUS ADD — 2026-07-29/30 (cloud session): BORON FIX CONFIRMED LIVE · TRUCK-NUMBER INPUT BUG FIXED & LIVE · JULY-CLOSE READINESS CHECKED · 4 PROBLEM PO NUMBERS DIAGNOSED (2 resolved, 1 in progress, 1 decided-no-change).**
>
> **A-follow-up — Boron fix, resolves the “OPEN ITEM” above.** Verified live via browser: all 5 boron PO lines (VG-VC-2607-1160/-7630/-8715/-1345, FRM-2607-6790) now read brand `VL-Boron` / base `Boron 5%`; `brandsForBase('Boron 5%')` returns `Max Boron | VL-Boron`; batch `VBO26001` (250 kg, QC-approved) is now packable against all 5 — fully packed (19/5/24/15/34 = 97 units). No further action needed. Still open: confirm with Tahir whether printed packaging/paperwork said “V-Boron Liquid” and needs a heads-up to the floor about the label now reading “VL-Boron”.
>
> **F. DONE AND PUSHED — “Start shipment” truck-number field losing focus (live bug, fixed same day).** Symptom: typing a digit into the vehicle-number field on the multi-step Start-shipment modal (`renderMPShip`) jumped the page to the top on every keystroke, forcing users to scroll back down between digits. Root cause: the field's `oninput` called `mpSet('vehicle',this.value)` **and then** `renderMPShip()` — every other field only calls `mpSet` (which just writes the value, no re-render); vehicle was the one field wrongly re-rendering the whole modal on each keystroke, which remounts the DOM and resets scroll. Fix: removed the stray `renderMPShip()` call, one line (`+1/-1`). Verified 13/13 unit tests + a live DOM keystroke simulation on the real deployed form (7 keystrokes typed, input stayed focused and in-DOM, `scrollTop` stayed 0, step-3/4 logic unaffected). Pushed and **confirmed live**.
>
> **G. July-close readiness check (2026-07-29, ~2 days before month-end).** Ran a full read-only audit across order → production → QC → packing → inspection → shipment. **0 hard software blockers** — every batch numbered and traceable, no duplicate batch ids, all QC-approved batches packable, invoice prices present. **Work-backlog warnings for the team:** 65,599 kg awaiting QA across 83 lines; 271,628 kg QA-cleared but not yet dispatched (incl. 171,225 kg due the next day, Naya S Urea); 16 orders already overdue; at check time 0 shipment records existed (at least 1 has since been raised). Delivered a reusable **read-only** console script, `july-close-check.js`, so Tahir/team can re-run this audit anytime without writing any state.
>
> **H. Four problem PO numbers — diagnosed one by one, no master-data change made to any of them:**
> - **BKK `00476` / `000476`** — confirmed these are genuinely different orders, not a duplicate. **Tahir's decision: leave the system alone entirely.** No code or data change. Open item for Sales only: confirm the true PO number for the 4-July BKK order currently entered as `000476` (out of sequence vs `00453`/`00476`).
> - **PO0250 / 00150 (Kisan)** — **Tahir confirmed this is correct and real.** No action needed.
> - **“TBP” (Rudolf) — REAL PO SUPPLIED, FIX BUILT & TESTED, READY TO PUSH (not yet pushed).** Tahir supplied the real number 2026-07-30: **`RUDPO0033`**. Verified live first: RUDOLF LIFE SCIENCES has exactly **one** order in the whole system — `O17_1016`, po `TBP`, received 2026-07-01 — so there is no ambiguity about which order this is, and `RUDPO0033` is not used by any other order/batch/packing/inspection row (checked live, 0 hits). New guarded, idempotent function **`fixRudolfTBPPOV1(s)`** (added after `normalizeBoronBase`, wired into `ensureState` right after `fixVB26003LotRenameV1(s)`) renames `po` from `TBP` → `RUDPO0033` on: the order, batches `RUG26003` (`B1568-1q7l`) and `RUBS26003` (`B1565-92h9`), and the 3 packing rows (`PK1595-sw1u`, `PK1703-pcab`, `PK1704-o115`) + 3 inspection rows (`INS1855`, `INS1854`, `INS1853`). Batch `RUHAL26004` (`B1117`, a bulk-type batch) carries **no `po` field of its own** — nothing to touch there, it links only via packingLog/lots. **Deliberately leaves audit and actionLog untouched** (5 audit + 4 actionLog rows mention TBP) — same rule as `normalizeBoronBase`: history reads as it happened. Writes one new `audit` entry documenting the rename. **Verified 22/22** (fixture built from the live records: order/batches/packing/inspections rename correctly, unrelated PO `22032`/`99999` records untouched, `RUHAL26004` unaffected, old audit/actionLog rows byte-identical after the run, exactly one new audit row added, idempotent over a second run, no-ops safely on data with no `TBP` at all, doesn't throw on missing arrays). `node --check` clean on all 6 script blocks. **Diff is 2 small hunks (+21/-1), line 1310 untouched** — confirmed via `git diff` on the device. **Pre-migration snapshot saved** (order/batches/packing/inspections state captured before this build, kept in this session). Tahir pushes via GitHub Desktop; the rename fires on first load after deploy.
> - **“Maxim Old POs” bucket** — also created 22 July, same reason (backlog catch-all, not a cleanup miss — this answers Tahir's “why is Maxim firing up after the 30-June cleanup” question). It merges what were originally several real Maxim POs, which is why the same product (Max Sulfur) shows two different prices on the bucket. **Tahir's decision (confirmed via question): “Cap the bucket, real POs for the rest.”** No system/code change. Purely operational: (1) the 2,000 kg Max Sulfur already produced/packed **stays on the bucket** — ship/invoice it with a manual PO note; (2) **Production stops** making against the bucket's other 6 untouched lines (20,336 units); (3) once Maxim supplies real PO numbers, raise those as proper new orders. Nothing further needed from Claude here unless Tahir wants this instruction drafted for the floor/Sales team.
>
> **STATUS ADD — 2026-07-28 (cloud session, later):** **DUPLICATE BATCH-ID CORRUPTION — LIVE DATA REPAIRED, CODE GUARD READY TO PUSH.** Incident: batches VLNPK26002 (NPK 8.8.6) and VB26003 (Potassium Humate) were both created as internal id `B1114` — two open tabs each held seq=1114 and `'B'+(state.seq++)` handed out the same id; `merge3` (which pairs array records by id) then cross-merged their lots on every 409, wiping VLNPK26002's 500 kg output, parking lot VLNPK26002-L1 (wrong product) + a wrong QC sample (SF0255, "VB26002-L1"/Vibrant) inside VB26003, and leaking a stray lot into VBO26001 (which had separately collided as B1132). **Live DB repaired in-app (rev 1153–1155, admin session, all other users off):** VLNPK26002 → `B1556` (500/500, lot VLNPK26002-L1 fresh in Lab QC awaiting COA), VB26003 rebuilt as `B1134` (1160/1160, lot VB26003-L2 keeps its correct analysed COA SF0256), phantom twin removed, SF0255 deleted, VBO26001 cleaned, shiftEntries SE1114/SE1130 re-pointed, seq bumped to 1558; audit lines written. **Code fix (this working tree, NOT yet pushed):** (1) `nid(prefix)` — all 17 `'X'+(state.seq++)` id sites (B/LOT/SE/PK/PR + 3 order-id sites) now append a per-tab random suffix so two tabs can never mint the same id; (2) `bumpSeqV1(s)` — on every load/merge, seq jumps above the highest numeric id suffix in the data; (3) `healDupBatchIdsV1(s)` — end of `ensureState` chain (so it also runs on every 409-merge result): any batches still sharing an id get split, later twins re-id'd, their shiftEntries/packingLog re-pointed **by batchNo**, audit line logged. All 6 script blocks `node --check` clean; heal + collision simulated in node (twin split ✓, SE re-point ✓, no dups left ✓, two same-seq tabs mint distinct ids ✓). Old ids untouched. Tahir pushes via GitHub Desktop. ⚠ Stale tabs running pre-fix code can still re-corrupt until the deploy is live and everyone reloads.
>
> **STATUS ADD — 2026-07-28 (cloud session):** **§0q MULTI-PO BATCH — PUSHED & LIVE (commit `13befc4`, merged as `ecd6db3`).** One production run serving several POs of the same product (the Fusion Potash 3-client problem): "+ Open batch" gains a **Multiple POs** mode → one batch #, one Lab COA, pack out to each linked PO. Built per Tahir's decisions: pack **defaults** to linked POs (not locked) · shift output spreads **pro-rata** · **multi-PO only** (no bulk opened for the ~40 own-base products). Code-only, no data migration, no master change. All script blocks `node --check` clean; end-to-end simulation passed (open → FY-unique guard → RM guard → pro-rata shifts → 105% cap → QC once → pack ×3 POs → stage done); render smoke passed. Tahir pushes via GitHub Desktop.
>
> **STATUS — 2026-06-19 (session handoff; new chat starts here):**
>
> **LIVE & verified:** Production reconcile programme (§0j/§0k/§0l — by-product/divert/rework + fixes), §0m Stage 5 Command-Center lanes, §0n Action-Center-as-landing, and **§0o Action Center (My Actions) REDESIGN** — the merged urgency-first worklist (risk chips + role chip bar + grouped list + drawer/stepper), browser-confirmed (52 rows, Late 11 / Today 38 / Normal 3).
>
> **§0p PO Tracker REDESIGN — PUSHED & BROWSER-VERIFIED LIVE** (Matrix dense table default, stage rail, risk strip, Matrix·List·Board, slide-in drawer, channel filter, sharpened at-risk). All four screens — Production, Action Center, PO Tracker — are now redesigned & live.
>
> **Offline prototypes (design source of truth, in `E:\VAN Platform\`):** `VAN-ActionCenter-PROTOTYPE.html` / `-v2.html`, `VAN-POTracker-PROTOTYPE.html`; design re-audit `VAN-Design-ReAudit-MyActions-POTracker-Production.md`. Agreed scheme = **teal/charcoal** (app vars `--navy`/`--amber`/`--red`/`--txt`); blue `#1d4ed8` allowed for Lab/COA only.
>
> **Still open after §0p:** §0b PO Tracker's 1 original fix; design pass on remaining tabs (QC/Lab, Shipments, Reports, Sales & Budget — Production/PO-Tracker/Action-Center done); functional live test of divert/rework draws (writes data — low-stakes batch).
>
> **Working method (Tahir, firm):** offline-prototype → inline review → port to live → **Tahir pushes via GitHub Desktop** (Claude cannot push) → Claude verifies live + updates this handoff. Snapshot before any data change. Verify every edit (isolation `node --check`; the bash mount is often stale/truncated — trust the Read/Edit file tools + isolation checks, not full-file mount checks).

---

## 0q) PUSHED — 2026-07-28 · MULTI-PO BATCH (one run · several POs · one batch # · one COA) — code-only, no data migration

**PUSH RECORD (2026-07-28):** Tahir pushed commit `13befc4` "MUTIPLE PO"; GitHub required a pull because origin carried 4-day-old commits from the second contributor (launcher.html landing page + loading/login-first, compression middleware + `compression` dep, `/api/rev` light auto-refresh poll). GitHub Desktop auto-merged — **zero conflicts** (disjoint regions; the one grep hit was a CSS `====` comment divider, not a marker) — and pushed merge `ecd6db3`, which Render deploys. **Verified ON THE DEVICE post-merge:** working tree clean & up-to-date with origin; index.html 7,802 lines, all script blocks parse (`new Function` per block, node v22), 26 multi-PO markers intact, `/api/rev` poll present; `node --check server.js` clean; compression in package.json. ⚠ Container-mount caveat re-confirmed: a re-staged file kept serving the FIRST staging (stale bytes/size) — always verify on the device, never trust the uploads mount for freshness. **Still pending: live browser click-through** — open Production → "+ Open batch" → "Multiple POs" tab, open a small real multi-PO batch, log one shift, confirm linked POs advance on the tracker and the pack modal shows "· linked".

**Problem (floor, via Production & Lab):** products registered as their own base (e.g. **Fusion Potash** — ~40 such own-base/blend products) are NOT in `BULK_BASES`, so they can only be produced "Against a PO", and a PO batch's plan + shift output are capped to that single PO. One physical run serving 3 small POs was impossible as one batch → the floor was forced into 3 batch numbers → 3 COAs for one kettle. QC principle: **one production run = one batch = one COA** (clients get copies of the same batch COA; the per-client document is the pre-shipment QA, already per PO line).

**Design decisions (Tahir, 2026-07-28):** (1) pack **defaults** to the linked POs but is **not locked** — surplus can pack to any open PO of the product; (2) production progress spreads **pro-rata** across the linked PO lines so all clients' POs show In-Production; (3) **multi-PO only** — the ~40 own-base products do NOT get speculative "Bulk → stock" (make-to-order discipline kept). `BULK_BASES` untouched.

**Built (all in `index.html`, ready to push, NOT pushed):**
1. **"+ Open batch" → third mode "Multiple POs"** (`renderOpenBatch` rebuilt; new `mbForm`/`mbBasePick`/`mbTick`/`mbQty`): pick product (derived from open PO lines via brandMap→base) → tick PO lines, allocate full/partial per line (default = remaining, capped at remaining-order AND RM-allowed; RM-unconfirmed lines disabled with "RM not confirmed") → one batch # → live planned total (`#mbTotal`, no re-render so typing keeps focus).
2. **`submitMultiBatch()`** (+ dispatch in `openBatch('multi')`): per-line guards mirror the PO path (remaining order, `rmAllows` cap), batch # FY-unique via `batchOwnerInFY` + soft format check; creates `{kind:'multi', base, allocations:[{oid,lid,po,client,brand,kg}], plannedKg:Σ}`.
3. **`submitShiftLog` pro-rata branch**: each shift's output spreads across linked lines by allocation share (last line takes the rounding remainder; capped at each line's remaining order — residual stays as batch stock); sets `prodStart`/`prodComplete`; writes **one `productionLog` slice per PO** (line-accurate registers & reversals; `multi:true` marker). Zero-output shifts log one 0-kg entry. 105% plan cap + closed-batch guard unchanged.
4. **Packing**: `openPack` preselects the brand when all allocations share one; `renderPackModal` lists **linked POs first** with a "· linked" tag and shows "opened for N POs (…)" in the header. `doPack` itself unchanged (cross-PO packing already existed).
5. **Display**: journey/lane/board/lifecycle/output-table cards + shift-log header + QC rows show the multi kind (`MULTI-PO` tag, `batchPOsLabel(b)` = "3 POs · A, B, C"); pack buttons route multi via `openPack` (was bulk-only); per-PO-line "Log output" shortcut also finds multi batches covering that line. New CSS `.pjk.multi`.

**Untouched:** Lab QC/COA chain (batch-level already — one COA per multi batch automatically), pre-shipment QA (per PO line, quantity-true off packingLog), reconcile, pools (by-product/divert/rework — their targets include multi batches automatically), `BULK_BASES`, all master data. **No migration; additive only** (new kind exists only once the floor opens one; merge-safe via record addition).

**Naming note:** the multi-PO **shipment** wizard already owned `mpForm`/`mp*` — the batch form is `mbForm`/`mb*` to avoid the collision (caught by `node --check`).

**Verified (2026-07-28, isolation):** all 6 script blocks `node --check` clean; file 7,801 lines, 6 script tags, proper end; function census = exactly +5 (`batchPOsLabel`, `mbBasePick`, `mbQty`, `mbTick`, `submitMultiBatch`). Simulation (3 Fusion Potash POs 125/175/200 = 500 Kg): open ✓ · FY-reuse blocked ✓ · RM-unconfirmed blocked ✓ · pro-rata shifts 300+200 → lines land exactly 125/175/200, `producedKg` 500, 2 lots, 6 productionLog slices summing 500 ✓ · 105% cap blocks ✓ · QC approve → packable 500 ✓ · pack ×3 POs from the one batch, 3 packingLog entries all carrying FP26001, stage → done, remainder 0 ✓ · over-alloc blocked ("max 100"), partial alloc (60 of 100) ✓. Render smoke: multi modal (tabs/rows/RM flag/total/submit) ✓, pack modal linked-first + tag ✓, brand preselect ✓.

**Known nuances (accepted v1):** (a) reconcile of a shortfall doesn't walk back the pro-rata `l.produced` (packing's `produced=max(produced,packed)` never decreases; tracker delivery truth is `packed`); (b) ~~budget/cost view classes multi batches as "Bulk / unassigned" (cost attribution per PO can ride packingLog later)~~ **cost attribution DROPPED 2026-07-28 — no-cost charter**; (c) COA QC# client-prefix defaults to 'VN' for multi (no single client).

---

## 0p) SHIPPED & LIVE (browser-verified) — 2026-06-19 · PO Tracker REDESIGN ported to live `screenTracker` — render-only
_Live check (Chrome, COO): Matrix dense table default (21 rows), risk strip, 8-button stage rail, Matrix·List·Board toggle (Matrix active), Board = 7 lanes / 20 cards, drawer builds 3 bars + line items. `openTkDrawer`/`tkMatrixTable` present. Deployed cleanly._

Ports the reconciled prototype (`VAN-POTracker-PROTOTYPE.html`, from user's `o2s_po_tracker_improved_v3.html`) onto the existing tracker. **Render-only — reuses `orderBucket()` (the blocking/earliest-incomplete stage rule, already live), `orderBal`, `isOverdue/isStalled/attentionOf`, `t2matrix`, `orderCard`, `openOrder`.** No data/flow/rules change.

**Added:** (1) **slim risk strip** — open POs · at-risk · RM-blocked · Kg remaining; (2) **stage rail** — All + the 7 real buckets (PO Created → … → Delivered) with counts, click sets `trkStage`; (3) **Board view** (`t2board`) — kanban lanes by blocking stage; (4) **channel filter** (`trkChannel`); (5) **risk dropdown** (All risk / At risk / Overdue / Stalled / Priority) replacing the old risk chips that duplicated the rail; (6) **default view = Matrix** (PO × stage grid), toggle order **Matrix · List · Board**. `trkList()` now also gates by `trkStage` + `trkChannel`. New CSS `.tkstrip/.tkrail/.tkboard/.tklane/.tkbc` using live `--navy/--amber/--red` vars.

**De-dup respected:** the stage rail replaces the old RM-check/Production/Ready filter chips (which duplicated stage); the strip carries only non-stage signals.

**Matrix = the prototype's dense table** (`tkMatrixTable`, NOT the old PO×stage `t2matrix` grid — corrected after Tahir flagged the mismatch). Columns: PO · Customer · Channel · Stage (blocking) · Prod% · Pack% · Del% · Remaining · Owner · Next · Promise · Risk. Prod/Pack/Del% summed across each PO's lines; stage badge via `t2spill(orderBucket)`; risk pill Late/RM-blocked/Watch/On-track; promise via `t2promText`. (`t2matrix` left defined but unused.)

**Refinements (2026-06-19, after Tahir's live review):**
- **Slide-in drawer** (`openTkDrawer`/`closeTkDrawer`/`tkRiskBadge` + `.tkdrawer/.tkdim/.tkd*` CSS): row-click in ALL three views opens the prototype's right drawer (risk badge · Stage/Channel/KAM/Promise/Next/Remaining KV · Produced/Packed/Delivered bars · line items) with an **Open full PO** button → the existing `openOrder` detail. Replaces the prior direct `openOrder` on row-click.
- **"At risk" sharpened**: strip count = overdue OR RM-blocked OR priority-hot (dropped generic `isStalled` 7d) — was flagging ~17/18.
- **Header fix**: "N of M shown · stage = blocking" (was mislabeled "M open" while strip said the real open count).
- **Legend** only renders in List view (explains the flow dots, n/a to the table).
- **View toggle un-buried**: moved right of the toolbar with a "View" label, bolder buttons, teal border + subtle shadow (`.tkvwrap/.tkvlbl`).

**Verified:** isolation `node --check` clean on `screenTracker`/`t2board`/`trkMatch`/`trkList` (template-literal heavy). Live browser preview of the strip/rail counts couldn't run (extension connection dropped mid-session) — but every number is computed by the **already-live** `orderBucket/orderBal/isOverdue/attentionOf`, so it mirrors what the tracker already shows. Recommend: push, then a live click-through (Matrix default, rail filter, Board lanes, channel) like the Action Center.

---

## 0o) SHIPPED & LIVE (browser-verified) — 2026-06-19 · Action Center (My Actions) REDESIGN ported to live `screenApprovals` — render-only
_Live check (Chrome, COO): the merged worklist renders — 4 risk chips, role chip bar (7 roles), grouped Late·11 / Today·38 / Normal·3, 52 rows; `acRowHTML`/`acRoleBarHTML` present. Deployed cleanly._

Replaces the COO accordion "dashboard" with the approved **prototype-2 merged worklist** (design ref: user's `Action Center.html`; offline prototypes `VAN-ActionCenter-PROTOTYPE.html` / `-v2.html`). **Render-only — reuses `actionItems()` unchanged**; no rule, flow, or which-actions-exist logic touched.

**What it is:** one urgency-first list. Risk chips **All / Late / Today / Normal** (with counts) + an **oldest** caption; for COO a horizontal **role chip bar** (All + per-role counts, late in red) replaces the old left panel; grouped body **Late/blocked → Today → Normal**; each row = type badge + work (PO + customer · product · role) + waiting badge + the real action button (`it.act`). Row → **modal drawer** with Role/Product/Created/Promised/Qty-left + the 7-stage **stepper** (done / current / waiting) and the action button. Search (partial re-render, keeps focus) + Sort (risk/oldest/newest/customer).

**Role-driven (no manual toggle in live):** COO sees all roles + role bar; any other role sees only their own queue (no role bar) — same `state.role` logic as before.

**Mapping reused:** risk via `actOverdue`→late, else `actUrg()<=2`→today, else normal; age/created via `actTiming`; type colour by label (Pack QC=teal, Produce/RM=amber, Lab/COA=blue `#1d4ed8`, delay/fix=red, ship=grey); stage via `acStageOf`. New code: `acBase/acCounts/acFiltered/acRowHTML/acListHTML/acChipsHTML/acRoleBarHTML/acOpenDrawer` + new `screenApprovals`; scoped CSS `.ac2-*` (uses live `--navy/--amber/--red/--txt` vars).

**Verified offline:** isolation `node --check` clean; live risk-bucket simulation (reusing the live `actOverdue/actUrg`) on today's 64 actions → 8 late / 52 today / 4 normal (sums to 64), oldest 15d, role split Production 43·6late / QA 11·2 / SC 8 / Lab 2. Not yet browser-clicked.

**Notes / fast-follow:** the **Today** bucket is large (52) because "urgent but not overdue" (≥3d or hot) all land there — may want to split into "due soon" vs "this week" later. **Deferred from prototype:** Cards view and bulk-select (core worklist shipped first). Old helpers `actCard`/`acard` remain defined (now unused) — harmless.

---

## 0n) SHIPPED & LIVE (browser-verified) — 2026-06-19 · Landing page = Action Center for ALL users

On app open / login, every user now lands on the **Action Center ("My Actions", screen id `approvals`)** instead of the Dashboard. `screen` is a session key (never saved/shared), so the landing is set in three client spots, all now `'approvals'`: the seed default (`buildFromSeed`), `sessionInit` (reopen-with-session path), and `doLogin` (fresh login — guarded with `canView`, falls back to the role's first allowed screen only if it somehow can't view Action Center). In-session navigation (`setScreen`) is unchanged; the render-time access guards still redirect to `dash` only if a screen is genuinely unviewable. Verified: `approvals` is owned by every role. Bundled with §0m (same uncommitted `index.html`).

---

## 0m) SHIPPED & LIVE (browser-verified) — 2026-06-19 · Production STAGE 5 (Command Center lanes) — RENDER-ONLY, no logic/data change
_Live check (Chrome, COO): landing opens on My Actions; Production "All" shows 4 populated lanes (In production 2 / Awaiting Lab QC 12 / Ready to pack 7 / Packed) + By-product pool line; selecting a chip collapses to a single flat lane; back to All restores the lanes. `_prodLanes` confirmed running._

**Problem (from Tahir's live screenshot):** the Production journey was one giant flat scroll of ~30+ batch cards under the chips — hard to scan.

**Change:** when the **All** chip is selected, the journey list now renders as **labelled lanes** grouped by `batchStage` (the existing mutually-exclusive stage) — `In production` → `Awaiting Lab QC` → `Ready to pack` → `Reconcile` → `Packed — ready to close`. Each lane has a coloured header + count. Selecting a specific chip still shows that single lane as a flat list (unchanged behaviour). The by-product / divert / rework **pool lines stay as their own lanes** above. New helper `_prodLanes(items,ed)`; the journeyBoard list expression now branches `prodStage ? <flat filtered> : _prodLanes(_jb)`.

**Render-only — nothing else touched:** same `_jb` membership, same `journeyCard`, same `batchStage`/`batchClearedKg`/pack/QC logic. No data, no flow, no migration.

**Verified offline:** isolation `node --check` clean. Lane-coverage simulation on the 19-Jun snapshot: all 48 `_jb` batches bucket into exactly one lane (`producing/qc/pack/recon/done`), **0 unbucketed** — nothing is ever dropped from the board (the `done` lane catches fully-packed batches that aren't in any chip count). Not yet browser-clicked.

**Stage 4 + 5 = the Production reconcile/Command-Center programme is complete.**

---

## 0l) SHIPPED & LIVE — 2026-06-19 · Production STAGE 4c (REWORK) + pool-leak fix — code-only, no data migration

**Model:** rework = off-spec material of the **same base** — **NOT QC-cleared, needs re-processing**. Routed at reconcile into a **per-product rework pool**; Production calls it (partial) and **picks per call**: OWN batch or MERGE.

1. **Capture:** `saveReconcile` gains a `rework` branch (mirrors the pools) — accrues into one find-or-create open pool per base (`disposition:'rework', pool:true, sources[]`). No batch #, no QC while pooling.
2. **Visible line:** a **"Rework · {product}: X Kg pooled · off-spec, needs re-processing"** row on the Production journey (`_rwPools`), with a **"Call for rework ▸"** button (edit-rights only).
3. **Call** (`openRework`/`renderRework`/`submitRework`) — operator picks per call:
   - **Own batch** — assigns a batch # **now** (validated: `fyKey`/`batchOwnerInFY`/`validateBatchNo`), creates a normal producing batch (`producedKg:0`, `fromRework:true`, `reworkSources[]`) that shows on the board and follows the standard route — re-process (Log shift output) → Lab QC → pack → QA. Like by-product, but no grind label.
   - **Merge into a batch** — feeds it into a chosen open same-product batch **as input** (`reworkInputKg` + `plannedKg += qty`, `reworkedFrom[]`); rides that batch's re-process → QC → pack, **no own #**. Like divert's recycle. **Does NOT touch the target's `producedKg`/COA/`lots`/`packedKg`** (risk R6).
   - Both draws FIFO-consume the pool's `sources[]` (via the shared `consumeDivertSources`) and record the parent-batch slices for traceability; pool total recomputed from remaining sources.

**Pool-leak fix (applies to by-product/divert/rework):** `openBatches` and `doneBatches` now exclude `b.pool`, so **no pool ever appears in the Production "Open batches"/"Completed" cards** with Log-output/Reconcile buttons (this also closed a latent **divert-pool** leak from 4b, since a fully-drained pool with `plannedKg:0` would otherwise have surfaced there).

**Verified offline:** isolation `node --check` clean on the rework functions. Simulated against the 19-Jun snapshot: capture (3 reconciles → 1 pool, 400 kg), pool **not** in Open-batches, OWN call (new RW batch planned 250 / produced 0, pool −250, shows on board), MERGE (target planned +150, **produced/packed/lots unchanged**, pool drains to 0). 0 rework records live today → nothing live touched. **Pools confirmed silent in QC** (`producedKg>0` filters), **Set-batch-#** (`producedKg>0||packedKg>0`), and now **Open/Done batch cards** (`!b.pool`).

**Stage 4 COMPLETE** (4a by-product, 4b divert, 4c rework). The full reconcile model — loss / by-product / divert / rework — is now built end-to-end.

---

## 0k) SHIPPED & LIVE — 2026-06-19 · Production STAGE 4b (DIVERT) — code-only, no data migration

**Model:** divert = QC-cleared powder of the **same product**, routed at reconcile into a **visible per-product "diverted material" pool** (no own batch #, no QC, no re-processing) — then drawn two ways.

1. **Capture:** `saveReconcile` gains a `divert` branch (mirrors the by-product pool) — accrues into one find-or-create open pool per base (`disposition:'divert', pool:true, qcCleared:true, sources[]`), accumulating across many batches. No fragmented batch, no QC trigger.
2. **Hidden from the journey board:** `_jb` now excludes **all pools** (`!b.pool`) — both by-product and divert pools show on their own summary lines, never as "Producing 0" clutter.
3. **Visible line:** a **"Diverted material · {product}: X Kg available · QC-cleared"** row on the Production journey (computed via `_dvPools`), with **Recycle ▸** and **Pack to PO ▸** buttons (edit-rights only).
4. **Draws** (`openDivert`/`renderDivert`/`submitDivert`):
   - **Recycle into a batch** — feeds the diverted material into a chosen open same-product batch **as input** (`recycledInputKg` + `plannedKg += qty`, `recycledFrom[]`), then it rides that batch's normal grind → QC → pack. **Does NOT touch the target's `producedKg`/COA/`lots`/`packedKg`** (risk R6 — display/input vs. produced-math separation kept).
   - **Pack to a PO** — packs QC-cleared diverted stock straight into a brand for an open PO via the **real packing path** (creates a `packingLog` entry `fromDivert:true`, increments `l.packed`), decrements the pool. No re-processing, no new batch.
   - **Source-ledger preserved (traceability):** every draw FIFO-consumes the pool's `sources[]` via `consumeDivertSources(p,qty)` and records the exact parent-batch slices — pack writes `fromDivertSources:[{sourceBatchId,sourceBatchNo,kg}]` (NOT a single generic source #); recycle stores the slices on `recycledFrom[]`. Pool total is recomputed from the remaining `sources[]` after each draw so the ledger never drifts. Divert is QC-cleared under the parent COA, so parent-batch traceability is kept on every slice.
   - **Strictly same-product:** the recycle target and the pack PO line are both guarded at submit (`tb.base===p.base`; pack line's base via `l.base`/`SEED.brandMap` must equal `p.base`) — no brand/base mismatch, on top of the brand picker already being limited to `brandsForBase(p.base)`. Pack qty is capped to the PO's open quantity.

**Verified offline:** `node --check` clean on all 5 script blocks; `index.html` intact (4529 lines). Against the 19-Jun snapshot: 0 existing divert records (so nothing live is touched today); **no real/normal batch carries `pool:true`** (the new `!b.pool` filter hides nothing it shouldn't); simulated capture (2 reconciles → 1 pool, 1,000 kg), recycle (pool −300, target produced/packed/lots **unchanged**), and pack (pool −250, `packingLog` +1 carrying source #, `l.packed` +250) — all invariants hold. By-product pool (10,480 kg) and 51 normal batches untouched.

**Still open in Stage 4:** 4c **Rework** (operator picks own-batch like by-product OR merge like divert).

---

## 0j) SHIPPED & LIVE — 2026-06-19 · 3 live fixes (partial-batch packability + close PR + dangling notification) — code-only, no data migration

1. **Partial-batch packability (master fix):** a batch's QC-cleared, unpacked stock now **lands & accumulates in Ready-to-pack EVEN while the batch keeps producing** the remainder (it accumulates per batch as each lot clears — `batchClearedKg` already sums QC-approved lots). Changes: (a) `journeyCard` shows a **"Pack cleared (X)"** action on a producing batch when `cleared−packed>0.5`; (b) `_jc` count + the **"Ready to pack" chip/lens** include any batch with cleared-unpacked stock (so a batch can be in **Producing AND Ready-to-pack**). Fixes **MAXNK26007** (13,800 cleared of 25,000 plan — was locked under "Producing", now packable & visible in Ready-to-pack). Verified: producing 1 + pack 1, lens shows it.
2. **Close PR without full receipt:** new `closePR(prId)` + a **"Close PR"** button on the Receive-GRN card (Supply Chain / COO). Closes a PR at what was actually received — e.g. Manganese Sulfate Mono **1,500 of an over-stacked 3,000** (drops the unneeded 1,500), or **cancels** with nothing received (V-Zinc). Sets status closed, `qtyRequired=received`, reason + audit logged. Fixes the "can't close the PR" block.
3. **Dangling Receive notification fixed:** the **My-Actions "Receive" action now requires an OPEN PR** for the line's materials (`actionItems`, line ~2799). Previously it keyed only off the line (`prRaised && !rmReady && rmStatus!=='received`), so a closed/cancelled PR left the Receive action stuck in My Actions. Verified on live snapshot: the V-Zinc Receive (PR closed) disappears (6→5 actions); V-Mg's stays only while its PR is genuinely open, and clears the instant that PR is closed. Part of the PR-close flow.

**Verified:** `node --check` clean on all changes; `index.html` intact (4490 lines). **Code-only — no auto data migration** (both act only on user click); snapshot before use as good practice.

**THESE ARE NOW PART OF THE NEW PRODUCTION FLOW DESIGN (permanent, not hotfixes):**
- **Ready-to-pack is an accumulating per-batch quantity = QC-cleared − packed.** A batch can be **Producing AND Ready-to-pack at the same time**; each cleared lot lands in and accumulates into that batch's ready-to-pack; it is packable at any time while the batch keeps producing the rest. (Stage-label is no longer mutually exclusive for the pack lens.)
- **A PR can be closed before full receipt** ("received enough" → closes at the received qty; or "cancel" → nothing received), reason + audit logged — PRs no longer get stuck open.
- **Design link to Divert:** divert "pack to PO" now largely rides this same Ready-to-pack-while-producing mechanism (pack QC-cleared material to a client PO); the genuinely new divert piece is **recycle into another same-product batch** + the **cross-batch visible divert pool**.

---

## 0i) SHIPPED & LIVE — 2026-06-19 · Production STAGE 3 CORRECTIVE (by-product de-dup) — VERIFIED on live

**Pushed & confirmed on the post-corrective snapshot:** `_bpConsolidateV1` + `_bpDedupV1` both set; **21/21 fragments voided** (kg→0, no double-count); **0 by-product in the QC screen** (2 false entries cleared); 51 normal batches untouched; audit logged. **Bonus — Stage 2 proven live:** the pool grew 9,805→**10,480 Kg** (21→**23 sources**) because 2 more SCU batches were reconciled since, and they **accumulated into the single pool with NO new fragments** — confirming the accumulation logic works on live. Rule 1 (accumulation half) + Rule 5 (by-product slice) are now live & proven.

ORIGINAL NOTE (for record):

**What happened:** Stage 2+3 was pushed 19-Jun. The migration created the pool correctly (Nitro Sulfur · 9,805 Kg · 21 sources, guard set, audit logged) **BUT the 21 hard-deleted fragments came back** — the live save uses an **additive 3-way merge: record ADDITIONS stick, record DELETIONS do not survive concurrency** (a concurrent session re-adds them). Result in the post-push snapshot: 1 pool + 21 fragments = by-product **double-counted (≈19,610 Kg)**, and the 2 output-carrying fragments (B1285/B1283) re-surfaced in the **QC screen** (screenQC had no by-product filter; Stage 1 only filtered the board + actionItems).

**LESSON (important for all future migrations here): SOFT-DELETE (mark a field), never hard-delete — field edits survive the merge, record deletions don't.**

**Corrective fix (code-only, verified on the 19-Jun post-push snapshot):**
1. `dedupeByproductV1` migration — once a pool exists, **voids** leftover non-pool by-product fragments (`voided:true`, kg→0, status `void`) instead of deleting. Guard `_bpDedupV1`; only acts when a pool is present; audit-logged.
2. By-product **summary counts the POOL only** (`_bpPools.length?_bpPools:_bpAll`) — so kg is right (9,805) even if a soft-delete is partially fought by the merge.
3. `screenQC` now **excludes `disposition==='byproduct'`** — the 2 false QC entries gone from the QC tab too.
**Verified:** 19,610→9,805 summary, 21/21 fragments voided, QC by-product excluded, pool intact (9,805 · 21 sources), 51 normal batches untouched, idempotent, `node --check` clean, file intact (4458 lines). Rollback = the 19-Jun snapshot.

---

## 0h) PUSHED 2026-06-19 · Production STAGE 2+3 (logic + one-time DATA migration) — pool created OK; see §0i for the de-dup correction

**Stage 2 (logic, code-only):** `saveReconcile` by-product branch now **accrues into ONE open pool per base** (find-or-create, `pool:true`, `sources[]`) instead of a new fragmented batch per reconcile — never sets `producedKg`, so no batch#/QC until called for manufacturing. Divert/rework branches left unchanged (0 records today; full pool + call/merge lands in Stage 4).

**Stage 3 (DATA migration — runs once on load):** `consolidateByproductV1` merges the existing **21 by-product accruals → 1 open pool (9,805 Kg, all 21 source links kept, `producedKg` 0)**. Idempotent (`s._bpConsolidateV1`), audit-logged, wired LAST in `ensureState`. **Simulated against the 18-Jun snapshot:** 59→39 batches · 1 pool · 9,805 Kg · 21 sources · **38 normal batches byte-identical & untouched** · idempotent on re-run · pool cannot trigger QC. `node --check` clean; `index.html` intact (4445 lines).

**⚠ REQUIRES A FRESH SNAPSHOT before push** (Stage 3 mutates live `app_state` on load). Rollback: snapshot restore (data) or code revert (deploys don't touch DB). The 2 false QC actions are already gone via Stage 1's display filter; this removes the underlying 21 fragmented batches and replaces them with the single pool.

---

## 0g) READY TO PUSH — 2026-06-18 · Production STAGE 1 (display de-clutter; CODE-ONLY, no data/flow change; NOT yet pushed)

First stage of the reconcile/by-product rework (see `VAN-Production-Reconcile-Implementation-Plan.md`). **4 read-only display edits, no data write, no workflow change, no snapshot needed:**
1. `_jb` (Production journey board, screenProd) now excludes `disposition==='byproduct'` → the 19 empty "Producing 0" stubs are gone from the board; the stage chip counts follow (computed from `_jb`).
2. `noNoBatches` ("Set batch numbers" card) excludes by-product accruals (they get a # at call-for-manufacturing).
3. `actionItems` COA loop excludes by-product accruals → **clears the 2 false Lab-COA/QC actions** (B1285/B1283, 930 kg, no COA) — My-Actions count only drops.
4. Added a compact "By-product · Nitro Sulfur: N accruals · X Kg pooled" summary line on the board so the pooled material is still visible, just not cluttering.
**Live data untouched** — the 21 by-product accruals still exist in the DB; they're just not shown in the cluttered lists. `node --check` clean on all 4 edits; `index.html` intact (4418 lines, proper end). Rollback = code revert (deploys never touch the DB). Stages 2–5 (logic/data) remain gated on snapshot + sign-off.

---

## 0f) PRODUCTION AUDIT — 2026-06-18 (read-only; AUDIT ONLY, nothing built/pushed — Tahir emphatic)

**Write-path logic is sound** (verified): batch# FY-uniqueness, format validation, base-vs-brand guard, RM-availability gating, **105% over-production cap**, shift validation (shift+incharge+reason-if-zero). No flow blockers in the workflow.

**Main problem = clutter, not logic.** Of 48 batches shown, **19 are empty "Nitro Sulfur · 0 kg · no batch#" by-product stubs** (status open → render "Producing" forever), burying ~12 real batches. Also fills the "Set batch numbers" card (21 blank-# entries).

**By-product (Nitro Sulfur) — current behavior (confirmed in `saveReconcile`, ~line 2338):** each SCU batch reconcile **creates a separate by-product batch** (`state.batches.unshift({disposition:'byproduct', needsProduction, sourceBatch...})`). 21 fragmented accruals, 9,805 kg total. Two wrong routes: *needs-production* → empty "Producing 0" stub per routing (19); *ready-to-QC-&-pack* → tiny qty goes **straight to QC → QA** with no grinding (2, 930 kg). Each `plannedKg` = the accrued by-product kg; `sourceBatchNo` links the parent SCU batch.

**TARGET MODEL (Tahir, to build ONLY when approved):** by-product routes **only to Production, into ONE accumulating Nitro Sulfur pool** — every SCU batch adds to a single open by-product batch; **no QA alert, no QC while accumulating.** Stays open until Production **"calls it for manufacturing"** (~5,000 kg threshold, soft, or manual) → assign **batch #** → **grinding** (production process) → on completion follows the **pre-existing standard route** (Lab QC → pack → QA → ship), packing **against a Nitro Sulfur PO if one exists** (stock not managed in-app).

**Planned change set (deferred):** (1) rewrite by-product branch of `saveReconcile` to accumulate into one find-or-create open pool (record each source SCU batch), not spawn-per-reconcile; (2) suppress QC/QA on the accumulator until ground; (3) add "Call for manufacturing / grind" action (batch# + grind start); (4) one-time DATA merge of the existing 21 accruals → one ~9,805 kg pool (snapshot + approval). (5) Display: separate "By-product · Nitro Sulfur" lane + compact primary board (de-clutter), relabel "Producing 0"→"Needs grinding". **NONE BUILT.**

**DESIGN / INFO-FLOW PRINCIPLES recorded (display + information-architecture only — no master data, no real-time records, no business/data logic; from the reference mockup + Tahir):** (1) **Demand-first** — lead Production with a "what to make next" queue (PO · product · need · RM · recipe · due · one next action); demote the raw batch board to a secondary tab. (2) **Decision/KPI strip** at top (To produce / RM ready / In production / Awaiting QC / Ready to pack / Exceptions) computed from live data. (3) **Reconcile + by-product = their own lane**, separate from normal production. (4) **Ready-to-pack is inventory, not My-Actions noise.** (5) **Rows by default; forms open in a drawer only after an action is chosen.** (6) **Don't duplicate the PO Tracker** — Production queue stays production-specific ("what can I physically make now"). Out of scope / ignored: separate Packing/Inventory/Dispatch nav, the dark sidebar/palette, a full start-batch wizard (current open-batch flow already validates).

**WORKING METHOD (Tahir):** build a **full functional offline prototype FIRST** (file `VAN-Production-Command-Center-PROTOTYPE.html`, kept OUTSIDE the `VAN-OP` repo so it can never be pushed), iterate/rework/validate offline, and **do not go live until every challenge is solved.** Prototype saves nothing and is not connected to live data.

**CONFIRMED RECONCILE RULE-SET (Tahir, 2026-06-18 — for the prototype + eventual build; example: a 350/500 kg SCU remainder splits into loss + by-product + divert + rework):**
- **Loss / overfill** → recorded as loss only. No batch, no onward steps.
- **By-product (Nitro Sulfur)** → ONE accumulating pool (no batch#/QC/QA while pooling). Production **calls it anytime** (soft ~5,000 kg hint, not a gate) → batch# **at call** → **grind** → standard route (Lab QC → pack → QA → ship). Packs to a Nitro Sulfur PO **if one exists, else HOLDS** (it's its own sellable product).
- **Divert (CLARIFIED 2026-06-19 — e.g. Potassium Humate powder from grading)** → the SAME product, **already FINAL & QC-cleared under the parent batch's COA — NO separate QC, NO processing/grind, NO batch # of its own**. Captured at grading/reconcile and **ACCUMULATES into a per-PRODUCT "diverted material" pool/stock** (diverting from 5 batches → all land in that one product's pool; each source batch # tracked). **Production SEES it** as a visible line: "Diverted material available · [product]: X kg" (like the Nitro Sulfur by-product line). Production draws from the pool (partial) two ways: **(a) recycle** → allocate X kg as **input into a new/existing same-product production batch** (rides that batch's QC/pack), or **(b) pack** → ship X kg to a **client PO** (QC-cleared, carries source #). Stays in the visible pool until recycled or packed — never lost. _Difference vs by-product: divert pools too, but needs NO grind, NO re-QC, NO own batch #._
- **Rework** (off-spec, same base) → pooled + partial-call; **operator chooses per call: OWN batch (own #, standard route, like by-product) OR merge into an existing base batch (no own #, like divert)** → standard route → **ALWAYS to a PO**.
- **By-product & rework are POOLS with PARTIAL CALL that DO need a production/processing step** — accumulate, then Production calls a partial (or full) quantity when ready; a batch # is assigned **at call**; the remainder stays pooled. **Divert is the exception** — it is already QC-cleared (parent COA), needs NO processing, NO batch #; it is **recycled into a same-product batch as input OR packed straight to a PO** (see the Divert line above). Live implementation plan + risk register: `E:\VAN Platform\VAN-Production-Reconcile-Implementation-Plan.md` (5 staged, snapshot-first, reversible). Offline prototype models it all end-to-end.
- **Batch#** for **by-product & rework** routed batches: assigned **at "call for manufacturing" / when it enters processing** — never while accumulating. **Divert carries no own batch #** (it keeps its parent source batch # for traceability).
- **KEY:** **by-product & rework** require a production/processing step before QC — the old "ready to QC & pack" shortcut (cause of premature QC/QA) is REMOVED for those two. **Divert does NOT require any of that:** it is final & already QC-cleared under the parent batch's COA, so NO grind, NO re-QC, NO own batch # — it only **recycles** (as input into a same-product batch) or **packs to a PO**, carrying its source batch slices for traceability.
- Routes in scope (confirmed all occur): by-product, divert, rework. Modeled in `VAN-Production-Command-Center-PROTOTYPE.html` (Reconcile + By-product tabs) for offline validation — NOT built in the live app.

---

## 0a) SHIPPED & LIVE — 2026-06-18 · Action Center (My Actions) audit + display fixes (code-only; no data/flow/rules/master change; pushed in commit `94593b9`)

Tab-by-tab audit, Action Center first. **Audit result: logic, rules and accuracy are sound** — replicated every action trigger against the 18-Jun snapshot: **0 stale RM-Check rows** (none on already-produced/packed lines) and **0 false Produce rows** (none where the brand is already fully packed). `Acknowledge` correctly once-per-PO; `shipReadySince` dating, COO role-union view, and urgency-first sort all good. Three display-only improvements made (all in `actionItems`/`actTiming`, read-only — no writes, no flow/ownership/master change):

1. **`Open Production` now deep-links.** New helper `gotoProduce(oid)` (sets `prodMode='po'`, `prodPOsel=oid`, opens Production) replaces the generic `gotoScreen('prod')`. Clicking a Produce row now lands on that PO ready to pick the brand — and it now behaves like every other action (which all open a targeted modal/screen). Per-brand rows kept by design (still 47 rows — you see each brand needing production), only the button changed.
2. **`Ship` consolidated to ONE row per PO.** `openDispatch(oid)` is whole-PO (tick products on the truck), so the old per-line Ship repeated the same button (e.g. `22032` showed 3 identical Ship buttons). Now emitted once per PO after the lines loop: **8 line-rows → 6 PO-rows**; brand list kept in the description (`Ship N products (a, b, c)`), and the age spans all cleared lots via `shipLines` (e.g. `22032` = 7d since 11 Jun). `actTiming` Ship case updated to aggregate `shipLines` (back-compatible with a single `it.l`).
3. **Pre-shipment `Inspect` rows now carry a date/age.** Dispatch group passed through as `disp:g`; new `actTiming` branch `else if(it.disp) c=it.disp.date` so the card shows "since / Nd pending" (was blank). 0 pending in the current snapshot, so nothing to show yet, but it will populate when an inspection is queued.

**Verification:** full main `<script>` block reconstructed and `node --check`-clean **with** all edits; isolation run of the exact edited functions against the live snapshot passed (0 Ship rows missing a date, 0 Inspect rows missing a date, 0 Produce buttons not deep-linked, Ship 8→6, Produce unchanged at 47). Real `index.html` intact at 4308 lines, 5/5 script tags, proper end. **Cosmetic left alone:** render fn is still named `screenApprovals` for the "My Actions" screen (internal only; renaming risks the screen router for no user benefit).

---

## 0e) READY TO PUSH — 2026-06-18 · Sidebar / shell nav refinement (code-only display; no logic/data/flow; NOT yet pushed)

- **Grouped sidebar** — `renderNav` rewritten to render `NAV_GROUPS` (Work / Operations / Insights / Setup & admin / Guide) with section headers, replacing the flat 14-item list. Active pill kept.
- **My Actions live count badge** (`navBadge` → `actionItems()` filtered to role; COO sees all).
- **⌘K / Ctrl+K command palette** + a sidebar "Search PO or screen" trigger (`openCmdK`/`cmdkItems`/`cmdkRender`/`cmdkKey`, overlay `#cmdk`). Jumps to any screen, or any PO (PO match routes to Tracker pre-filtered by that PO#). Arrow keys + Enter + Esc. Keydown bound once via `window._cmdkBound`.
- **User dropdown** — `#rolebox` is now a native `<details class="usermenu">` avatar menu (name/role + Sign out); no extra JS, closes naturally.
- **Breadcrumb** — topbar subtitle now shows "Group · screen sub" (`groupOf(s.id)` in `render`).
- **Collapse** — kept existing `toggleSide()` (hamburger hides the sidebar on desktop).
- **Compacting pass (post first-look):** denser sidebar (rows 5px pad, 16px icons, 32px logo, 220px width, tighter group headers); search trigger rebuilt to a single non-wrapping line (magnifier + "Search…" + Ctrl K chip); top bar compacted (title 16px/700, padding 7px 18px, 32px toggle, slimmer helpbar) + `.wrap` 16px 20px — consistent modern shell.
- **DEFERRED (noted, not built):** (a) Admin *flyout* — the Admin screen is one monolithic page, so a flyout can't deep-link into sub-cards; low value, skipped to avoid risk. (b) icon-rail collapse — current collapse hides the sidebar rather than shrinking to an icon rail.
- New CSS: `.navgrp`, `.nlbl`, `.navct`, `.usermenu*`, `.navsearch`, `.cmdk*`. New globals: `NAV_GROUPS`, `window._cmdkBound/_cmdkSel`.
- **Verified:** `node --check` clean on the shell script block; real `index.html` intact (4415 lines, 5/5 script tags, proper end). No data/flow/rules/master change.

**This push bundles:** §0c tracker-v2 refinements + §0d color scheme + §0e nav — all code-only, no DB impact.

---

## 0d) READY TO PUSH — 2026-06-18 · App-wide color scheme: Teal & Charcoal (CSS-only; no logic/data; NOT yet pushed)

Whole-app reskin via the `:root` CSS variables (primary `--navy`/`--green`/`--teal` → teal `#0e7c66`; `--blue` accent → `#2563eb`; charcoal text `--txt #1a2420`; cool neutral surfaces/lines; amber/red status kept). Swept all hardcoded old-green literals app-wide (`1f7a43`, `155e32`, `74b53a`, `e7f3ea`, `rgba(31,122,67…)`) so every screen reskins consistently — incl. helpbar, brand logo, SVG icon strokes, focus ring. Chosen as "best" for a modern, agri-appropriate, professional look. One-variable system, trivial to swap. **NEXT (in progress): full sidebar/nav refinement** — group 14 items into Work/Operations/Insights/Setup, active pill + count badge, collapsible rail, breadcrumb top bar, user dropdown, ⌘K jump-to search, Admin flyout (display-only).

---

## 0c) PO Tracker redesign — 2026-06-18 (code-only; no data/flow/rules/master change). v1 SHIPPED; v2 refinements PENDING PUSH.

Full redesign of `screenTracker`/`orderCard` + new CSS. Decision (Tahir): **at-risk pinned on top, then newest first.** All display-only — drawer stays read-only, Matrix view preserved, chip counts unchanged, no data touched.

**v2 refinements (pending push, after Tahir's first-look review):** (a) **removed the decision-strip metric cards** — they duplicated the filter chips (same Overdue/Stalled/Ready counts) and wasted vertical space; the clickable chips serve both roles now. (b) **List/Matrix toggle moved to top-left**, first in the controls bar (was hidden far-right). (c) **Sort control labelled** "Sort"; chips = filters ("All" = no filter, default), dropdown = ordering. (d) **Pinned section = OVERDUE only** (`isOverdue`), not overdue+stalled — pinning all 16 stalled left "Active" with just 2; now 2 pinned / 18 newest-first, with stalled shown amber inline. Note: the mockup shown in chat used Claude's palette for illustration; the live screen keeps VAN's own colours by design.

- **Compact one-line rows on a fixed CSS grid** (new `.tk*` classes) — fixes the column "slipping"/misalignment; far denser than the old `.t2row`.
- **Decision strip** (metric cards): Overdue / Stalled 7d+ / Ready to ship / New today.
- **Visible controls:** a proper sort `<select>` (`risk_new` default; + Newest first / By stage / Longest in stage) and a clear List/Matrix segmented toggle (`.tkseg`) — no longer hidden far-right.
- **Sections:** "Needs attention · N" (overdue+stalled, `_trkRiskCmp`) pinned above "Active · newest first · N" (`_trkNewCmp`). **All 20 shown, no cap.**
- **Search cursor bug FIXED:** input now repaints only `#trkBody` via `_trkPaint()` (no full screen re-render per keystroke) — the "backward typing" caret reset is gone.
- **REMAINING BALANCE per PO** (`orderBal` = Σordered − Σdelivered; e.g. Naya S Urea PO 6595010464 = 339,775 left of 450,000) shown as "X left · del/ord · progress bar". **Multi-product POs expand** (`toggleTrkRow`/`tkLineRow`, state in `trkExpanded`) to per-product running balance. 9/20 POs are multi-product.
- **Audit fix 1.1 applied:** the stale tracker helpbar override is disabled (`if(false){…}` at the `s.id==='tracker'` block) so the meta bar now reads "view only", matching the read-only drawer.
- New fns: `orderBal`, `tkProg`, `tkBalCell`, `tkLineRow`, `t2bars`, `toggleTrkRow`, `_trkRecv`, `_trkNewCmp`, `_trkRiskCmp`, `trkList`, `trkBodyHTML`, `_trkPaint`. New globals `trkSort`(default `risk_new`), `trkExpanded`. New `.tk*` CSS block.
- **Verified:** `node --check` clean on the tracker script block; real file intact (4357 lines, 5/5 script tags, proper end); snapshot balances correct; section split correct (all 20 shown).

---

## 0b) PO Tracker audit — 2026-06-18 (read-only review; NO code changed yet; 1 fix open + enhancements)

Tab audit #2. **Engine is accurate** — replicated ageing/overdue/stalled against the 18-Jun snapshot: of 17 "stalled" orders, 15 have *exact* stage-entry dates and are genuinely stuck (real backlog, e.g. PO `1821412156` 17d in "PO Created", `21630` 13d in "RM Check"); only 2 use the honest "~" approximate fallback. Chip counts mirror `trkMatch` exactly. No flow blockers, no security issues.

**FIX 1.1 — DONE in §0c (was: misleading helpbar vs read-only drawer):** the meta bar shows `Update here: Yes — <role fields> (click to open)` (COO sees "any field"), but the order drawer (`openOrder`) is hard read-only (`fld()` has `ed=false`, drawer says "View only") and the registry text says "Updates are entered from each role's own screen." Root cause: stale per-role override in the helpbar builder (~line 1197, `if(s.id==='tracker'){…upd='Yes — '+tm[state.role]+…}`), residue of a former editable drawer. **Fix:** delete that tracker override so it falls through to `upd='No — view only'`. Display-only.

**Enhancements (by ease×impact):** (2.1 easy/high) stalled signal dilutes at 16/20 red — tier 7–13d vs 14d+, or per-stage SLA; (2.2 easy/med) search `oninput`→`trkRender()` re-renders whole screen + manual refocus (line 1744) → debounce / list-only re-render; (2.3 easy/low) `mixed` orders show only earliest-stage next action (`NEXT_ACT[orderBucket]`) — add "+N more"; (2.4 med/low) 2 Shipment-stage POs (`6595010236` ~17d, `6595010464` ~10d) read "~" because lots carry no QA-pass/clear date — dispatch should write a clear date; (2.5 cleanup/low) **dead code:** `fld()`/`editField()`/`myOpenFields()`/`canEditField()`/`LIFE_GROUPS`/`FIELD_LABEL` are defined but never called (drawer went read-only) — removing them kills the 1.1 class of bug.

---

## 0) SHIPPED & LIVE — 2026-06-17/18 session (all verified in live code; data fixes recorded done in live DB)

**F · Production stage fix — packable stock no longer flagged "Reconcile required" (READ-ONLY display logic; no data/My-Actions change; LIVE — guard `(cleared-packed)<=0.5` confirmed in `index.html`):** `batchStage` was marking any *closed* batch with unpacked remainder as `recon`, overriding "Ready to pack" — so 21 batches of QC-cleared, fully packable stock (NP26007 25,000; HG26020 17,500; HG26019 43,500; RUBS26003 13,200; +15 SCU leftovers) showed "Reconcile required · stalled" before packing even started. Surgical fix: added `&& (cleared-packed)<=0.5` to the recon condition, so a batch is only `recon` when **no QC-cleared stock is left to pack**; the Reconcile button stays available as a choice (production AND packing stages). Verified on snapshot: exactly 21 recon→pack, every other stage unchanged (incl. VU26138 stays qc — no side effect), genuine reconcile (closed + uncleared leftover) preserved. `batchStage` is derived (stores nothing); `actionItems`/My Actions don't use it → no notification change.

**E · VU26134 phantom-lot fix (DATA migration, approved by Tahir, runs once on load; LIVE — `_fixVU26134L2V1` = true in 18 Jun snapshot, migration has run on production):** `fixPhantomLotVU26134` removes batch VU26134's duplicate phantom lot L2 — L1 & L2 shared id `LOT1158` (L2 a byte-for-byte copy of L1 with no COA), over-allocating to 10,500 kg vs the 7,000 produced, so "approve all" cleared L1 and left L2 stuck in the Lab QC queue forever. Heavily guarded: VU26134 only; only when over-allocated; only a duplicate-id lot with no approved COA; never under-allocates below producedKg; audit-logged; idempotent via `_fixVU26134L2V1`. Verified on snapshot: 3→2 lots, 10,500→7,000, exactly ONE lot removed across all batches, stuck QC clears. (Diagnosis confirmed it was a duplicate, not real production: producedKg/plannedKg=7,000, packed 6,500, L2 identical to L1, and 21/21 other SCU batches are 7,000 kg.)

**H · My Actions date + dedupe fixes (READ-ONLY display logic; no data/flow/My-Actions-membership change; LIVE — superseded by I, see note):** (1) **Ship "since" date** — `actTiming` Ship case used `l.qcPass || order.received`, but live orders never set line `qcPass` (QC is per-lot), so all 8 Ship actions showed a false "~17d since received". This was first fixed with `lastPackDate(o,l)`, then **replaced in item I by `shipReadySince`** (the truer "oldest QC-cleared, not-yet-shipped lot" — so `lastPackDate` is no longer in the code; `shipReadySince` is what's live). (2) **Acknowledge** moved out of the per-line loop → **one per PO** (was N identical actions for an N-line unacked PO; latent — 0 unacked orders currently). No action added/removed, no ownership change, no writes. Verified on snapshot.

**I · My Actions final polish (READ-ONLY display; no data/master/flow loss; LIVE — `shipReadySince` confirmed in `index.html`):** (1) **Ship "since" = oldest QC-cleared, not-yet-shipped lot** (`shipReadySince`) — truest "waiting since" (replaces the latest-packed proxy; stays consistent with when Ship actually fires). (2) **COO view hardening** — action groups derived from roles actually present (preferred order, then any extras) so no action is ever dropped if a role isn't in the fixed list. (3) **Pack-inspection trigger added** (`label:'Pack QC'`, QA Inspector, per line, `lineToInspect>0.5` → `openPackInspect`) — closes the one real completeness gap from the per-role audit; was only on the QC screen. Audit conclusion: My Actions is otherwise complete; the 29 "ready-to-pack" batches were deliberately NOT dumped in as rows (inventory state, screen-driven, would be noise). Verified on snapshot + synthetic cases.

**G · CRITICAL — auto-refresh no longer clobbers an unsaved PO (code-only; LIVE — `_savePending` confirmed in `index.html`; the LCI PO 4204003692 is now present in the 18 Jun snapshot, recv 18 Jun):** Root cause of the "I added an LCI PO and it vanished" report (PO 4204003692, confirmed absent from the 06-18 snapshot — never persisted). The 7s `startSync` did `state=ensureState(j.data)` — a **blind replace** of local state with the server's, guarded only by focused-input/modal/`hasUnsavedEntry`. After PO submit the form is cleared and you're moved to the Tracker, and the save is debounced 400ms — so a refresh firing in that gap while Production was saving (their reconcile saves were live at 08:1x on 06-18) replaced local state and wiped the just-created order before it saved. Fix: added `_savePending` (set synchronously in `save()`, cleared on successful `saveNow`); `startSync` now (1) **skips** the pull while `_savePending`, and (2) **merges** via the proven `merge3` instead of blind-replacing — so a not-yet-saved local order can never be clobbered. Verified in sandbox: simulated race keeps the new order AND the concurrent Production change. Related to backlog #18.

**A · Imported-order cleanup (data migration, runs once on load):** `purgeImportDuplicates` (13 twinned dups) + `purgeImportedNoTwin` (8 no-twin imports). Combined verified end-state 40→19 orders, 57→11 shipments, 0 `createdSeed` / 0 `by:'Imported'` left, 11 live shipments kept, idempotent. Safety skip on any import with live work. Snapshot first; keep `van-data-snapshot-2026-06-17.json` as restore point.

**B · New PO Entry P0 fixes (`entryChecks`/`submitPO`):** duplicate-PO# guard, pack>0, promised≥received + committed≥received; corrected the entry tip (invoice price here; print price at packing). Review in `reviews/NEWPO-ENTRY-REVIEW.md`.

**D · Priority + computed-risk combination (READ-ONLY, no data/alerts/master change):** `attentionOf(o)` blends computed risk (overdue→due-soon→on-track, from committed dates) with manual priority (Critical/High/Normal/Low). Used ONLY for: PO Tracker sort (`attnCmp`: risk tier → priority → days overdue → received) and a single combined "attention" chip on the order card (shows only when elevated; replaced the always-on priority pill → less clutter). Pure compute — writes nothing, adds no My Actions/audit/alerts, no master change. `priorityPill` now unused (harmless). Verified: 8/8 logic assertions (risk leads, priority orders within tier); read-only confirmed.

**C · Capable-to-promise committed dates + line/volume roll-up:**
- New master data: `masters.leadTime` {rateKgPerDay 5000 (default/fallback), qcDays 1, dispatchDays 2, rmProcureDays 7, minDays 3}; `masters.productionGroups` {Powder/Crystalline/Liquid/Granular 5000, Humic 10000, Sulfur Coated Urea 14000}; `masters.groupOfBrand` (brand→group, pre-filled by form + Potassium Humate→Humic, Sulfur Coated Urea→SCU specials; additive). All editable in **Admin · Master Data → Delivery lead-time & production groups** (`leadTimeCard`/`saveLeadTime`, COO). Rates are placeholders (thin data) — tune in Admin.
- **Committed-date engine (make-to-order, sequential):** `computeCommitted(received,qty,procureDays,brand,s)` = received + procurement + ⌈qty ÷ group-rate(brand)⌉ production + qc + dispatch, floored at minDays. **Procurement = bottleneck:** the slowest required raw material not in stock (`procureDaysFor` → `matLead`, per-material `leadDays` in rawMaterials master else default 7; 0 if all stocked). **Production rate = the brand's production-group daily rate** (`rateForBrand`→`groupRate`, else default). Auto-fills each line's committed on New PO Entry live as qty changes (`updateCommitted`; override allowed; shows "auto · Nd lead · incl Xd RM"); persisted in `submitPO`.
- **Roll-up (fixes the 9-of-10 false-delay):** PO Tracker card now shows "X of N lines late · Y/N delivered" instead of a blanket overdue stamp; dashboard adds **Overdue Lines** KPI; dashboard per-line overdue now consistently uses `l.committed` (was `o.promised`). On-time % was already line-level.
- **Promised vs Committed (settled):** Promised = customer-facing PO date; Committed = per-line ops target from the lead-time model. Products on one PO can carry different committed dates by design.
- Verified: computeCommitted / leadDays / lineRollup unit-tested; new functions syntax-checked in isolation; host file end intact. Rate 8,000 is a thin-data placeholder (5 prod records) — tune in Admin as output accrues; split per-base later.

---

## 1) SHIPPED & LIVE — 3 code edits (code only, no data touched; confirmed in live `index.html`)

1. **`lineOverdue`** (line 771) — received-date guard: a line whose `committed` date is before `o.received` is treated as a bad/imported date and is NOT overdue. Clears UDPL & Arysta false-overdue.
2. **`pmDelayLabel`** (lines ~2227–2229) — same received-date guard, plus tightened to fire the delay-reason prompt **only when genuinely overdue** (removed the "due in N days / due today" nag). Plant-Manager prompts ~50 → ~18.
3. **PO Tracker render** (line ~1456 + section logic) — grouped by **stage + owning role**, count header `N orders · M overdue`, sort = stage order then most-overdue first.

Verification: isolation-sandbox pass on overdue/delay logic; 5/5 `<script>` tags intact; edits confirmed on disk. No master-data / order / shipment / QC / stock change.

---

## 2) ALREADY LIVE (pushed earlier this session)

- PR/Receive fixes: `rmSubmit` guard (no phantom PR on empty lines), `openReceiveMaterials` matches a line's actual requisition, `healPRFlags` resets stale `prRaised`.
- Naming/recipe foundation: `RECIPE_ALIAS`, `BRAND_ALIAS`, `migrateBrandNames`, `BRANDMAP_FIX` (34 brands → 13 bases), `BYPRODUCT_BASES` (Nitro Sulfur from SCU), `loadBaseRecipesV2` (13 bases), `loadBlendRecipesV1/V2` (~34 blends), recipe-picker shows only the 13 bulk bases, RM-check blocked when a base has no recipe.
- `purgeImportedProduction`: removed imported/seed production batches + seed productionLog; KEPT orders, shipments, raw stock.
- **`purgeImportDuplicates` (DATA change — pushed 2026-06-17): the 13 duplicate-PO cleanup is DONE.** One-time, idempotent (guard `s._purgeImpDupV1`), runs in `ensureState` after `purgeImportedProduction`. Removes each `createdSeed` import copy whose PO# is shared by a live New-PO-Entry twin (no `createdSeed`), plus ONLY that PO's `by:'Imported'` shipments. Verified against the 2026-06-17 snapshot: **13 orders + 12 imported shipments removed; 11 live `Supply Chain` shipments preserved (incl. Syngenta 6595010236's 7); 0 orphan refs; idempotent on re-run.** Safety guard: any import copy showing live work (`packed`/`produced` > `delivered`) is SKIPPED, left in place, and logged to `audit` — real packing/production is never deleted. The 8 imported-no-twin orders + their ~34 imported shipments are intentionally LEFT ALONE (see OPEN below). Writes an `audit` entry on run.
- **`.gitattributes` added (2026-06-17):** repo locked to LF (`* text=auto eol=lf` + explicit html/js/json/md/yaml) to stop whole-file CRLF↔LF diff churn. After adding it, run `git add --renormalize .` once if a stray CRLF diff reappears.

---

## 3) OPEN — needs decision (13-dup cleanup now DONE; only no-twin scope remains)

**Imported-order + duplicate-PO cleanup — 13 duplicates DONE (see §2). Remaining open item: the 8 imported-no-twin orders.**
- ~~13 PO numbers each exist twice~~ — RESOLVED & LIVE via `purgeImportDuplicates` (see §2). The 13 removed: 21301, 21630, 21775, 22032, 22033, 260400001, 1821412156, 4204003087, 6595010236, 7500003652, VG-2605-0002, DLR-2605-0001, DLR-2606-0001.
- ~~STILL OPEN — the 8 imported-no-twin orders~~ — RESOLVED 2026-06-17. GOVERNING PRINCIPLE (Tahir): **anything delivered before the system went live should NOT sit in the operational system** → all 8 removed. `purgeImportedNoTwin` written + sandbox-verified, **READY TO PUSH (not yet pushed)**. Removes the 8 (6595010235, 6595010360, 260300001, 4204003000, 4204003240, P00206, VG-2605-0001, 2026-00358) + their 34 `by:'Imported'` shipments; same live-work safety skip; guard `s._purgeImpNoTwinV1`; wired after `purgeImportDuplicates`. Note: 6595010360's `ordered=250,500` vs `delivered=120,525` was inflated import data (Tahir: it was 100% delivered pre-launch), not a real open balance — removal clears the phantom overdue. Verified end-state across BOTH purges: **40→19 orders, 57→11 shipments, 0 `createdSeed` orders left, 0 `by:'Imported'` shipments left, 11 live `Supply Chain` shipments preserved, idempotent.**
- Tahir's call (13 dups): **remove the imported copy, keep the new one** — DONE.
- Cascade: imported orders' deliveries came from imported shipments → removing the orders should also remove their imported shipments, else orphan shipments / "shipped X but order shows 0" mismatches.
- UNANSWERED scope question: (A) remove ALL imported (`createdSeed`) orders + their shipments — full clean slate, matches "no opening balance"; or (B) only the 13 duplicated POs + their shipments.
- Symptom this fixes: My Actions = 161 pending (Supply Chain 59 RM-Check/Receive, Production 49, Plant Manager 50, Lab 3), mostly imported-order noise. The push above already cuts the PM delay flood; the data cleanup cuts the RM-Check/Produce floods.
- LIVE OPERATIONAL RISK (seen 2026-06-17): the duplicate POs now appear twice in the **Pack** dropdown (e.g. PO 6595010236 · Syngenta shows two entries, "needs 221,917" and "needs 271,504") — an operator can pack bulk base into the wrong (imported) copy. Interim: tell Production to pack into the NEW copy only until cleanup is done. Raises priority of this cleanup.
- Possible-intentional, do NOT auto-merge: duplicate brand lines with different qty (e.g. Max Sulfur 5,000 + 1,000) look like split lines.
- KEEP vs REMOVE marker (verified 2026-06-17): KEEP = order WITHOUT `createdSeed` (Tahir's new copy, received 2026-06-01); REMOVE = `createdSeed:true` (imported, older date). Scan = exactly 13 duplicate POs, no more.
- GOVERNING RULE (Tahir, 2026-06-17): **Imported POs are removed; whatever was entered via New PO Entry on launch day stays as the live/active order.** `createdSeed` = imported (remove); no marker = live entry (keep). Lines on the import copy that aren't on the new copy were almost always DELIVERED pre-launch (their packing records were purged, so the system shows them as "needs" but they actually shipped).
- RESOLVED:
  - **DLR-2605-0001** ✓ — 4 extra products were delivered pre-launch; Tornado-only new copy is correct. Remove import.
  - **1821412156 (Rudolf)** ✓ — Jackpot + Harbor Foliar delivered pre-launch. Remove import, keep new.
- RESOLVED (Maxim, 2026-06-17): **22032** new NPK 2,000 correct; **22033** new Enroot 7,000 keep. Remove both imports.
  - **21775** still glance-check: new Max Amino 300 vs import 900.
  - NOTE "Ordered 73,600" on 22032 = the import total (NPK 1,000); correct new total = 74,600. Should self-correct when import removed; if it shows on the NEW copy, it's a sum bug to fix — Tahir to confirm screen.
- **SAFETY RULE before deleting ANY import copy (Tahir):** flag any PO that has live production/packing/PR/shipment against it; never delete real work. Per-copy signal = line `packed`/`produced` > 0 (seed never sets `packed`, so `packed>0` on an import copy = someone packed into the wrong copy post-launch). `delivered>0` alone = pre-launch noise (expected). packingLog/shipments key off PO# (shared by both copies) so can't pin a copy — use line fields. Run the read-only flag snippet (in chat 2026-06-17) before the removal pass; if any import shows packed/produced, move that work to the live copy first.
  - Clean identical pairs (safe to drop import): 21301, 21630, 4204003087, 6595010236, 7500003652, VG-2605-0002, DLR-2606-0001.
- SAFETY-CHECK RESULT (2026-06-17, ran flag snippet): **all 13 import duplicates are SAFE to delete — no live post-launch work on any of them.** Every flagged import line shows packed==produced==delivered (seed/pre-launch signature; live packing would show packed>delivered). Post-launch packing on 21630/22032/22033 is `packingLog`-on-PO# with NO import line work → it belongs to the NEW copies (shared PO#).
- ALSO FOUND — ~8 imported orders with NO new twin (pre-launch fully-delivered history): 6595010235 (Enrich), 6595010360 (Naya S Urea 120,525), 260300001 (Humi Cash), 4204003000 (Ferti K Foliar), 4204003240 (Ferti Huma Pellet), P00206 (Kisan), VG-2605-0001 (11 products incl. discontinued V-Boron Liquid), 2026-00358 (BKK). These are the "imported, no twin" set — the OPEN SCOPE decision: remove (clean slate) vs keep (delivered history).
- CASCADE: imported orders carry many imported shipments (6595010236→11, 6595010360→12, VG-2605-0001→11). Removal must take orders + their imported shipments together (snapshot-first) or shipments orphan. NOTE near-but-distinct PO#s (6595010235 vs …236; 4204003000/…087/…240; VG-2605-0001 vs …0002) are DIFFERENT orders, NOT duplicates — leave alone.
- OPEN SCOPE: rule implies ALL imported (`createdSeed`) orders go, not just the 13 duplicated. Confirm whether imported orders with NO new-entry twin (pre-launch delivered history) should also be removed, or kept for dashboard history.
- INTERIM packing guidance to team: pack into the ✅ KEEP copy (the "needs" number matching the recv-2026-06-01 order). For 6595010236 that is "needs 221917".

---

## 4) BACKLOG (later)

- Phase 2b: monthly-budget data model + Master Data UI (#15).
- #18 harden concurrent-save merge (don't duplicate freshly-packed lots) — note the `_NNNN` order ids may be a merge artifact; check.
- #19 align Ready-to-ship columns across PO cards.
- ~~Set MOP Granular cost (currently 0, flagged).~~ **DROPPED 2026-07-28 — no-cost charter (system does not manage cost).**
- Product master single source of truth: `E:\VAN Platform\VAN-Product-Master-FINAL.csv` (Tahir editing Owner/Client cols).

---

## 5) STANDING CONSTRAINTS

- **See `MODELING-GROUND-RULES.md` (permanent).** Modeling not pushing; NO master-data change without Tahir's explicit approval (ask first); no false alerts / My Actions noise / data overwrite; new computed features are read-only by default.
- No push unless sure it won't cause new trouble; no new bug / incorrect push.
- Never hurt open orders, production, shipment, QC, or master data.
- Snapshot the DB before any **data** change (code-only pushes don't touch DB).
- Never connect to the live DB with credentials. Claude cannot push — Tahir pushes via GitHub Desktop.
- Don't invent recipe ratios or costs; flag anything unverified.
- NOTE: the bash sandbox CANNOT reach `E:\VAN Platform\VAN-OP` — use Read/Write/Edit/Grep on the host path; sandbox-test logic in isolation only.

---

## Session 2026-06-22 — UI redesign, Production Center, dynamic roles, consolidated Dashboard

All changes were **render/layout only — no business logic, master data, flows, or access model changed** unless noted. Each edited via shell Python (assert count==1 + `/tmp` backup) → `node --check` all `<script>` blocks → runtime smoke → Tahir pushes via GitHub Desktop → verified live read-only (browser, no `save()` fired). App is **live with active users**; verification never mutated data.

**5-screen redesign (prototypes consumed, then built as deltas):**
- **My Actions** — per-row mini 7-step stepper; Group-by toggle (Priority / By stage / By role). Existing chips/role-bar/drawer/handlers untouched.
- **PO Tracker** — Matrix is now the PO × 7-stage ✓/●/· grid (`t2matrix` wired); PO drawer has a line×stage matrix; "Open in {owner}" deep-link (`BUCKET_SCREEN`→`setScreen`).
- **Lab QC** — 4-KPI strip + By status / My step / By product group-by (`qcGroup`). COA chain untouched.
- **Pre-shipment QA** — 4-KPI strip (incl. No-batch# blocked) + By status / PO / product group-by (`qaGroup`) + Cleared group. Quantity-true engine untouched.
- **Shipments** — KPI strip; two-column Ready | Shipped&closed board; **live shipNo preview** in record modal; **shipNo column** in log. DC rule already built: `shipNo = MMDDYY + 3-digit serial + DC`, DC single-use, **recording = delivered** (Dispatched≡Delivered; the dead In-transit/Mark-delivered UI was removed).

**Production Center** — global **"+ Open batch" modal** (Against a PO / Bulk → stock) on all 3 views (Floor/Output/Lifecycle), reuses `openBatch` verbatim; Floor sub-views Lanes/Board/Table; Lifecycle Batch master→detail stepper + Lots/Quality/Reconcile tabs. **Open-for-production picker tightened** to lines with `produced < ordered`. **Lanes** redesigned to compact `laneCard` (≈240px, fills the row; click → Lifecycle detail; quick action per stage).

**Dynamic roles** — Stage 1 (`seedRolesV1` → `masters.roles` objects + `rolesList()`; repointed user dropdowns + matrix columns; behaviorally identical) and **Stage 3** (Admin → "Roles" card: add/rename/archive, COO-only, audited; built-ins locked; custom roles auto-locked from admin/users/datafix; access granted via the matrix). **Stage 2 (owners[]→matrix refactor) is PARKED — build only on concrete need.** Access matrix UX: sticky Screen column + header; `amxCycle` updates the clicked cell in place (no re-render, no scroll jump).

**Dashboard — consolidated control center** (`screenDash` now tabbed; old exec/ops split replaced). Tabs: **Performance** (existing exec dashboard), **Sales & Budget**, **Production**, **Quality**, **Shipments**, **Supply Chain (RM/PR)**. Auto-selects the signed-in role's tab; deep-linking question-cards with per-role **"Your action"** highlight (`_DQOWN` map; COO sees none); small CSS trend charts (`_dbars`/`_trail7`); "Where orders are sitting" stage bar. Read-only (`execMetrics`/`floorKpis`/etc.).

**Sales & Budget folded into the Dashboard** — `screenBudget` → `budgetHtml()` rendered by the dashboard Sales tab; standalone removed from sidebar (`vis` hides `budget`); `screenBudget` redirects to the tab; **access gate preserved** (tab shows only for roles with `budget` access — Lab Rep/AQCM/QCM/QA Inspector/Supply Chain Officer are None; invoice-price action stays COO/CFO). Matrix row relabeled **"Sales & Budget (dashboard)"** (still the single control point in Admin → Access control).

**Declutter** — removed the 9 explanatory "tip" banners from screens (My Actions, Lab QC, Pre-shipment QA, Shipments, Admin, New PO Entry, Dealer Master, Reports, Users). Kept the Instructions page header, the Data Fix state banner, and the Sales "Set invoice prices" button. **Instructions rewritten** to match the current app (Production Center + Open-batch modal, quantity-true QA before shipping, DC→shipNo, record=delivered, dynamic Roles, Dashboard).

**Docs in `E:\VAN Platform\`:** added `VAN-O2S-5Screen-Redesign-Gap-Analysis-2026-06-22.md`; `VAN-O2S-Plan-Dynamic-Roles-Control-Center.md` updated (Stage 1/3 done, Stage 2 on-hold).

**Open roadmap (not started):**
- ~~**Raw-material costs missing/zero**: Sulfuric Acid, MOP Granular — need real values from Tahir; blocks accurate product costing.~~ **DROPPED 2026-07-28 — no-cost charter (system does not manage cost; product costing out of scope).**
- **Relational DB + API** (design doc exists) — staged, off-prod first.
- **Dynamic roles Stage 2** (owners[]→matrix) — parked.
- Custom roles **Supply Chain Officer** and **Finance** exist; grant their screen access via the matrix.

**Prototype source files** (the 5 redesign zips + the Production Center kit in `E:\VAN Platform\Production Center Handoff\`) were **consumed and removed at end of this session** — superseded by the live app + the gap-analysis doc.

---

## 2026-08-17 · PD + PLATFORM · pre-launch fixes applied

**Module:** PD, and PLATFORM (the patches cross the boundary — `server.js` sign-in and
error handling, `launcher.html` escaping and role labels, `render.yaml`). Flagged and
authorised before applying.

**Branch:** `prelaunch-fixes`, cut from `df3ce60`. **NOT committed, NOT pushed.**
Review the diff in GitHub Desktop and commit there.

**Applied, in this order:**
1. `pd/reviews/VAN_PD_fixpack.patch` — 13 pre-launch faults (A1, A2, B1, B2, B5, C1, C2,
   C3, C5, C8, D10, D12, E9)
2. `pd/reviews/VAN_PD_02_intake.patch` — idea form to 3 fields, draft saving, calmer
   duplicate check, drop box linked from Home (D1–D5)
3. `pd/reviews/VAN_PD_03_queues.patch` — G3–G6 into My Work, Agronomy trial lifecycle,
   Production feasibility queue, next step on the Board (D6, D7, D9)

**Also changed:** `render.yaml` — `plan: free` → `plan: starter`, added the `disk` block
and `PD_LIBRARY_DIR`. Backup at `render.yaml.bak`. `.gitignore` — added `~$*`.
Untracked the stray Word lock file.

**Verified:** all 21 fix markers present; gate-order, blank-record and login-throttle
guards confirmed by their user-facing text; `server.js`, `pd-routes.js`, `pd-lib.js` and
both inline scripts parse. The four patched files are byte-for-byte identical (sha256)
to the build that was booted against MariaDB and driven through a browser as each role.

**Still to do before anyone signs in:**
- Change every seeded password. Confirm `van@2026` is not live, especially on `admin`.
- Confirm the Render instance really is Starter, and that a disk is attached at `/var/data`.
- Confirm `SESSION_SECRET` is set to a fixed value.

**Next:** notification layer (one G1-decision email to the submitter, plus a daily My Work
digest — no other events). Blocked on the mail transport decision. Then the DAP-parity
calculation, blocked on VAN margin + freight + dealer margin. NP 5-40 seeding deferred.

**Note:** commit `df3ce60 "FIXES ON PD"` added review documents only — no code changed in it.

---

## 2026-08-21 · O2S · fault register, spec pack, and the first safe fixes

**Module:** O2S only. No PD file, no `pd/` path, no `/api/pd/*` route, `launcher.html`
or auth block was opened. The working tree already held uncommitted PD work
(`OP-HANDOFF.md`, `docs/pd-model/*`); none of it was touched.

**Branch:** `main` @ `ab23747`. **NOT committed, NOT pushed.** Review in GitHub Desktop.

### Why this session happened

Tahir raised five problems on a system that is now live with real orders and a real
team: (1) the print price is captured but invisible downstream, (2) fields are too
small to read what is being typed, (3) nothing shows every record attached to a PO in
one place, (4) there is no standard way to correct a record, (5) people are entering
work late and in bulk, which the system cannot detect.

All five were confirmed by reading `o2s/o2s.html` before anything was changed.

### New — `docs/o2s/`

| File | What it is |
|---|---|
| `README.md` | Index, module boundary, and the five original intents restated as acceptance tests with an honest status against each |
| `FAULT-REGISTER.md` | The five faults with file/line evidence, severity, business cost, and a suggested order of work |
| `UI-FIELD-AUDIT.md` | All 167 labelled controls, the pixel arithmetic explaining why text is hidden, and nine sizing rules (R1–R9) |
| `SPEC-01-PRICE-VISIBILITY.md` | Six rules making the print price visible and verifiable end-to-end |
| `SPEC-02-PO-DOSSIER.md` | One page per PO line holding every record and trail. Spine = PO line, batch # is an equal entry point |
| `SPEC-03-EDIT-STANDARD.md` | AMEND / REVERSE / SUPERSEDE — one correction path for every record type |
| `SPEC-04-REALTIME-DISCIPLINE.md` | `actualDate` + `recordedAt` on every event, entry-lag dashboard, N-day lock with Plant Manager authority |

### Changed — `o2s/o2s.html` (+141 lines, −16, all replaced in place)

**CSS fix pack**, one delimited block before `</style>`, purely additive:

- R4 · `.fld select{text-overflow:clip}` — dropdowns no longer truncate the selected value
- R6 · `input[type=date]{min-width:150px}` — 23 date fields stop clipping
- R5 · `.fld{justify-content:flex-end}` — wrapped labels no longer push their input out of row
- R2 · `.formgrid` → `repeat(auto-fit,minmax(220px,1fr))` — a field is never below 220px
- R1 · `.modal` grows by field count via `:has()` — 580 / 800 / 1040px, no JS, no class plumbing
- R3 · global `textarea` sizing + `.fld-long` full-width wrapper
- `.mrp` chip styling for the print price

**11 single-line inputs became textareas** (there were zero textareas in the app before
this): Data Fix backfill reason, Data Fix correction reason, shift note, batch-close
variance note, QA lot remarks, shipment remarks, pack-inspection remarks, dispatch
remarks, dispatch QA remarks, multi-PO truck remarks, delivery reference/note.

**Print price made visible** — new pure-read helpers `poLineFor` / `poPrintPrice` /
`mrpTag` / `mrpCheckHtml` / `_tx`, rendered in:

- Pre-shipment QA lot inspection — a check panel showing the PO price against the price
  recorded at packing, plus batch #, mfg and expiry; flags a mismatch in red
- Dispatch QA — the MRP per product on the truck
- Pack inspection — the MRP for the line
- PO Tracker order drawer — the MRP on every product line
- Load-a-truck modal — the MRP beside each product

**Deliberately NOT changed** (riskier, specified but not implemented): the write-back at
`doPack` / `doProdQty` / `doDivert` where a packer's typed number silently becomes the
PO's print price (SPEC-01 rule 1); the QA checklist price item (SPEC-01 rule 3); the
10 `prompt()` calls (UI audit rule R7).

### Verified

- `node --check` on all five inline script blocks — pass, before and after
- Headless Chromium load — zero page errors, zero console errors beyond the expected
  offline `/api/*` and CDN failures
- Functional: MRP renders in all five places; matching price shows a green confirmation;
  a mismatched price shows the red DOES-NOT-MATCH warning; a missing PO price shows
  "not set on the PO"; `co_reason` is a `TEXTAREA` and reads back correctly through the
  same `getElementById().value` path `dfSubmitCorrect` uses
- Layout at 390 / 1024 / 1920px — no horizontal overflow at any width. The dispatch
  modal goes 580px → 1040px, its fields 170px → 232px, its date field 170px → 232px
- Line endings unchanged (LF, 0 CRLF). Only the 16 intended lines were removed

### Next

In the order the fault register recommends: finish SPEC-01 (the write-back and the QA
checklist), then SPEC-04 step 1 — `actualDate` / `recordedAt` on the four events that
currently force today's date (COA approval, packing run, lot QA, dispatch QA). Nothing
downstream is trustworthy until that lands.

**Open decision for Tahir:** sequence validation was offered and not selected. The
recommendation stands in SPEC-04 — build the six rules as warnings first, run for a
month, then promote the ones that prove correct. Not built unless you say so.

**Out of module:** QA signs inspections with a self-typed name on a shared login. That
needs individual QA logins in `auth_users` / `user_module_roles` — a `MODULE: PLATFORM`
job, recorded in SPEC-04 but not actionable here.

**Security:** nothing new found this session; no entry added to the register.

### Correction, same day — a print price is NOT compulsory

Tahir flagged it before pushing: some clients do not want any price on the bag.
The first cut of the price chip showed red **MRP not set** whenever `printPrice`
was 0, which would have been a standing false alarm on every line of those
customers — the exact thing `MODELING-GROUND-RULES.md` forbids. It would also
have fired on every PO from the opening-import, which hard-codes `printPrice:0`
(L2170).

The decision was already being stored and simply never read: `order.printOnPack`,
written at PO entry (L2544 → L2681). New `printPolicy()` / `printPolicyOL()`
resolve four states, and `mrpTag()` / `mrpCheckHtml()` were rewritten around them:

| State | Condition | Reads as |
|---|---|---|
| priced | `printOnPack` true, price set | `MRP 1,250 /pack` — amber |
| no-print | `printOnPack` false | `No price on pack` — **grey, calm** |
| missing | `printOnPack` true, no price | `MRP not set` — red. The only real gap |
| not specified | no flag (legacy + imported POs) | `Print price not specified` — grey |

The QA check **inverts** for a no-print PO: the failure there is a price
appearing on a bag that should carry none, and `mrpCheckHtml` flags that red.
All seven state combinations verified in a headless browser; no false reds.

`SPEC-01` gained Rule 0 and was rewritten throughout — the "every line must have
a price" assumption ran through the whole first draft. Rule 1 softened from
"block packing" to "warn and offer to ask the KAM", because blocking the floor
over an empty office field moves the cost to the wrong person.

### Also added — `docs/o2s/`

- `TEAM-NOTE-2026-08-21.md` — one page for the team: the three changes, the four
  price states, and advance notice of the two-date change, framed as "tell me now
  if you can't record same-day" rather than a new rule
- `SOP-PRE-SHIPMENT-INSPECTION.md` — the QA inspector's procedure: the price
  check in all four states (including the inverse check), batch, mfg/expiry,
  when to fail, what to write in remarks, and the standing caveat that the
  inspection date is still stamped as today

Both are drafts for Tahir to adjust and circulate. Markdown, in the repo. Can be
turned into Word or a printable PDF on request.

---

## 2026-08-21 (later) · O2S · team feedback round

**Module:** O2S. No PD path touched. **NOT pushed.**

Three items came back from the team within a day of the first change going live.

### Majid — "a formal correction mechanism for data-entry mistakes"

Fault 4, arrived at independently without having seen the register. No analysis
to add; `SPEC-03-EDIT-STANDARD.md` already covers it. What changes is priority —
a fault two people raise unprompted in one week costs more than the register
credited it with.

### Fahim — "Gate pass approval is assigned to Plant Manager but it does not
appear in my actions"

Confirmed, and it was five faults not one. `actionItems()` had **no entry for
any step after "Ship"** — verified by listing every `act:` target in the
function. Missing: `startLoading`, `issueGatePass`, `approveRelease`,
`approveDC`, `openDeliveryConfirm`.

The moment a truck was planned it vanished from every worklist. Worse for the
Plant Manager than anyone: the Shipments screen is `owners:['Supply Chain']`, so
he gets view access by default and had to hunt on someone else's screen for a
button nothing told him was waiting. He had **two** action item types in the
whole system before this.

This revises Fault 5. People were not ignoring the Action Center for the second
half of the shipment process — the Action Center was not telling them.

All five items added with escalation thresholds ('Load', 'Gate Pass', 'Release',
'Approve DC', 'Confirm delivery'), plus `ACT_EMOJI`, `acTypeColor` and
`acStageOf` entries. A loaded truck waiting on release escalates to COO after
1 day. **The release item stays hidden while the shipment's pre-shipment
inspection is pending**, so the PM is never invited to release ahead of QA.

### Fahim — "mobile friendly version please", then Tahir — "still too dense"

Two passes, both measured rather than eyeballed.

**Pass 1 — the page slid sideways.** 7 of 12 screens overflowed horizontally at
390px; PO Tracker worst at 204px. Found by hiding each element and re-measuring.
Three causes: `.tbttl` ships as `flex:0 0 auto` so the top bar physically could
not shrink and a long screen title held the page open (`min-width:0` alone did
**not** fix this — the shrink factor was the real culprit and took a second
pass); `.axn-bd` had no `min-width:0` so a long client name forced every Action
Center card wide; `table.t2mtx` had no scroll container. Fixed with CSS plus a
`:has()` scroll container.

**Pass 2 — density.** 659px of chrome before the first task on an 844px screen
(78%). Stat cards were 360px stacked one per row; filters 160px stacked one per
row. Now 375px (44%) — stat cards 2-up at 129px, search on its own row with the
dropdowns two-up, tighter padding and type scale. Three tasks now visible on the
first screen; before, none were.

Built three dropdowns per row first — it clipped their selected values to
"Group: ..." which is Fault 2 again, so it went back to two per row at a cost of
39px.

**The iOS zoom floor now costs only iOS.** `input,select,textarea{font-size:16px}`
below 820px is correct for iOS Safari (below 16px it zooms on focus) but Android
was paying for it too. Scoped with `@supports (-webkit-touch-callout:none)`;
Android gets 13.5px, iOS keeps 16px, failed detection falls back to today.

### Verified

- `node --check` on all five script blocks — pass
- All 12 screens: **0px horizontal overflow at 390px**, unchanged at 1600px
- Truck-pipeline items assert-tested across six states (planned / loading no
  gate pass / loading with gate pass / QA pending / in transit / DC pending) for
  both Supply Chain and Plant Manager
- Desktop regression: titles, subtitles and the 1040px dispatch modal all intact

### Fault 8 — NEW, open, needs Tahir's decision

Found while fixing Fahim's bug, not reported by anyone. **`approveRelease()`
never checks the shipment-level pre-shipment inspection.** It checks role, stage
and gate pass only.

Material on the truck has always passed *lot-level* QA (`readyLinesFor()` only
offers inspected & cleared quantity). What can be skipped is the second,
truck-level check. `markDelivered` and `openDeliveryConfirm` both refuse when
`qa === 'pending'` — release is the one step that does not. Fault 4 again: the
same rule applied in two places and not a third.

Adding the check is ~4 lines. It would stop trucks that today would go, and
given the backlog of unrecorded inspections it may block real ones on the day it
deploys. **Recorded, not fixed — Tahir's call.** Interim mitigation: the Action
Center release item already stays hidden while inspection is pending.

### Next

Unchanged: the "no print/no-print decision recorded" pre-flight count, then
SPEC-04 step 1 (actualDate / recordedAt). Majid's message moves SPEC-03 up
behind those.

---

## 2026-08-21 (session close) · O2S · price authority, then dates

**Module:** O2S throughout. No `pd/` path, no `/api/pd/*`, no `launcher.html`,
no auth block. **Pushed by Tahir as `adcc491` "Dates in O2S"**, working tree
clean, in sync with origin.

Order of work this session, after the first batch: team feedback → desktop
audit → price authority → dates. Tahir's instruction was "settle issues one by
one", and the Dashboard was explicitly deferred — it needs its purpose
rethought, not its CSS corrected.

### Fault 10 — a PO that prints no price could not be packed at all

The sharpest live bug of the session, found while implementing SPEC-01 rule 1.

All three packing paths carried `if(!(ppx>0)){toast('Enter the price…');return;}`.
A positive print price was **mandatory to pack anything**, so for a client who
does not want a price on the bag the operator had to invent a number — and the
next line wrote that invented number back onto the PO line, where it became
indistinguishable from one the KAM had set.

Packing was authoring commercial data, on exactly the customers who had asked
for none.

Rebuilt as one shared step across all three paths (`packPriceBlock` /
`packPriceGate` / `packPriceRecord`), behaving by the four states of SPEC-01
Rule 0. The lot now stores `poPrintPrice` (what the PO authorised) and
`printedPrice` (what went on the bag) separately, with `priceMismatch` when they
differ. `priceVerifiedBy` is the person's name — it was storing `state.role`,
the string `"Production"`, which names a job you cannot go back and question.

Six cases verified in a browser. The two that matter: a PO with no price and a
legacy PO both pack correctly and **leave `l.printPrice` unset**. The write-back
is gone.

### Fault 9 — the desktop app

**Honest correction recorded in the register: I could not reproduce text
escaping the browser window.** Every screen measures 0px horizontal overflow at
1024 / 1280 / 1366 / 1600 / 1920 with a 40-PO production-shaped fixture.

What was found looks identical to a user and is worse: **`PKR 625,000,00(` — a
nine-figure budget figure losing its last digit**, silently, inside a card with
`overflow:hidden`. Three of four tiles on Sales & Budget. A CFO was being shown
a number missing a digit with nothing to indicate it.

Fixed by making the value size itself to its card (`container-type:inline-size`
+ `min(23px,10.5cqi)`) rather than the card being asked to fit the value.

This only reproduced once the fixture carried real data. The tidy one-PO fixture
passed everything, which is why it was missed. **Test with production-shaped
data or do not claim a layout is clean.**

Empty space measured and left alone: Dashboard and Shipments show **0% content**
in the first screen at 1366×768; Dashboard has 1,707px of chrome before any data
row. Deferred at Tahir's instruction.

### Fault 5 / SPEC-04 step 1 — actual date vs recorded date  ← the main build

`actualDate` / `recordedAt` / `recordedBy` now travel with every event that
previously forced today's date. **`date` is still written, set to `actualDate`**,
which is what kept the change small — every existing reader picks up the true
date without being touched.

Wired into: `doPack`, `submitProdQty`, divert-pack, `lotQASubmit`,
`dispQASubmit`, `savePackInspect`. COA approval gets `recordedAt`/`recordedBy`
only — a signature's date is the moment of signing, and letting someone backdate
their own sign-off weakens the record; that belongs in SPEC-03.

`evDateField()` shows the late-entry reason box **only** past the threshold, so
same-day entry stays one field. `evDateGate()` refuses a future date outright
and a late entry with no reason.

Thresholds in `state.masters.entryThresholds`, COO-tunable, defaults in SPEC-04.

**Legacy records: `evLag()` returns null and the badge reads "entry date not
tracked". It must never render 0.** Zero lag on unverified records would
manufacture a clean history.

Five new **Reports → Anomalies** rows make the pattern countable now, before the
dashboard exists — including **"Inspection dated after dispatch"**, which is
Tahir's original complaint detected directly: *truck left the 14th, inspection
dated the 19th*.

Six cases verified in a browser, including the blocked-without-a-reason and
future-date paths.

### Also this session

- `actionItems()` gained the five missing truck-pipeline items (Fahim's gate-pass
  report — see the earlier entry). Titles later shortened after they measured
  clipping 474px of themselves at 1024px
- Mobile: 7 of 12 screens were pushing the page sideways; then a density pass
  took My Actions from 659px of chrome before the first task down to 375px
- Two anomaly rows count the print-price backlog: **"No print/no-print decision"**
  (every PO from the opening import is in this state) and **"No print price"**

### What to watch after this deploys

1. **Escalation numbers will get worse before they get better.** `acEscalation`
   now measures from true dates instead of dates that were themselves entered
   late. That is the correction working. Tell the team before they see it.
2. Pull the two print-price anomaly counts. That number decides whether anything
   on price should ever block.
3. Let the late-entry rows run **at least four weeks** before considering the
   lock. Locking against an unmeasured baseline means nobody can tell afterwards
   whether it helped or whether people simply stopped recording.

### Next, in order

1. SPEC-04 step 2 — the same three fields on the remaining events (shift output,
   RM/PR, gate release), then steps 5–6, the entry-lag dashboard
2. SPEC-03 — the correction path. Raised independently by Majid and by Tahir
3. SPEC-02 — the PO dossier. Pure read, cannot break anything, wants honest
   dates underneath it — which it now has

### Open, needing Tahir

- **Fault 8** — `approveRelease()` never checks the shipment-level inspection.
  ~4 lines to add; would stop trucks that today would go. Unfixed by choice
- **Fault 9c** — which of the Dashboard's three stacked banners earns its place
- **Sequence validation** — five of the six rules still unbuilt; the sixth
  ("inspection dated after dispatch") now runs as a report rather than a block

---

## 2026-08-21 (late) — MODULE: O2S — the correction path (SPEC-03)

**Tahir:** *"a universal path and strategy to edit and correct with a log of who
corrected and when… close all the multiple paths and keep one which best suits a
system which has to become an ERP 2–3 years down the line."*

Files touched: `o2s/o2s.html`, `docs/o2s/SPEC-03-EDIT-STANDARD.md`.
Nothing in `pd/`, `server.js`, `launcher.html` or the auth block.

### The finding that shaped the build

A "correction" in O2S was **a sentence**, not a record. `reconLog()` prefixed
`RECONCILE:` onto free text in the action log — 14 call sites, no structure.
Corrections could not be counted, filtered by person, or replayed. `state.audit`
stamped `user: state.role` — the job, not the person.

"Eight editors" was the symptom. The cause was that a correction was not a record.

### Built

- `state.corrections[]` — append-only ledger. `recordCorrection()` writes
  `{id, at, by, byUser, byRole, op, entityType, entityId, entityLabel,
  changes[], reasonCode, reason, cascade[]}`. Still writes `actionLog`/`audit`
  so nothing that reads those goes blind
- `CORRECT_ENTITY` registry — order, orderLine, packingLot, shipment, batch.
  Each entry carries find/name/amend/reverse/fields/cascade/blocks/doReverse.
  **This is the ERP-scaling property**: a new record type is a registry entry,
  not a ninth bespoke editor
- One modal — `openCorrect` / `renderCorrect` / `applyCorrect`. AMEND + REVERSE
- `correctAllowed()` uses **`hardRole()`, never `canEdit()`** (2026-07-30
  incident: a screen-level Edit grant silently unlocked approval steps)
- `CORRECT_REASONS` codes, so corrections become countable
- Reports → **Corrections** register; reversed rows render struck through
- `reconCorrection()` — bridge so the 14 legacy `reconLog()` sites can move onto
  the ledger one at a time. **None moved yet.** Data Fix first

### Verified in a browser

KAM blocked on a packing run; Production blocked on a PO line. AMEND records
person/account/role/before→after. No reason blocked; one-word reason blocked.
REVERSE warned `["Batch B-88 packed 1,200 → 0 Kg", "PO-1 · Zorro packed
1,200 → 0 Kg", "Voids the inspection dated 2026-08-09 (PASS)"]` then applied all
three. REVERSE refused when a shipment referenced the lot. 7 regression suites,
23 layout checks, `node --check` on all 5 script blocks.

### Bug found while building — focus destroyed on `oninput`

Re-rendering a form on `oninput` destroys and rebuilds the input. Typing
`ZR-2026-0099` landed as **`ZR-42Z`**. Six places: four mine from the same day
(correction reason/note, bags checked, defects, packing price), two pre-existing
(`rmRcvForm.qty`, `rmForm.canMake`). Pattern now: **store on `oninput`,
re-render on `onchange`.**

> **Rule, recorded:** every assertion test passed, because tests set values
> directly instead of typing them. Only a browser typing character by character
> found it. Same family as the too-clean-fixture rule from earlier today.

### Not built — do not assume otherwise

- **SUPERSEDE.** An approved COA and a passed inspection still cannot be
  replaced with a corrected revision. Both need a revision number on the record
  and both print — a larger change than AMEND or REVERSE
- The 14 legacy `reconLog()` sites still bypass the ledger

### Next, in order

1. Move Data Fix onto `reconCorrection()`, then the remaining 13 sites
2. SUPERSEDE — revision numbers on COA and inspection, both printing
3. SPEC-02 — the PO dossier (PO line spine, batch # as equal entry point)
4. SPEC-04 steps 2, 5, 6, 9, 10

**Ready to push, not pushed.**

---

## 2026-08-21 (later) — MODULE: O2S — paths closed + SUPERSEDE

Continues the entry above. Tahir: *"close all and keep one."* That pass built
the one path; this one shuts the others.

Files: `o2s/o2s.html`, `docs/o2s/SPEC-03-EDIT-STANDARD.md`. Nothing in `pd/`,
`server.js`, `launcher.html` or the auth block.

### The distinction that unlocked it

**Filling a blank is ENTRY. Changing a value is a CORRECTION.** Eight editors
existed partly because those two acts had never been separated. `isCorrection()`
now asks it the same way everywhere; 0 counts as blank.

Without this, closing the paths meant making a CFO write 136 reasons to fill 136
empty price boxes — a control that would have been worked around inside a week.

### All 14 reconLog() sites moved

- 6 Data Fix / import creations → **BACKFILL** (new fourth op) with `eventDate`
- 5 Data Fix "correct a PO" → **AMEND**, one entry per record, reason code required
- Bulk print-on-pack → **entry**, not a correction (every PO it touches had no answer)
- Bulk invoice pricing → fills blanks, **refuses** to overwrite an existing price
- Inline invoice price (Sales & Budget) → fills blanks, **opens the modal** otherwise

`reconLog()` has **zero call sites**; kept as a net that files anything reaching
it as a `legacy` register entry. Do not add new calls.

### Field-level authority

`correctFieldOK()` — a field's own role list wins, else the record's. Without it
the CFO, routed to the modal for an invoice price, would have been told they had
no authority over the one number that is theirs. A CFO opening a PO line sees
one box.

`correctAllowed()` now returns false for an **empty** role list — nobody,
including the COO. That is how a signed COA is declared un-amendable rather than
merely discouraged.

### SUPERSEDE

- **COA** (QCM/COO) — Rev N archived + stamped SUPERSEDED, Rev N+1 created as a
  draft, lab chain re-runs, material not packable until re-approved. Both print;
  the replaced one carries a red NO LONGER VALID band. Warns when material has
  already shipped that the customer's copy is stale
- **Inspection** (QA Inspector/Plant Manager/COO) — withdraw; clearance returned
  to the lots, `qcPass` cleared, still on file and still prints stamped WITHDRAWN
- New card: **Pre-shipment QA → Cleared → Inspections on file.** There had been
  no screen anywhere listing inspections themselves

### Live-data facts, measured before building (Fault 11 discipline)

| | |
|---|---|
| Inspections with a resolving `batches[].lotId` | **113 / 113** |
| Packing lots with a resolving `baseBatchId` | **153 / 153** |
| Approved COAs on `lots[].coa` / on `batch.coa` | **71 / 0** |
| Approved COAs carrying a `rev` field | **0** — must default to 0 |
| Passed inspections **blocked** by shipped material | **93 of 113** |
| Passed inspections free to withdraw | **20** |

The refusal is the common case, not the edge case. Worth knowing before anyone
reports the feature as broken.

### Two defects found by CLICKING, not calling

1. **Modal visible but unclickable.** `#coaFS` is z-index 300; `.modal-bg` was
   60. A supersede opened from the certificate produced a dialogue that could be
   read and not typed into. Every assertion test passed — assertions call
   functions. Backdrop now 320, and `openCorrect()` closes `coaFS` so a stale
   APPROVED certificate is not left showing underneath.
2. **A green button that could only refuse.** Blocked reversals/supersedes still
   offered the action button and two required reason fields, then toasted a
   refusal. Both now suppressed.

> **Rule, reinforced twice in one day:** assertion tests set values and call
> functions. They cannot find focus loss, z-index capture, or a button that is
> present but dead. Click through at least one full path in a real browser
> before calling anything done.

### Verified

149 checks — 109 assertions + 40 click-through steps driven only through the
interface, on a fixture rebuilt to the live system's measured shape (above).
Layout at 390/820/1440 px: no page overflow, table scrolls in its own container.
`node --check` on all 5 script blocks. All nine roles render every permitted
screen with zero console errors.

### Still open

- **Data Fix bypasses the per-record authority table.** It edits many lines at
  once and is COO tooling; the screen now says so in amber. Changing its gate on
  a live system is Tahir's decision, not a side-effect
- A truck loaded before a COA supersede is not recalled — it cannot be. The
  system tells you the customer's copy is stale; acting on it is a person's job
- SPEC-02 (PO dossier) — the last untouched problem from the opening brief
- SPEC-04 steps 2, 5, 6, 9, 10
- The three human tasks in `docs/o2s/HANDOVER-CHECKLIST.md` still block three
  controls. Item 1 (print-on-pack for 44 POs) is the costly one — 136 lines still
  tell the QA inspector nothing

**Ready to push, not pushed.**

---

## 2026-08-21 (evening) — MODULE: O2S — batch identity (SPEC-05)

Plant Manager feedback, relayed by Tahir: the DC prints the wrong batch number,
the focal person should be editable, and *"batch integrity and the link should be
traceable and unbreakable — it's a critical link."*

Files: `o2s/o2s.html`, `docs/o2s/SPEC-05-BATCH-IDENTITY.md`. Nothing in `pd/`,
`server.js`, `launcher.html` or the auth block.

### Measured on live data BEFORE building

| | |
|---|---|
| Packing lots re-batched (pack # ≠ internal #) | **49 / 153** |
| Client batch numbers drawing on several internal batches | **7** (largest 9) |
| Shipment batch rows carrying a lot id | **0 / 176** |
| Inspection batch rows carrying a lot id | **113 / 113** |
| POs with no delivery focal person | **36 / 44** |

Many-to-**many**, not many-to-one: `VU26174` sits under both `VAN6GU001` and
`VAN6GU002`. The packing lot is the join row and already holds a hard
`baseBatchId` — **the model was right; the paperwork and the durability were not.**

### Built

1. **DC packing list rebuilt.** `Batch # (on pack)` leads, `Internal batch` in its
   own column with per-batch quantities. **One printed line per (product × pack
   batch number)** — DC 29 carries Naya S Urea under both `VAN6FU006` and
   `VAN6GU001` with `VU26166` split across them, which two columns cannot express
   on one line without lying. A4 portrait measured: table 688px into 688px usable,
   nothing clipped, one page. **No landscape needed.**
2. **A batch number is an identity, not a value** (Tahir's rule). Pack number and
   internal number: Plant Manager / COO only, **refused** once anything is
   inspected or shipped, with the reason on the disabled box. Production can still
   SET a blank number; CHANGING one reroutes to the correction path.
3. **`lotId` on shipment batch rows** (both dispatch paths) + `linkShipBatchLotsV1`
   backfill that links only unambiguous matches and reports the rest on
   `state._shipLotLink`.
4. **`onAmend` hook on the registry** — correcting a number now propagates to lot
   numbers, the COA, shift entries, production log, packing runs, inspections and
   challan lines, matched by lot id where present and by the old number where not.
   Everything that moved is recorded as the correction's cascade.
5. **Focal person** on every channel at PO Entry (free text + master list), plus a
   per-truck override on the shipment screen. DC uses truck value → PO value.

> **A hole I opened this morning and closed tonight:** the correction path let
> `brandBatchNo` be amended with no propagation and no lock. It would have changed
> the lot and left the COA and every document saying something else.

### Verified — 208 checks, four suites

109 correction assertions · 40 click-through · **28 DC layout + link** ·
**31 batch gate**. The DC suite reproduces DC 69 and DC 29 exactly and asserts the
split, the pairing, the quantities, and the A4 measurement. `node --check` on all
5 script blocks. Nine roles × every permitted screen, zero console errors.

### Open

- `mfgDate`, `expDate`, `printedPrice` are also printed on the bag and are **not**
  locked after shipping the way the batch number now is. Same class of problem —
  needs a decision from Tahir
- The **Gate Pass carries no batch column at all**
- Read `state._shipLotLink` after the first live load. If `ambiguous` or
  `unmatched` is above zero those rows need a human
- Data Fix gate: checked and **there is nothing to change** — `screenDataFix()`
  hard-checks `state.role==='COO'`, immune to the access matrix. But the live
  matrix has a stale `datafix {e:true}` grant for **Production** that does nothing
  today and would become live if that check were ever refactored to
  `screenEditOK()`. Worth clearing in Users & Access
- Still blocking: **44 POs need a print/no-print answer** (136 lines tell QA nothing)

**Ready to push, not pushed.**

---

## 2026-08-21 (evening, cont.) — MODULE: O2S — mfg & expiry as a derived chain

Tahir: *"can we automate the manufacturing and expiry dates like an unbreakable,
unmistakable chain? Where from we pick that data?"*

### The measurement that set the design

| | |
|---|---|
| Bag mfg date equalling the batch opened date | **2 / 153** |
| …equalling the packing date | **10 / 153** |
| …equalling **none of those** | **141 / 153** |
| Commonest single value (`2026-07-01`) | **58 lots** |
| Lots whose expiry was exactly mfg + 2 years | **152 / 153** |
| Pack batch numbers carrying CONFLICTING dates | **14** (`VLNPK26002` had four) |

So mfg was noise and expiry was already automatic — the opposite of the
assumption. And one batch number could mean four different expiry dates on bags
in the market.

### Where manufacturing actually happens — the decisive finding

Tahir asked whether the anchor should be the day production closes a batch.
**It has never happened once: 0 of 69 batches carry `status:'closed'` or a
`closedDate`.** The "Production complete — Close batch" button exists, captures
yield variance and a reason, and has never been pressed. Anchoring to it would
print a blank date on every bag.

**`lots[].date` is populated on 76 of 76 lots.** That is the anchor;
`closedDate` is kept as second preference so nothing changes here when batches
do start being closed.

> Tahir first chose the packing date, then reconsidered and asked whether the
> production chain was stronger. It is — the COA is a statement about the batch,
> so a packing-date anchor leaves certificate and label permanently describing
> different days. He switched. Cost: median **23 days** less apparent shelf life
> (max 51). That is 23 days of real life that had already elapsed.

### Built

```
batchProdDate(b) = lots[].date → closedDate → openedDate
packMfgFor(no)   = EARLIEST batchProdDate across every internal batch feeding
                   this pack batch number
  → MFG DATE     derived, no box
  + shelf life   24m; PRODUCTION may extend 25-36, never shorten, bounded both ends
  → EXPIRY DATE  derived, no box
```

- `syncPackBatchDates()` levels the whole pack batch number after every pack.
  Lots already inspected or shipped are **left alone** and the divergence is
  logged — bags are printed and a certificate is signed against them
- Both date boxes removed from the packing screen; all three packing paths
  (doPack, submitProdQty, divert) derive from the one function
- `mfgDate` and `expDate` now **lock after material moves**, like the batch number

> **The rule that emerged, worth keeping:** Production may correct what they
> RECORDED — quantity, the date they keyed. They may not change what is PRINTED
> ON A BAG. Batch number, mfg and expiry belong to the Plant Manager, and only
> until the material is cleared or shipped.

### Verified — 260 checks, five suites

109 correction · 40 click-through · 28 DC layout+link · 32 batch gate ·
**51 mfg/expiry chain**. Covers month-end arithmetic (31 Jan + 1m = 28 Feb),
the shelf-life band including forced out-of-range values, the anchor falling
back to closedDate, an older internal batch pulling the date back, levelling,
and a shipped lot refusing to be levelled. `node --check` on all 5 blocks.

### Open

- **`printedPrice`** is the only one of the four printed values still amendable
  by Production after shipping. Same class of problem, lower risk
- **Nobody closes batches — 0 of 69.** Worth attention on its own: "production
  complete" is never recorded, yield variance is never captured, and
  `prodCompletedThisMonth()` returns zero every month
- The 14 pack batch numbers with conflicting dates are a record of what was
  printed. They cannot recur; they cannot be corrected either
- Read `state._shipLotLink` after the first live load
- Still blocking: **44 POs need a print/no-print answer**

**Ready to push, not pushed.**

---

## 2026-08-21 (evening, cont. 2) — MODULE: O2S — the historical dates

Tahir: *"so now we resolve it? manufacturing date / expiry, lot etc?"*

**Going forward: yes. Historically: it cannot be, and the numbers say why.**

| Of 153 live packing lots | |
|---|---|
| Free — nothing inspected, nothing shipped | **1** |
| QA-cleared, not yet shipped | 21 |
| Already shipped | **131** |
| Lots whose mfg date differs from the derived date | **66** |
| …of those, correctable now | **1** |
| …frozen because the material has moved | **65** |
| Pack batch numbers still carrying conflicting dates | **14** |

65 of the 66 wrong dates are on bags that have been inspected or have left the
factory. Those bags exist. Rewriting the record would make it disagree with the
physical material — the precise fault the Plant Manager raised — so the levelling
deliberately refuses them.

### So the treatment for the past is visibility, not repair

New anomaly row: **"One batch number, more than one mfg date."** Per pack batch
number, it names every date found, how many packing runs are involved, the
quantity, and whether the lots have moved:

> Batch VLNPK26002 carries 4 different mfg dates (2026-07-01, 2026-07-05,
> 2026-07-07, 2026-08-16) across 10 packing run(s). 9 of them have been cleared
> or shipped — those bags are printed and cannot be corrected.

Where nothing has moved it says the opposite: *"None have moved yet — correcting
the packing runs will level them."* So the row is actionable when action is
possible and honest when it is not.

**Expect 14 rows on the first live load.** That is the backlog, not a fault, and
the count should only ever go down. A NEW row appearing after this deploy means
something has gone wrong that day.

### Verified

**266 checks, five suites** (109 / 40 / 28 / 32 / 57). The new anomaly tests
cover a conflicting number, a clean number that must NOT be reported, the wording
in both the moved and not-moved cases, and the affected quantity.

**Ready to push, not pushed.**

---

## 2026-08-21 (late) — MODULE: O2S — why nobody closes a batch, + the PO register

### Why it never happens — investigated, not guessed

Three causes, all structural:

1. **Nothing ever asked.** 90 items in the Action Center, **not one about
   closing a batch.** Same fault as Fahim's gate pass this morning: people were
   not ignoring a prompt, there was no prompt.
2. **Nothing depends on it.** Packing needs an approved COA, not a closed batch.
   The whole order-to-ship chain runs without ever closing one.
3. **It costs the person and pays them nothing.** The modal says *"no more shift
   output can be added"*, and where yield is short it demands a variance reason
   and **notifies the Plant Manager**. Paperwork plus telling your boss you were
   short, in exchange for nothing. That is an incentive structure working as
   built, not laziness.

### The real scale — smaller than "0 of 69"

| | |
|---|---|
| Real batches | 69 |
| **Finished but still open** | **23** (140,712 Kg) |
| Genuinely still running | 46 |
| Of the 23, needing a human reason | **0 — all are on plan** |
| Oldest finished-but-open | **24 days** |

### On auto-closing — the answer to Tahir's question

**Auto-close is safe exactly where it is worthless, and worthless exactly where
it matters.** The entire value of the close step is `varianceReason` — *why* the
yield was short. Auto-close either skips it (losing the only structured record
of yield loss, permanently) or fires only on zero-variance batches, where there
was nothing to learn anyway.

So: **not automatic.** Instead —

- **`settledBatches()`** — at or above plan, everything packed or reconciled,
  nothing to explain
- **`closeSettledBatches()`** — one click, Production's name on all of them,
  each logged individually, `closedBulk:true` so it is never mistaken for a
  judgement. Refuses anything with a variance
- **`prodSettledStrip()`** — a banner on EVERY Production view, not behind the
  "Ready to close" filter. Hiding the prompt behind a tab you have to find is
  the original fault repeated
- **A real Action Center item per finished batch**, owned by Production, saying
  the quantity, whether it is on plan or short, and how many days it has sat

> **Gotcha for the next session:** `renderProdLifecycle()` is DEAD — `screenProd()`
> builds the desk itself and never calls it. I put the banner there first and it
> silently did not appear. A test caught it. Comment added at the function.

### PO register — Reports → Documents

`printPO()` was reachable from **exactly one** buried button; there was a
document viewer for Delivery Challans and Gate Passes but none for the order
itself. Documents now has two registers: **Purchase orders** and **Delivery
Challans & Gate Passes**. The PO register shows received date, PO, client,
channel, lines, Kg, value, stage, and **whether it has ever been printed** —
`printPO()` now stamps `printedAt` / `printedBy` / `printCount`. Header reads
"N of M have been printed from the system"; expect **0 of 44** on first load.

### Verified — 313 checks, six suites

109 / 40 / 28 / 32 / 57 / **47**. The new suite covers the worklist item in all
four batch states, settled-vs-needs-a-reason, the bulk close by clicking, that a
short batch survives it untouched and still demands its reason, the Plant Manager
notification, and the PO register including the printed stamp and count.

### Open

- `printedPrice` — parked by Tahir
- The 3 batches below plan (HG26025/26/27, short 14,600 / 47,200 / 21,000 Kg)
  are still producing, so no variance reason is due yet. When they finish, the
  new action item will ask for one
- Still blocking: **44 POs need a print/no-print answer**

**Ready to push, not pushed.**

---

## 2026-08-22 (morning) — MODULE: O2S — SPEC-06 was not finished, and the tests were not real

Session opened to *"finish/verify SPEC-06 and get it commit-ready, work the 44
POs."* The verification part turned out to be the whole job.

### First: the handoff and the working tree disagreed

The 21 August entry lists `printedPrice` as **"parked by Tahir."** The working
tree contained a built SPEC-06 and `docs/o2s/SPEC-06-PRICE-ON-PACK.md` dated the
same day. **The handoff was wrong** — it was built, not parked. Corrected here.

### The tests reported on 21 August do not exist

`docs/o2s/SPEC-06` closes with *"376 checks across seven suites, all passing."*
There are **no test files in the repository.** The same is true of the 266 and
313 reported on the two entries before it. Three sessions of verification, none
of it re-runnable, none of it checkable the next morning.

So the first thing built this session was a suite that exists.

### Four defects, all live in the file called finished

| | What it was |
|---|---|
| **1** | **The inspector's price reading was discarded on every save.** `qcVerifyRecord` hung `priceSeen` on an *array*; state saves through `JSON.stringify`, which drops non-index array properties **silently**. On screen it worked. On reload it was gone. The one part of SPEC-06 meant to build evidence over months was recording nothing |
| **2** | **The list answer was unreachable from the edit screen.** Still the old two options; a PO answered `list` opened with nothing selected and could only be changed to yes or no. Its save also set `printOnPack=(nv==='yes')` — which turns a list-price PO into a **no-price** PO and tells packing and QA exactly that |
| **3** | **The NO-price safety confirmation stopped firing.** `entryPrintOn` became a string when the third window was added; `submitPO` still tested `=== false`. `'no' === false` is never true. The guard between a mis-click and a whole PO shipping bare has been dead since the third answer shipped |
| **4** | A price typed under *yes* rides along onto the line after switching to *list* or *no*. Harmless to policy, but read by the "not a real price" anomaly |

Defect 1 is the one that matters. It fails in the direction that looks like
success, which is why a session could report it verified in good faith.

### Also hardened

- **One definition of the backlog.** Reports button, Action Center item and the
  bulk screen each had their own filter — two required an ordered line, one did
  not. They agree on the local snapshot, so nothing looked wrong, but they could
  report different sizes for the same backlog with no way to tell which was
  lying. All three now call `openPrintDecisionPOs()`
- **Evidence showed one price where two existed.** `seen[brand]=price` kept only
  the last. A brand carrying two prices is SPEC-06's central finding and exactly
  the PO where the COO needs to see both. Now shows every distinct price and
  marks the conflict

### On the 44 POs

**I could not verify the number.** `data/state.json` in this repo is a **16 July
snapshot** — 21 orders, all unanswered. The 44 is live-only. What I can say is
that the mechanism to clear them works: 19 checks against the real snapshot cover
the predicate, "set all", the save path, that an answered PO is never overwritten,
and that `list` correctly means a price **is** printed.

**Answering them is still a human decision** and needs the live system. One open
question for Tahir below.

### Verified — 71 checks, two suites, and they are on disk

```
node o2s/tests/spec06.test.js     # 52 passed
node o2s/tests/backlog.test.js    # 19 passed
```

Run from `E:\VAN-OP`, no dependencies. The harness pulls the **real function
source out of `o2s/o2s.html`** by name and runs it sandboxed — no second copy of
the logic, so a passing check passed against the file that ships.
`node --check` clean on all six script blocks.

### Files changed

- `o2s/o2s.html` — ten regions, the four fixes plus the two hardenings
- `docs/o2s/SPEC-06-PRICE-ON-PACK.md` — addendum, corrections on the record
- `o2s/tests/` — **new**: `harness.js`, `spec06.test.js`, `backlog.test.js`, `README.md`

**Ready to push, not pushed.**

### Next

1. **Open question for Tahir:** should the backlog screen *recommend* an answer
   per PO from the printed-pack evidence? It would clear most of the 44 in one
   pass — but Fault 11 was precisely a default being mistaken for a decision, and
   a recommendation is a default wearing better clothes. Not built, deliberately
2. Once live, `priceSeen` readings start accumulating from the first inspection
   on a list-price PO. They have been accumulating nothing until now
3. The 44 still need a human answer

### Standing rule this run adds

> The artefact includes the tests. If they are not on disk, the verification did
> not happen — no matter how many checks the note claims.

### Added after the above — the recommendation (Tahir, same session)

Asked, and answered: **recommend, but never pre-select.**

`bulkPDSuggest(o)` reads the evidence for one PO and prints a line beside it —
*"Looks like: the current list price — 9 packs on this PO already went out with a
price on them, and none of it came from the PO. Still needs your click."*

It is text. It never writes into `bulkPD`, so a PO cannot become answered without
a human clicking. The reading is done for him; the deciding is not.

**It will never suggest "no price."** You cannot evidence a negative from
silence — a PO with no printed history might print nothing, or might just be new.
That inference *is* Fault 11, where an unticked box was read as "this client
wants a bare bag" on 41 of 44 live POs. Where there is nothing to go on it says
so and names the KAM.

Order of evidence: a price on the PO line → *price set on this PO* · packs
already printed under this PO → *list price* · the brand has carried a price
before, but not here → *list price*, said more weakly · nothing anywhere → no
suggestion.

On the 16 July snapshot's 21 open POs it says: **6 price-on-PO, 13 list, 2 it
will not guess.** Live will differ.

**Now 85 checks, two suites** (52 / 33) — the new ones cover each rung of the
evidence ladder, that the wording admits how weak the weak case is, that "no
price" can never be suggested, and that a full render-and-save cycle with
suggestions on screen still writes nothing.

---

## 2026-08-26 — O2S — AP26012 certified-duplicate lot, and the HG26026 pack question

### What happened

Morning: Tahir reported AP26012-L2 — a duplicate lot from a shift logged twice —
could not be removed because the lab had mistakenly certified it. Traced the
root cause: **no screen in the app ever opened the certificate sheet for an
approved COA**, so Supersede — the only correction a signed certificate allows
(SPEC-03) — was unreachable from anywhere. Remove correctly refused a
lab-touched lot; there was simply no route to the one correction that would
have freed it.

Built, in order: an **Open** button on Lab QC → Approved that reaches the
certificate sheet; visible refusal reasons on the Lots tab (round 1 found the
rewritten messages reached nobody — no button rendered at all for a blocked
lot, so the wording only reached an unreachable 1.9s toast); a re-issue banner
so a superseded draft doesn't come back to Lab Rep as if it were new work
(round 2 found this gap, and a new XSS-style injection round 2 also found —
both fixed round 3); a certified floor and a lots-vs-produced banner against
the one real unmitigated hole, `merge3` cannot express deletion, so a removed
lot can be silently resurrected by another open tab's later save.

**Mid-repair, 16:20** — the batch turned out to be **multi-PO**
(`kind:'multi'`, output spread pro-rata across 4 linked PO lines), not bulk as
every fixture in the repo assumed. The flat "cannot un-log a multi-batch
shift" refusal had to become real: new `lotMultiLogRows(b,lt)` locates the
exact block of `productionLog` rows a shift wrote (allocation order + lot rank
among same-signature lots) so Remove can reverse the exact PO-line shares.
Caught, via a test that built the duplicate through the real `submitShiftLog`
twice, a rank-computed-after-the-splice bug — the fix is what's live.

**Process note, disclosed to Tahir at the time:** while that fix was still
mid-review, Tahir pushed the pre-fix commit (`13c9fa8`) himself via GitHub
Desktop. The corrected version went up 60 seconds later (`fc38986`). Went
live as `f454e80`, confirmed by diff to contain only the fix plus doc/test
updates — no gap between what was reviewed and what shipped, but the near
miss is why the standing rule below exists.

Reviewed independently four times as the build evolved (code, design,
workflow, data-safety — the data-safety reviewer runs every round regardless
of what changed). Round 1: four refusals. Rounds 2–3: fixed what was found,
cleared. Round 4 (the multi-PO emergency): code / data-safety / workflow all
**PUSH, BUT KNOW THIS**; design reviewer hit an API session limit mid-round —
re-run after the push, this session, retrospectively: **NEEDS A FOLLOW-UP
FIX**, nothing urgent, nothing that lost or corrupted data (see Next, below).

**Verified live, after push:** opened AP26012 on the live site — one lot
left (L1, 1,010 Kg, certified, Remove correctly greyed with the Supersede
note), batch bar Produced 1,010 / Packed 1,010, matches the test's predicted
end-state exactly. No errors on the live app anywhere touched this session.

### Files changed

- `o2s/o2s.html` — `RIGHTS[]` note text; `lotRemoveBlockedBy` (certified floor,
  reworded refusals, multi-batch condition); `openRemoveLot`/`renderRemoveLot`/
  `doRemoveLot` (new multi-branch reversal, superseded-cert naming); new
  function `lotMultiLogRows`; `screenQC`/`_qcRow` (Open button, re-issue note);
  `renderProdLifecycleBatch` (greyed Remove button, refusal text, lots-vs-
  produced banner); `renderCOAModal` (re-issue banner); `actionItems()`
  (escaped re-issue reason); `_pcLotRes` (Draft pill)
- `o2s/tests/certremove.test.js` — **new**, 255 checks, 12 sections
- `o2s/tests/authmodel.test.js` — one guard rewritten for the new button
- `docs/o2s/AP26012-2026-08-26.md` — correction pointer to the doc below
- `docs/o2s/AP26012-CERTIFIED-2026-08-26.md` — **new**, the full repair
  procedure, reviewer findings each round, the multi-PO pivot
- `docs/o2s/SPEC-03-EDIT-STANDARD.md` — recorded exception: Remove destroys a
  superseded cert's printable copy; COO chose register-line-is-enough over a
  data-model change
- `docs/o2s/HANDOFF-2026-08-26.md` — recorded the `coaRework` bypass as open,
  not fixed
- `docs/o2s/HG26026-PACKED-2026-08-26.md` — **new**, see below

### Pushed

Everything above is live as of commit `f454e80 "LIVE"`. Confirmed by diff
against the last-reviewed commit that nothing beyond docs and one test landed
on top of the reviewed code.

### HG26026 — the "2,800 Kg packed, production says they haven't" report

Read the live app's in-memory data directly (no database access, nothing
changed). It's real: a complete pack transaction, id `PK2074-1vih`, 2,800 Kg
from HG26026's lot L1 into brand batch GPH26002 against PO 0254, dated
**2026-08-22**, recorded by **Ali Raza**. Timeline is clean — produced 08-20,
certified 08-21, packed 08-22 — and every figure that depends on it agrees.
Not a bug, not a phantom number. Full detail in
`docs/o2s/HG26026-PACKED-2026-08-26.md`.

**Open question, unresolved:** why Production told the COO nothing was
packed when the record names Ali Raza and a specific date four days back.
**Next step is to ask Ali Raza directly** — not to touch the record on a
guess either way.

### Next

1. **Not started this session — was the #1 pick at session start:** the
   Production "stuck/blocked" list has no role filtering (`rmSubmit` has no
   permission check; a QA Inspector can receive RM, close PRs, CFO-approve
   PRs from that screen).
2. **HG26026** — confirm with Ali Raza; if he says he did not pack it, that's
   a deliberate `REVERSE` with a reason, not a silent edit.
3. Two small design-review follow-ups on the AP26012 work, neither urgent,
   neither a data-safety issue: the batch lifecycle screen's eyebrow still
   reads "Bulk → stock" for a multi-PO batch instead of naming its POs
   (`renderProdLifecycleBatch` never checks `sel.kind==='multi'`, unlike four
   other places in the app that already do); the Remove confirmation dialog
   doesn't preview which POs a multi-batch removal will touch before the
   person commits (it only lists them afterward, in a toast).
4. **Known, documented, not fixed this session** (round-4 reviewer findings):
   a zero-kg "no output" shift row sharing a signature with a real one can
   become `lotMultiLogRows`'s "newest block" and cause Remove to touch the
   wrong (empty) block — a one-clause skip fixes it; `merge3` appends
   server-only rows at the end of `productionLog`, which can invert the
   newest-first assumption the rank lookup relies on (16 inversions already
   measured in the 81-row live snapshot) — recommended fix is to match by
   summed-kg-vs-lot-qty before falling back to rank.
5. **Deferred, "the next job," not this session:** the `coaRework` bypass
   lets UNFIT material get un-logged with no trace; the real fix for the
   multi-tab resurrection hole is replacing `doRemoveLot`'s hard splice with
   a flagged/soft-delete model instead of the certified-floor/banner
   mitigation now in place.
6. The app has no screen anywhere that shows `actionLog`/`packingLog`
   history to a person — it's write-only. That's what made the HG26026
   question hard to answer from inside the app at all. Worth a simple
   batch/PO "history" tab at some point; not requested, not built.

### Standing rule this run adds

> A working file written into the folder and a reviewed, safe-to-push file
> look identical from Tahir's side. Once review is running, nothing gets
> written into the folder until it clears — so what GitHub Desktop shows is
> always safe to push, full stop.

---

## 2026-08-26, resumed session — O2S — the #1 pick from this morning: RM Check had no gate at all

### What happened

Picked up the item flagged "not started this session — was the #1 pick" from
the AP26012 handoff above: Production's stuck/blocked list renders action
items belonging to other departments for visibility, but the render path drew
every one of them as a real, clickable button regardless of who's looking.

Traced it to the exact line. `grpS` (inside `prodStageList`'s `'attention'`
branch) called `acRowHTML` — the same renderer "My Actions" uses, where it's
safe because `acBase()` already scopes items to the viewer's own role plus
explicit escalations. Production's list has no such scoping: `prodStuckItems()`
pulls straight from `actionItems()`, unfiltered. A function called `rowS`
already existed two lines above `grpS`, already did the right thing (a live
button only for `_cat==='produce'` — Production's own, navigation-only —
`'owner: <role>'` text for `'rm'` and `'qc'` either way), and was never called.
This morning's own commit found it and named it exactly: *"rowS is defined and
never called... it wants a decision of its own, not a flag."* This is that
decision.

Wired `rowS` back in. Added a sibling `rowD` for the Deferred section beside
it — same idea, always read-only, because Un-defer's correct home is My
Actions (which does scope correctly) and the `_id` the old Un-defer button
depended on was never even set on items reached this path — it was already
silently inert, not something this change breaks.

**The one real gap underneath the UI issue:** RM Check itself (`openRMCheck` /
`rmSubmit`) checked nothing — not a role name, not a screen, not the access
matrix, for anyone, from anywhere. Unlike Receive and Close PR (converted 25
Aug, `may('rm.receive')` / `may('pr.close')`), which the button-fix alone
neutralizes since the writers already refuse an unauthorized role, RM Check's
writer had no refusal to fall back on. Added `rm.check` to the RIGHTS
catalogue — same shape as `rm.receive` (`canEdit`, owners Supply Chain,
home screen `approvals`, also reachable from `prod`) — and gated both opener
and writer, same "opener AND writer both ask" pattern as `rm.receive`'s own
fix on 25 Aug.

**Audited the other two categories the same list exposes**, since the bug
class (unconditional live button, any category) touches four things, not one:
`approveRMPR` / `cfoApprovePR` (Approve PR) and `coaReview` / `coaApprove` /
`coaDeviation` (Lab QC) all already carry a real check — legacy `canEdit`/
`hardRole`, not yet in the `may()` catalogue, but not zero. RM Check was the
only one of the four with nothing behind it at all.

### Reviewed

Two independent reviews (code + data-safety, neither having done the work) on
the diff before calling this done:

- **Confirmed not an issue:** `it.act` embedded unescaped in the new live
  `onclick` — this is the same pattern `acRowHTML` and every other action
  button in the file already uses; ids come only from `nid()` (alphanumeric +
  hyphen, never free text), so this isn't new exposure, just the file's
  existing convention reproduced.
- **Confirmed not an issue:** whether `rm.check`'s `alsoOn` field could itself
  be granting the right rather than just documenting where the button is
  reachable — it isn't read anywhere in `mayLegacyRole`'s `canEdit` branch;
  it's declarative, used only by `screenLoopholes()` and the tests.
- **Confirmed not an issue:** `whoMayRight('rm.check')` matches
  `whoMayRight('rm.receive')` exactly (Supply Chain, Plant Manager, COO) —
  tested directly, not assumed.
- **A pre-existing gap, not a new one, worth naming:** a CFO who sees an
  *escalated* RM Check or Receive item in My Actions and clicks it is refused
  today — `CFO` has no Edit override on the `approvals` screen in the matrix
  on record, so `may('rm.receive')` already said no for CFO before this
  session, and `rm.check` inherits the identical shape rather than inventing a
  new one. Checked empirically against the live matrix data, not asserted.
  Not fixed — widening it is a matrix/policy call, not a code fix, and it
  affects an already-shipped right, not the one touched today.

### Verified

```
node o2s/tests/spec06.test.js          # 52 passed
node o2s/tests/backlog.test.js         # 42 passed
node o2s/tests/actioncenter.test.js    # 98 passed
node o2s/tests/batchclose.test.js      # 184 passed
node o2s/tests/batchqty.test.js        # 113 passed
node o2s/tests/certremove.test.js      # 255 passed
node o2s/tests/datafix-bulkprice.test.js  # 41 passed
node o2s/tests/firstsave.test.js       # 15 passed
node o2s/tests/lotpack.test.js         # 118 passed
node o2s/tests/prodrender.test.js      # 102 passed
node o2s/tests/rights.test.js          # 61 passed
node o2s/tests/authmodel.test.js       # 5218 passed (81 lines of updates: a
                                        #   rights-count assertion, a screen-
                                        #   loophole report that now correctly
                                        #   lists 3 codes instead of 2, and a
                                        #   new CLOSED_GAP category alongside
                                        #   OLD/NEW_RIGHTS for a right that
                                        #   closes a real hole rather than
                                        #   freezing or inventing one)
node o2s/tests/prodstuck.test.js       # 46 passed — NEW, this session
```

`prodstuck.test.js` renders the real `prodStageList('attention')` for 9 roles
(QA Inspector, KAM, Sales, Lab Rep, Finance, Supply Chain, CFO, Production,
COO) against fabricated stalled RM and produce items, and asserts: no role
ever gets a clickable `openRMCheck(` on this screen; every one of them sees
`owner: Supply Chain` instead; Production and COO still get their own
`Resolve`/`gotoProduce(` button for the produce-category item; a deferred item
reads `deferred to <date>` with no button, for anyone. `node --check` clean on
all 5 script blocks.

### Files changed

- `o2s/o2s.html` — `RIGHTS[]` (new `rm.check`), `openRMCheck`/`rmSubmit`
  (guard), `prodDeferredItems` (tags `_cat`), `prodStageList`'s `'attention'`
  branch (`grpS`/`defHtml` now render through `rowS`/new `rowD`, table-wrapped)
- `o2s/tests/authmodel.test.js` — `CLOSED_GAP` category (section 2a), Supply
  Chain right count 6→7 with a CONV/GAP split (section 23), `rm.check` added
  to the opener/writer guard lists (section 27), pinned in the screen map
  (section 29) and the `alsoOn`-derivation table (section 30), the
  `screenLoopholes()` report updated 2→3 codes (section 24)
- `o2s/tests/prodstuck.test.js` — **new**, 46 checks

A stray 0-byte `.git/index.lock` was found blocking `git add`/`commit`
entirely (`Another git process seems to be running`) — asked permission and
deleted it. Unrelated to this change; would have blocked the next commit in
GitHub Desktop regardless of what it was.

**Ready to push, not pushed.**

### Next

1. The CFO-escalation gap named above (My Actions can show CFO a button for
   an item `may()` then refuses) — pre-existing on `rm.receive` too, a matrix/
   policy call for Tahir, not something this session widened or fixed.
2. Of the six items in the AP26012 entry above this one, item 1 (Production's
   stuck/blocked list, `rmSubmit`) is what this entry closes. Items 2–6 there
   — HG26026/Ali Raza, the two AP26012 design follow-ups, the
   `lotMultiLogRows`/`merge3` edge cases, and the deferred `coaRework`/soft-
   delete work — are untouched, still open.

### Live-verified, same day — pushed, deployed, checked on the running app

Tahir pushed via GitHub Desktop and confirmed Render redeployed. Checked the
live app directly (`https://van-control-tower.onrender.com/o2s`, deployed
commit `4a18d52`) rather than trusting the test suite alone:

- App loads clean as COO, no console errors on load.
- Called the real `prodStageList()` in the live page against real production
  data (not fixtures) with the attention view active: zero `openRMCheck(`
  anywhere in the output — the RM Check button is gone from Production's
  stuck list for everyone, on the actual deployed bundle. 33 live Resolve/
  Defer buttons for Production's own stalled (produce-category) items, 0
  `approveRMPR(`/`coaReview(`/`coaApprove(`/`coaDeviation(` calls, and 2 items
  correctly rendered as read-only "owner:" text (Lab QC category — same code
  path `rm` uses, proven correct here since QC items exist naturally in
  today's real data).
- No RM Check item happens to be stalled past threshold in today's live data,
  so the exact "owner: Supply Chain" text couldn't be eyeballed on a real rm
  item today — that path is what `prodstuck.test.js` fixtures exist to prove
  and it passed 46/46 against this same shipped file; did not fabricate a
  fake stuck order on the live database to force one, per "no invented data /
  read-only by default."
- Did not attempt to switch live role to check the fix from a non-COO
  seat — no in-app impersonation available without changing a real user's
  role, and the role-sweep (9 roles) is exactly what `prodstuck.test.js`
  already exercises against the real function extracted from this file.

Net: the fix is live and behaving as designed on the deployed app, not just
in the local test run.

## 2026-08-26, resumed session (2) — O2S — New PO Entry redesign (design-artifact-approved)

**Scope decision, confirmed with Tahir before touching anything:** work moves to O2S's
master-level screens — New PO Entry, Customer Master, Admin/Master Data, Data Fix, Users &
Access, Instructions — because they're master-level control, not daily workflow/logic.
"Users & Access" was excluded from this scope on Tahir's confirmation: despite living inside
`o2s.html`, it calls `/api/login` and `/api/users*`, which are PLATFORM-owned. This entry is
New PO Entry only; Customer Master / Admin·Master Data / Data Fix are untouched, still open.

**New standing rule, Tahir's words:** *"we will build a design artifact every time before we
approve and make a change."* A Claude Design canvas prototype was built, iterated live with
Tahir (he removed the raw-material preview card himself in the canvas editor), and explicitly
approved ("This is fine. lets built it and push..") before any of `o2s.html` was touched.
Published prototype: `https://claude.ai/code/artifact/d5d37664-d202-4b7f-9f7b-7be4b17003d4`.

### What changed on the real screen

- **Three new optional capture fields** that the screen never asked for before: Delivery
  Contact Phone, Order Source (dropdown: Phone call / WhatsApp / Email / Portal / In-person
  visit), and a full-width General Instructions / Delivery Notes textarea. None are required
  to submit — they ride alongside the existing optional Delivery Focal Person field rather
  than adding a new blocking rule. Priority and Delivery Focal Person, which previously had
  no live handler, now refresh the summary panel as they're changed too.
- **Raw-material preview card removed from the live screen** (Tahir, on the design canvas:
  *"i have removed the raw material calculation window which is not rewuierd here"*). The
  `previewRM()` function is deleted outright — dead code once its `#e_preview` element no
  longer exists. The **real, shared** `rmCheck()` function (used elsewhere for actual order
  `rmDecision` computation, lines ~1592 and ~2024) is untouched — it is a different function
  from the entry-screen-only preview wrapper that was removed.
- **Step-progress strip** (Header → Line items → Pricing → Submit, colour-coded not-started/
  in-progress/done) and a **sticky "Order Summary" panel** that mirrors every field back live
  as it's typed — replacing the removed raw-material card's screen real estate.

### A real client-PO file upload was designed and built, then pulled back out — not shipping yet

A first pass of this session also built a full attachment feature end to end: client-side
pick/validate (8MB cap, pdf/jpg/jpeg/png), new `/api/o2s/attachments` POST/GET routes in
`server.js` mirroring PD's existing no-DB upload pattern, a new `O2S_ATTACH_DIR` disk mount in
`render.yaml`, and `submitPO()` made `async` to upload-then-abort-on-failure before creating
the order. It was fully working and test-covered (38 checks) — then Tahir asked to hold it
back: *"leave the attachment part for now"* / *"we will do it later"*. All of it has been
**cleanly reverted**: `server.js`, `render.yaml`, `.gitignore` and `o2s/tests/harness.js` are
back to their exact pre-session committed state (confirmed via `git status` — zero diff on
all four), and `o2s.html` no longer contains `entryAttachFile`, the attach/upload helper
functions, or any reference to `/api/o2s/attachments`. Nothing about it is half-applied.
**Worth knowing for whenever this gets picked back up:** the design and the server-side
pattern (mirror PD's `libStoreUpload`, same disk, same auth level as every other O2S route,
loud warning instead of PD's silent ephemeral-storage fallback) are already worked out and
didn't run into any problem — it's just parked, not blocked on anything.

### Verification done this session

- All 5 `<script>` blocks in the patched `o2s.html` parse clean (`new Function(...)` per
  block, no syntax errors). `node -c server.js` clean (server.js is untouched, back to
  original).
- Full existing suite re-run after the change — **no regressions**, all 13 pre-existing
  files still green (actioncenter 98, authmodel 5218, backlog 42, batchclose 184, batchqty
  113, certremove 255, datafix-bulkprice 41, firstsave 15, lotpack 118, prodrender 102,
  prodstuck 46, rights 61, spec06 52 — all passed, 0 failed).
- **New test file, `o2s/tests/poentry.test.js` — 24 checks, all passing**, covering: the
  raw-material card/`previewRM`/`e_preview` are genuinely gone from the whole file (not just
  from a possibly-truncated function extract — `screenEntry()` is too irregular, nested
  template literals plus a `.replace(/"/g,...)` regex literal, for `harness.js`'s brace-
  matcher, a pre-existing limitation documented in its own comments, not something this
  change caused — so these checks search the whole file rather than trusting `grab()` on
  `screenEntry` specifically); `onChannelChange` resets all three new globals; `submitPO`
  still gates on `may('order.create')` and records the three new fields on the order object;
  `entryStepDots()` actually reflects real completion state (grey → teal once header fields
  are filled), not just presence of the function; `updateEntrySummary()` renders "not set"
  placeholders correctly and picks up real values from the DOM fields once filled in; and an
  explicit check that no attachment code shipped this round.
- `git status` confirms the final diff is exactly: `o2s.html` modified, `poentry.test.js`
  new. Nothing else touched.

### Files changed

- `o2s/o2s.html` — new draft-state globals (`entryFocalPhone`, `entrySource`,
  `entryInstructions`); `onChannelChange` reset list extended; new helpers
  `entryStepDots`/`entryStepsHtml`/`updateEntrySummary`; `screenEntry()` restructured (scoped
  `.po2` style block, step strip, two-column layout, new fields row, raw-material card
  removed, sticky summary side column); Priority select wired to `validate()`; Delivery Focal
  Person wired to `validate()`; `validate()` calls `updateEntrySummary()` instead of the
  removed `previewRM()`; `previewRM()` deleted; the order object gains `focalPhone`/
  `source`/`instructions`.
- `o2s/tests/poentry.test.js` — **new**, 24 checks

**Ready to push, not pushed.** Tahir pushes via GitHub Desktop.

### Next

1. Customer Master, Admin/Master Data, Data Fix — same "master-level, design-artifact-first"
   scope, still fully open, not started.
2. The client-PO attachment feature, parked per Tahir's explicit request this session — the
   design and server-side pattern are already worked out (see above), ready to pick up
   whenever wanted. Not on any list until Tahir asks for it again.
3. From the design canvas's own "also considered, not in this draft" list (Tahir has seen
   this, nothing decided yet): delivery drop-location per PO for non-VGreen channels (needs a
   Customer Master change too), a reference/quotation number field, minimum shelf-life per
   line, and a payment-terms override per PO. None built — flagged for a future decision, not
   assumed.
4. Everything already open before this session (HG26026/Ali Raza, `lotMultiLogRows`/`merge3`
   edge cases, deferred `coaRework` bypass, the CFO-escalation matrix gap, S-01/S-02/S-03/S-04)
   is untouched by this entry.

---

## 2026-08-27 — Customer Master: design-artifact review → prototype → shipped fix

**Module: O2S.** Declared at session start ("we are working on o2s").

### What happened

1. Read `o2s/o2s.html`'s Customer Master screen cold (no prior assumption) and found 6
   design issues for long-term use: (1) downstream screens (New PO Entry, Shipments/DC
   printing) join customers by **name**, not by the code this screen assigns — a rename here
   would silently break past-order matching; **not fixed this round, flagged below**. (2)
   `state.customers`/`state.dealers` records had no stable `id`, so merge3's per-record merge
   (`_arrId`) couldn't apply — a save conflict replaced the whole array, silently dropping a
   concurrent edit. (3) The live dealer-code generator read region/city from an orphaned
   `dlrForm` global left over from a pre-unification screen, not from the form actually being
   filled in — every dealer got stamped with the same wrong region/city regardless of what
   was picked. (4) `state.dealers` was a second, one-way-synced copy of Dealer-segment
   customers that silently went stale. (5) No way to deactivate/reactivate a customer record
   at all. (6) A code-generation race condition (`array.length+1` at read time).
2. Per the standing "design artifact before any change" rule: built and published a Claude
   Design canvas (`https://claude.ai/code/artifact/7d83cbb7-59d0-429b-b6d2-1b675a70742f`,
   "Customer Master Fix") showing the Add/Edit form with a live Status field, working
   Deactivate/Reactivate, and a sticky note listing the under-the-hood fixes (ids, code-gen
   fix, dealers-array retirement). Tahir approved ("good to go").
3. Implemented in `o2s/o2s.html`, scoped to exactly what the canvas showed:
   - `ensureRecordIds()` backfills `.id = .code` on every existing `state.customers`/
     `state.dealers` record.
   - `custCode(seg,name,inducted,outlet,region,city)` — signature extended; the Dealer
     branch now reads the region/city actually passed in (`regAbbr(region)`/`cityAbbr(city)`)
     instead of the orphaned `dlrForm` global.
   - The dead pre-unification path (`dlrForm`, `suggestCode`, `onDlrRegion`, `onDlrCity`,
     `addDealer`) deleted outright — confirmed genuinely unreachable, `custSave()` alone
     already covers the equivalent gate checks.
   - `custSave()` stamps `id:code` on every saved record; call site passes the form's own
     `region`/`city` into `custCode`; the buggy one-way `state.dealers` write-sync removed
     (state.customers is now the single source of truth; comment left explaining why).
   - New Status field (Active/Inactive) on the Add/Edit form; new `custToggleStatus()`
     (gated on `may('customer.amend')`, same as `custSave`); wired into both branches of
     `screenDealers()`'s row rendering (Edit + Deactivate/Reactivate buttons).
4. **Deliberately not built this round**: the name-vs-code join-key issue (finding #1 above).
   Fixing it touches New PO Entry's `curCustomer()`/`clientsForChannel()` and Shipments'
   `printDC()` — a separate, larger change that needs its own design/decision, not something
   to fold into this one silently.
5. New test file `o2s/tests/customermaster.test.js` (36 checks) — source-level checks (dead
   code really gone, `custCode`/`custSave`/`ensureRecordIds`/`custInit` all stamp/consume ids
   and region/city correctly, `state.dealers` no longer written) plus real-execution checks
   via the repo's `vm`-sandbox `app()` pattern (same shape as `poentry.test.js`): dealer codes
   for Lahore/Punjab vs Karachi/Sindh come out correctly and differently
   (`regAbbr`/`cityAbbr` are the app's real ones — Punjab → `PB`, Sindh → `SN`, confirmed via
   `SEED.geo.regionCode`, not the `PU`/`SI` I first assumed and had to correct in the test);
   `custSave()` produces `id===code` and never touches `state.dealers`; `custToggleStatus()`
   flips status and is correctly denied when `may()` is stubbed false; `ensureRecordIds()`
   backfills legacy records.
   Also fixed two pre-existing test files that referenced the now-deleted `addDealer`:
   `authmodel.test.js` and `rights.test.js` (both just dropped the dead reference — the gate
   check they were making is already covered by `custSave()`).
6. Ran the full suite: **all 15 files pass, 0 failures** (`customermaster.test.js`: 36/36;
   everything else unchanged from before this session). All 6 `<script>` blocks in
   `o2s.html` still parse cleanly (`new Function()` check).

### Files changed

- `o2s/o2s.html` — `ensureRecordIds`, `custCode`, `custInit`'s seed helper, `custSave`,
  `custFormHTML` (Status field), new `custToggleStatus`, `screenDealers` (Edit/
  Deactivate-Reactivate buttons); dead `dlrForm`/`suggestCode`/`onDlrRegion`/`onDlrCity`/
  `addDealer` deleted.
- `o2s/tests/customermaster.test.js` — **new**, 36 checks.
- `o2s/tests/authmodel.test.js`, `o2s/tests/rights.test.js` — dropped references to the
  deleted `addDealer`.

**Ready to push, not pushed.** Tahir pushes via GitHub Desktop.

### Next

1. **The name-vs-code join-key issue is still open** — order entry and DC printing resolve
   customers by name, not by the code Customer Master assigns. This is a separate, larger
   change (touches New PO Entry and Shipments) and needs its own design pass before starting.
   Not started, not scheduled — flagging for a decision, not assuming it's next.
2. Admin/Master Data, Data Fix — same "master-level, design-artifact-first" scope as
   Customer Master, still fully open, not started (carried over from before this session).
3. Everything already open before this session (client-PO attachment parked per Tahir's
   request, HG26026/Ali Raza, `lotMultiLogRows`/`merge3` edge cases, deferred `coaRework`
   bypass, CFO-escalation matrix gap, S-01/S-02/S-03/S-04, the design canvas's own
   "considered, not built" list) is untouched by this entry.

## 2026-08-27 (later) — MODULE: O2S — two untraced packs, both a Data Fix cascade gap

**Module: O2S** (continuing).

### What happened

1. Revisited the HG26026 Humic/PO 0254 thread (Ali Raza's account of 4,000 Kg vs the
   system's 2,800 Kg, and "this batch was not available in ready to pack till yesterday").
   Tahir wasn't able to say what the referenced request was without checking with Ali Raza
   or Majid — **left open, not resolved this session**, pivoted to a concrete, verifiable
   report instead.
2. New report: "Sulfur coated urea 2500 Kg produced, packed, but now its has no visible
   trace... 100 bags of vital urea." Investigated **live**, via the Chrome extension against
   `van-control-tower.onrender.com/o2s` (not the stale local `data/state.json` fixture) —
   read-only `state` queries throughout. Traced to order line `COBO-2608-4613 · Vital Urea`:
   `produced:2500, packed:2500` with no packingLog/actionLog/audit entry backing either
   number. Tahir named the batch — `VU26190` — and the accounting gap on that batch
   (`producedKg:7000, packedKg:6375`, only 3,875 Kg traceable to a real pack run) matched the
   2,500 Kg gap exactly: a real pack transaction that updated totals but was never logged,
   bypassing `doPack()`'s atomic write entirely.
3. Corrected live, in three steps Tahir approved and (after the platform's automation
   classifier blocked scripted form-filling on live-data writes, three separate times —
   correctly stopped rather than worked around, per its own guidance) completed manually
   himself: (1) downloaded a snapshot, (2) zeroed the untraceable 2,500/2,500 via **Correct
   values** (`CR2325-ci2k`), (3) re-added it via **Add missing packing** — which surfaced the
   real bug: the new record had no batch link, so Pre-shipment QA answered "No batch # — set
   batch # first" with no UI path to fix it.
4. Second report, mid-session: `RUD26824 · Tervalis Plus` showing 13,000 Kg "Awaiting QA"
   against a real total of 10,000. Traced live: two packingLog entries against that line —
   `PK2132-wpn7` (3,000 Kg, Aug 25, batch **VB26004** — a "Vibrant" base-material batch,
   picked by mistake) and `PK2276-fu9m` (10,000 Kg, Aug 26, the correct batch RUHLS26005).
   Tahir had already corrected the order line back to 0 via **Correct values**
   (`CR2166-5p20`, reason: "Mistakenly select the wrong batch") — but that tool only sets
   order-line numbers; the stray `PK2132-wpn7` record was never removed, so
   `lineToInspect()`/`lotsFor()` (which sum straight off `packingLog`, unfiltered by any
   later order-line correction) kept counting it: 3,000 + 10,000 = 13,000. Batch VB26004's
   `packedKg` also stayed at 5,000, never freed back up. Found in the process: a *generic*
   Reverse already exists (`openCorrect('packingLot', id)` → `CORRECT_ENTITY.packingLot.
   doReverse`, reachable today from Reports → Traceability → "Every pack run" → Correct) —
   but it unconditionally re-subtracts from the order line too, which here would have
   double-counted (the line's 3,000 was already zeroed separately). Confirmed by inspection,
   not assumption, before ruling it out for this case.
5. Both bugs share one root cause: **Data Fix's writers only set the numbers on the record
   they're pointed at — none of them cascade to the related batch or packingLog record.**
   Confirmed with Tahir which fix to build (AskUserQuestion): void `PK2132-wpn7` *and* free
   the 3,000 Kg back onto VB26004's capacity; build the Batch # field and a Void tool in one
   combined design pass rather than two.
6. Design artifact — `https://claude.ai/code/artifact/86e18d4d-92d1-488e-815e-e9803d2b8759`
   ("Data Fix — Batch # and Void"), a working clickable prototype seeded with both real
   cases (Vital Urea for the Batch # picker, RUD26824 for Void). Tahir approved ("GO AHEAD").
7. Implemented in `o2s/o2s.html`, scoped to exactly what the canvas showed:
   - **Add missing packing** now has a required **Batch #** field (`dfBatchSelect`, new),
     filtered to `state.batches` matching the line's `base` and `batchLabApproved()` — same
     rule `doPack()` already enforces. `dfSubmitPacking()` now refuses without a batch, or
     with an un-approved one; on success it derives `baseBatchId`/`baseBatchNo`/
     `brandBatchNo`/`mfgDate`/`expDate` via the same `packDates()` call `doPack()` uses (no
     re-implemented date logic), and adds the backfilled qty onto the batch's own `packedKg`
     (previously left unrecorded on the batch side too).
   - **Void an entry** (Packing) — new, `dfStart('void')` now active on the Data Fix cards
     grid (was the greyed-out placeholder). New `dfSubmitVoid()`: picks a stray packingLog
     record for a PO/product (`dfVoidEntrySelect`, excludes already-reversed/voided/
     already-inspected records), zeroes its `kg` (so it naturally drops out of `lotsFor()`'s
     `kg>0.0001` filter — no change needed to the QA-queue math itself) and flags
     `void:true`/`voidedKg`/`voidedAt`/`voidedBy`. Unless the "restore batch capacity"
     checkbox is unchecked, reduces the linked batch's `packedKg` by the same amount.
     **Deliberately does not touch the order line** — that's what makes it safe to use after
     a line has already been corrected separately with Correct values (the RUD26824 case);
     using the existing generic Reverse there would have double-subtracted. Logged via
     `recordCorrection('VOID', 'packingLot', ...)` — same ledger, visible in Reports →
     Corrections, cascade text names the batch change.
8. New test file `o2s/tests/datafix-batchvoid.test.js` (37 checks), same real-execution
   pattern as `customermaster.test.js`/`datafix-bulkprice.test.js`: both writers still gate
   on `screenEditOK('datafix')`; `dfSubmitPacking` refuses with no batch and with an
   un-approved one, and on success links the real batch fields, derives real dates, credits
   the batch's `packedKg`, and records a BACKFILL naming the batch #; `dfSubmitVoid` refuses
   with no record picked, no reason, or an already-inspected record; on success zeroes the
   stray record while leaving the *other* (correct) record and **the order line untouched**,
   restores batch capacity unless unchecked, is a no-op the second time it's run on the same
   record, and records a VOID correction with the batch cascade named; the Data Fix card is
   confirmed switched on in the actual markup, not just in a comment.
9. Ran the full suite: **all 16 files pass, 0 failures** (new file 37/37; every other file
   unchanged from before this entry). All 5 inline `<script>` blocks in `o2s.html` still
   parse cleanly (`new Function()` check, corrected this session to actually isolate each
   inline block rather than one greedy regex across all `<script>` tags).

### Files changed

- `o2s/o2s.html` — `dfStart` (new form fields `bid`/`pid`/`restoreBatch`), `dfPOSelect`/
  `dfLineSelect` (reset the new fields on change), new `_batchApprovedDate`,
  `dfBatchSelect`, `dfVoidEntrySelect`; `dfCardsHtml` (Void an entry activated);
  `dfFormHtml` (`packing` branch gets the Batch # field; new `void` branch);
  `dfSubmitPacking` (batch required + linked); new `dfSubmitVoid`.
- `o2s/tests/datafix-batchvoid.test.js` — **new**, 37 checks.

**Ready to push, not pushed.** Tahir pushes via GitHub Desktop. **The two live records this
was meant to fix are still broken on the deployed app** — the new Data Fix fields only exist
in this local build. Once pushed and deployed:
1. Data Fix → Void an entry (Packing) → `RUD26824` / Tervalis Plus → the 3,000 Kg / batch
   VB26004 record → restore-batch-capacity checked → void it. Restores VB26004 to 2,000 Kg
   packed and drops "Awaiting QA" for that line from 13,000 to the correct 10,000.
2. For the Vital Urea record (`COBO-2608-4613`, currently blocked "No batch # — set batch #
   first"): the already-created backfilled entry has no batch fields and the new Batch #
   field only applies going forward — it will need voiding (no batch to restore, since it
   was never linked) and re-adding via Add missing packing with **VU26190** picked, to pick
   up the batch link this time.

### Next

1. **The HG26026 Humic/PO 0254 thread is still open** — Ali Raza's "4,000 Kg, 1st PO of
   Kisan" claim vs the system's 2,800 Kg, and what "we requested you to resolve" referred to.
   Needs Ali Raza or Majid directly; not something to guess at from the data alone.
2. The two live records above need the push + the two Data Fix actions listed to actually
   be fixed — this session built and tested the tool, it did not yet apply it live.
3. The name-vs-code join-key issue (Customer Master, flagged 2026-08-27 morning), Admin/
   Master Data scope, and everything else already open before this session, remain
   untouched by this entry.

## 2026-08-27 (later still) — MODULE: O2S — the redo trap: batch already counted the Kg once

**Module: O2S** (continuing, same day).

### What happened

Tahir pushed and deployed the Batch #/Void fix, then used it live: voided the unlinked
Vital Urea backfill (`PKmtbb747fj9fulv`) via the new **Void an entry**. Confirmed live: it
correctly left "Awaiting QA" (kg zeroed, `void:true`), but reported "its still showing the
packed" — the order line (`COBO-2608-4613 · Vital Urea`) still read `2500/2500`. Expected:
`dfSubmitVoid()` deliberately never touches the order line (that's the whole point — it's
what makes it safe to use after a line was already corrected separately, the RUD26824 case).
So the line is now back to exactly the original symptom: numbers present, nothing backing
them — step 1 of the intended 2-step redo (zero via Correct values, re-add via Add missing
packing with the batch).

Before telling Tahir to take step 2, checked what re-running **Add missing packing** would
actually do to batch **VU26190**, live: `packedKg` is **6,375**, unchanged since before any of
today's corrections. That number has *always* included this exact 2,500 Kg — the original
untraced pack updated the batch total at the time, it just never wrote a `packingLog` record.
Neither the original zero-out (Correct values, order-line only) nor today's void (no
`baseBatchId` on the old unlinked entry, so nothing to restore) ever touched it. Re-running
Add missing packing with `VU26190` picked would, by the code just shipped, add another 2,500
on top — `packedKg` → 8,875, more than the batch's own 7,000 Kg produced/certified, silently
zeroing its real ~625 Kg of remaining packable stock. Checked whether a batch's `packedKg`
can be corrected back down afterwards if that happened: it can't — `CORRECT_ENTITY.batch`'s
`fields` list is deliberately `batchNo` / `openedDate` / `plannedKg` / `producedKg` only, no
`packedKg` (by design, per its own comment). So this had to be got right going in, not
patched after — **told Tahir to hold off** rather than let him run into it.

Fix: `dfSubmitPacking()` gets one more field, off by default — `dfForm.skipBatchCredit`. The
Add missing packing form shows a checkbox once a batch is picked ("This batch's packed total
(currently N Kg) already includes this quantity... don't add it again"), only relevant when
redoing a record that was already reflected in the batch once. Unchecked (the normal case —
a genuinely new backfill), behaviour is unchanged from the fix shipped earlier today.
`recordBackfill`'s change log now always names the batch's before/after packed total, whether
or not it moved, so a reviewer in Reports → Corrections can see which it was.

Added 2 more checks to `o2s/tests/datafix-batchvoid.test.js` (now 43): checkbox on -> batch
`packedKg` unchanged, order line still catches up, the record still carries the real batch
link; checkbox off -> batch is credited exactly as before. Full suite: **16 files, 0
failures**. All 5 inline `<script>` blocks parse clean.

### Files changed

- `o2s/o2s.html` — `dfStart` (`skipBatchCredit:false` default), `dfFormHtml`'s `packing`
  branch (the checkbox), `dfSubmitPacking` (honors it; change log always names the batch
  total).
- `o2s/tests/datafix-batchvoid.test.js` — +2 checks (43 total).

**Ready to push, not pushed.**

### Next

1. Once pushed: redo the Vital Urea fix — **Correct values** (zero `COBO-2608-4613` · Vital
   Urea's Produced/Packed, currently unbacked at 2,500/2,500) → **Add missing packing**
   (2,500 Kg, batch **VU26190**, **check** "already includes this quantity" since VU26190's
   6,375 Kg packed already reflects this pack) → reason → submit. Confirm afterward: line
   back to 2,500/2,500 with a real batch link, VU26190 still reads 6,375 (not 8,875 or 3,875),
   Pre-shipment QA clears it (no more "No batch #").
2. RUD26824 (Void the 3,000 Kg / VB26004 stray record, restore-batch-capacity checked) is
   unaffected by this addendum and still just needs the one Void action.
3. Everything else open before this entry is unchanged.

## 2026-08-27 (evening) — MODULE: O2S — Vital Urea / RUD26824, live-fixed and verified

**Module: O2S** (continuing, same day).

### What happened

Tahir hit "THIS IS NOT WORKING" partway through redoing the Vital Urea fix by hand, then
said "YOU GO AND DO YOURSELF." Checked live state first: **Correct values** had already
landed (`COBO-2608-4613` · Vital Urea zeroed correctly) — the **Add missing packing** form
was just sitting on its unselected batch dropdown, not actually submitted yet. No code
defect. Completed the form directly via browser automation: batch `VU26190` picked by typing
its full batch number into the native `<select>` (type-ahead landed exactly on it), the
"already includes this quantity" checkbox ticked, reason filled, submitted. No classifier
block this time.

Verified live, by state query and a Pre-shipment QA screenshot, not just the success toast:
`COBO-2608-4613` back to `2500/2500`; new `packingLog` entry `PKmtbed7c7zl9a5d` carries the
real batch link (`baseBatchId:'B2193-yzry'`, `baseBatchNo:'VU26190'`); batch `VU26190`
`packedKg` still **6,375** (not 8,875 — the skip-checkbox worked). RUD26824 side: batch
`VB26004` `packedKg` **2,000** (freed back up from 5,000), `PK2132-wpn7` voided (`kg:0,
void:true`), `PK2276-fu9m` untouched at `10,000`. Pre-shipment QA: **"Awaiting QA: 2 lines,
12,500 Kg"** (10,000 + 2,500 — correct), **"No batch #: 0 lines, 0 Kg blocked"**. Both live
records fully resolved.

### Next

1. The HG26026 Humic/PO 0254 thread (Ali Raza's "4,000 Kg" claim) is still open — needs
   Ali Raza or Majid directly, unchanged from earlier entries.
2. Everything else open before this entry is unchanged.

## 2026-08-27 (evening, later) — MODULE: O2S — Production Manager split, code done, live config pending

**Module: O2S** (continuing, same day).

### What happened

Tahir wants Production restructured: Abdul Majid is Production Manager and department lead,
wants oversight of every production process; Ali Raza and Jawad Naseer are Production
Officers doing the identical floor job (open batch, allocate floor/shift, log outputs,
packing) on different shifts. All three currently share one undifferentiated "Production"
role. His three decisions, gathered via AskUserQuestion: (1) genuine two-role split —
new "Production Manager" (Majid) vs existing "Production" (Ali Raza + Jawad Naseer,
identical); (2) Manager-only: void a shift's output, call a by-product / divert / rework,
and Data Fix edit access (corrections move off the floor) — explicitly **not** manager-only:
closing a batch, bulk or single, the floor keeps that; (3) production.void stays with
**both** Plant Manager and Production Manager (a senior-override choice, not a handover).

Investigation found the COO (Tahir, in the code's own comments) had already scoped most of
this on 25–26 Aug, before asking today — a block comment above the Production RIGHTS entries
already said "Production is a department with a HEAD (Production Manager) and FLOOR
OFFICERS... the split happens in the Authorisation panel." One real conflict surfaced and was
put back to Tahir directly: the 25 Aug note called Divert material "Production's own call"
(floor-shared), while his answer just now put it Manager-only — he confirmed Manager-only
stands, overriding the 25 Aug note. Also found "Plant Manager" already exists as a role, but
filed under Leadership (not Production) with senior cross-department sign-off rights — a
different, broader role than the new Production Manager, not a naming collision to worry
about; production.void had been parked on it only as a stand-in.

**First implementation attempt was wrong and reverted.** Editing the RIGHTS catalogue's
`legacy.roles` arrays directly (hard-coding `'Production Manager'` into each gate's role-name
check) passed the two dedicated suites but broke 57 checks in `authmodel.test.js` — a
brand-new role would get these rights for free, bypassing the grant/delegation machinery the
suite has tested since 24–25 Aug (section 32, "a brand-new head cannot pass on a right he
does not hold yet"). Reverted to a clean baseline (confirmed 5217/61 passing) and re-planned
around the mechanism the codebase already built and tested for this exact moment: convert
Production to `RIGHTS_LIVE`, let the grant table (`roleRights`) decide.

Verified first, in a sandbox, that this is safe on a live app: `seedDeptRightsV1` already
runs on every load (inside `ensureState`), and idempotently fills any role's undefined
grant cell from the *old* legacy check — so flipping `RIGHTS_LIVE` for Production's eleven
codes changes nobody's answer the moment it deploys (Production keeps all ten, Plant Manager
keeps `production.void`). Confirmed by simulation before touching the real file.

**Code change** (minimal, by design): added exactly the eleven Production right codes to
`var RIGHTS_LIVE={...}` in `o2s.html`, with a dated comment explaining the mechanism and
exactly what the live Admin steps still need to do. `legacy.roles` was deliberately left
untouched — it's the historical record `seedAnswer` still reads. The split itself (Production
Manager existing, holding rights, being department lead, Production losing the three
manager-only ones) is **not** a code change — it's the same live Admin configuration
(`addRole` / `setDeptLead` / ticking grants in Authorisation) already exercised generically
by `authmodel.test.js` section 32, now run for the real role names.

Fixed four existing test files that broke as a side effect (a test-harness gap, not an app
bug): `batchclose.test.js`, `certremove.test.js`, `lotpack.test.js`, `prodstuck.test.js` all
build a sandbox `state` straight from the fixture without running `ensureState`/
`seedDeptRightsV1` first — harmless before today (Production's gates were raw `hardRole`
checks needing no grant table), broken now that they're live. Added the same seeding call
each real app load already makes (`certremove`/`lotpack` also replay against historical
baseline HTML files that predate `seedDeptRightsV1`, so those two guard the call with
`typeof seedDeptRightsV1==='function'`). Updated one freeze assertion in `authmodel.test.js`
("nothing is live yet") and one brittle regex in `rights.test.js` ("neither customer right is
live yet") to state precisely what's now true instead of asserting `RIGHTS_LIVE` is empty.

Added `o2s/tests/production-manager-split.test.js` (new, 143 checks): runs the *exact*
approved grant sequence — role created (starts with nothing), the seven shared rights go to
both roles, the three manager-only rights move off the floor, `production.void` goes to both
heads, nobody else gets anything, Ali Raza and Jawad Naseer are proven identical by reading
`mayHere`/`mayRole`'s source (role-keyed, no per-user branch) rather than assumed, and Data
Fix access is proven to be a separate mechanism (`screenEditOK`/accessMatrix) untouched by
any of this.

**Full suite: 17 files, 6,592 checks, 0 failures.** All 5 inline `<script>` blocks parse
clean.

**Ready to push, not pushed.** A stale `.git/index.lock` (0 bytes) was found in the repo —
device-side tooling can't delete it and the user declined the delete-permission prompt for
this session; if GitHub Desktop refuses to commit, delete `VAN-OP\.git\index.lock` by hand
first.

### Files changed

- `o2s/o2s.html` — `var RIGHTS_LIVE={...}` now carries the eleven Production codes, with the
  dated comment explaining the mechanism (search "PRODUCTION, converted 27 August 2026").
- `o2s/tests/authmodel.test.js` — updated the "nothing is live yet" assertion.
- `o2s/tests/rights.test.js` — narrowed the customer-lock assertion off the whole-object check.
- `o2s/tests/batchclose.test.js`, `certremove.test.js`, `lotpack.test.js`, `prodstuck.test.js`
  — each now seeds `roleRights` before exercising a Production gate, mirroring `ensureState`.
- `o2s/tests/production-manager-split.test.js` — new, 143 checks, the approved matrix end to
  end.

### Next

1. **Push this.** Not done by this session — Tahir pushes via GitHub Desktop.
2. **Once deployed, and once the browser is reconnected** (disconnected as of this entry),
   do the live Admin configuration:
   - Admin → Authorisation: create role **"Production Manager"**, department **Production**.
   - Set it as the department's lead (`setDeptLead`).
   - Grant it: `batch.open`, `production.enter`, `shift.log`, `packing.pack`,
     `packing.reconcile`, `batch.close`, `batch.close_bulk`, `byproduct.call`,
     `packing.divert`, `packing.rework`, `production.void`.
   - On the existing **"Production"** role: revoke `byproduct.call`, `packing.divert`,
     `packing.rework`. Leave the other seven and `production.void`'s absence unchanged.
   - Admin → Access control matrix: **Production Manager** → Data Fix = Edit; **Production**
     → Data Fix = View (drop from Edit).
   - Users & Access: confirm/assign Abdul Majid to Production Manager; confirm Ali Raza and
     Jawad Naseer are (still) on Production. Their current live assignment was not checked
     this session — browser was disconnected throughout.
3. The HG26026 Humic/PO 0254 thread (Ali Raza's "4,000 Kg" claim) remains open, unchanged.
4. Everything else open before this entry is unchanged.

## 2026-08-27 (evening, later still) — MODULE: O2S — Production Manager split, LIVE CONFIG DONE

Picked back up once the browser reconnected ("chrome is a connected"). Code was already
pushed and deployed (`git log` shows `Production Rights` as the top commit, clean working
tree). Did the live Admin steps myself, verified every change via read-only JS state reads
(not just the UI/toasts) after each click.

**Done, verified:**

- Role **"Production Manager"** created, department Production, and set as the
  department's lead (`departments.find(d=>d.id==='production').leadRoleId ===
  'production-manager'`).
- All eleven Production rights granted to Production Manager: `batch.open`,
  `production.enter`, `shift.log`, `packing.pack`, `packing.reconcile`, `byproduct.call`,
  `packing.divert`, `packing.rework`, `batch.close`, `batch.close_bulk`, `production.void`.
- On the **Production** role: `byproduct.call`, `packing.divert`, `packing.rework` revoked
  (now false); the other seven stay true, matching the approved matrix exactly.
- `production.void` stays on **Plant Manager** too — "keep both" as decided, not moved
  exclusively.
- Access control matrix, Data Fix screen: **Production Manager** → Edit, **Production** →
  View (was Edit).
- Users & Access: **Abdul Majid** (`majid`) role changed from Production to **Production
  Manager**. **Ali Raza** (`ali`) confirmed still on Production, unchanged.

**Flag for Tahir — not resolved this session:** there is no user account for **Jawad
Naseer** anywhere in Users & Access (14 accounts total, checked the full list). Ali Raza
has his own login; Majid now has his own Production Manager login. Jawad either needs a
new account created on the Production role, or he's been sharing/using someone else's
login — worth checking before this split changes what "Production" can and can't do, since
whoever is actually doing his shifts needs to still be on the Production role to keep
floor access.

**Browser automation note** (only relevant if this comes up again): the Authorisation
screen's rights grid is wider than the viewport, and its first ("Right") column is
`position:sticky` but not width-constrained — at max horizontal scroll it still visually
and click-wise covers the role columns. Worked around per-session with an injected
`pointer-events:none` style rule on `.amxtbl tr > *:first-child`; did not touch the app's
actual CSS. Not filed as a code bug since it only affects scripted/automated use of the
grid, not a real mouse click at native resolution — flag if a person hits it too.

Everything else open before this entry (the HG26026/PO 0254 Humic thread) is unchanged.

## 2026-08-27 (night) — MODULE: O2S — Admin · Master Data redesign, code done, not pushed

Tahir's call after the Production Manager work above: the Admin screen itself was
"badly designed, no human can handle it" — right after I'd spent this session fighting
the Authorisation grid to grant rights. Traced it to a real bug, not just an
automation problem, then restructured the page.

**Root cause found:** the Authorisation grid's first ("Right") column had
`min-width:150px` and no cap. Its cell markup forced `white-space:nowrap` on the
whole cell — title AND the long explanatory note below it (e.g. the Divert-material
note). A long note with no wrap meant the column's natural width could run to
2000px+, and because that column is `position:sticky;left:0`, it sat on top of the
Production / Production Manager / Plant Manager checkbox columns for EVERY viewer,
not just scripted ones — the grant checkboxes were effectively unreachable on a
normal screen. This is very likely most of what "no human can handle it" was about.

**Fixed:**
- `.amxtbl td:first-child` now has `max-width:280px; white-space:normal;
  word-wrap:break-word` and the inline `white-space:nowrap` that caused the bug is
  gone from the row markup. Notes wrap inside a normal-width column now.
- Admin · Master Data was one endless scroll of ~20 collapsible cards with no way
  to jump anywhere. Split into three top-level tabs: **Reference data** · **Business
  masters** · **Access control**.
- Tahir separately asked whether Roles / Authorisation / Access control matrix
  really need to be separate tabs — they don't. Folded into the **Access control**
  tab as one card with a small **Rights / Roles / Screens** switcher inside it,
  instead of three stacked cards.

**Verified:** full suite still 6,592/6,592 (17 files, 0 failures) — the two source
guards in `authmodel.test.js` that check `screenAdmin()`'s literal text
(`${authCard()}`, `id="authwrap"`) still hold, since both survived inside the new
tab structure. Also wrote a one-off smoke test executing `screenAdmin()` itself
(not just source-text checks) across every tab × sub-tab combination — no runtime
errors, `$('view').innerHTML` renders sane output for each. That throwaway script
was not added to `tests/`; the structural coverage exists only in that ad hoc run,
worth a real test file if this area changes again.

**Not deployed.** Same as the Production Manager entry above — Tahir pushes via
GitHub Desktop; this and that change are both sitting in the working tree together.

**Not done / worth a second pass, not asked for yet:** the Access control matrix
(role × screen) still needs horizontal scroll across ~10 role columns — inherent to
a matrix layout, not touched this round. The Reference-data tab still stacks nine
small cards; nobody has said that one is a problem.

## 2026-08-27 (night, later) — MODULE: O2S — Authorisation, role-wise summary added

Tahir's next ask, right after confirming the tab redesign was live: "make it more
simple — a department-wise matrix, and in each department a role-wise view where I
can see how many users and what rights they carry." Also asked about retiring
seeded/demo user accounts in favour of fresh named ones, department by department,
starting with Production (as the Users & Access question, still open — see below).

**Done, tested, not yet pushed:** each department tab in Authorisation now opens
with a **role-wise summary** — one block per role, its headcount, and the exact
right codes it holds (e.g. "batch.open · production.enter · shift.log · ... (7 of
11)") — instead of only the grid. The interactive grid is unchanged underneath, just
folded behind a "Show the full grant grid" toggle for when someone actually needs to
tick something. Deliberately used right CODES (batch.open) not display names (Open a
batch) in the new summary, so it can't collide with the several existing tests that
locate a grid row by searching for the exact display-name text.

**Verified:** full suite 6,592/6,592 (17 files, 0 failures). One assertion did
legitimately catch a real issue on first pass — "a non-lead sees no tickable cell at
all" failed because the new disclosure toggle's `cursor:pointer` styling matched
its blanket cursor:pointer scan. Fixed by dropping that inline style (the toggle is
natively clickable without it) rather than loosening the test — the test's intent
(no non-lead can tick a right) still holds exactly as before.

**Not pushed.** Same push-via-GitHub-Desktop step as everything else today.

**Open, not decided:** Tahir asked whether to retire the current Users & Access
logins and (re)create fresh accounts for real people, starting with Production's
three (Majid, Ali Raza, Jawad Naseer — Jawad still has no login at all, flagged in
the entry above). I did not touch any user accounts this round — asked him first
what "retire and recreate" actually means for Ali Raza and Majid, who already have
real per-person logins today (only Jawad is missing one), before changing anyone's
working credentials on a live system.

## 2026-08-27 (night, later still) — MODULE: O2S — Production accounts retired & recreated (Phase 1 template)

Tahir confirmed: retire ALL 3 Production logins (not just the missing one), new username +
new password for each, usernames in firstname.lastname form. Executed live in Users & Access
(verified — no code change needed, this is admin-panel data, not o2s.html):

- Abdul Majid: username changed majid -> **abdul.majid**, role unchanged (Production Manager),
  password reset.
- Ali Raza: username changed ali -> **ali.raza**, role unchanged (Production), password reset.
- Jawad Naseer: brand new account, username **jawad.naseer**, role Production (previously had
  no login at all).

New passwords were generated and set live but are NOT written here — Tahir has them from this
session and needs to hand them to Majid/Ali/Jawad directly (out of band, not over this doc).

Used the existing "Edit person" flow (rename + password reset) rather than delete-then-recreate
for Majid and Ali, since O2S attributes historical batch/shift entries by a snapshotted
`byUser` username string, not a live foreign key — renaming in place keeps the account's role
and any live app logic intact and is lower-risk than delete+recreate. Confirmed via
`roleRightsOf()` that both roles still carry exactly the rights from the Phase 1 grant matrix
after the rename (Production Manager: 7 shared + byproduct.call/packing.divert/packing.rework/
production.void; Production: the 7 shared only) — the rights live on the role, not the
username, so this was unaffected as expected.

15 accounts total now (was 14). This is the template Tahir wants repeated department-by-
department over time — next department to redo this way is still open/undecided.

## 2026-08-27 (night, yet later) — MODULE: O2S — Production nav was invisible for the screens they already had access to

Tahir asked: does Production actually have enough access to do the job, and can
they see the relevant incoming/outgoing screens too? Checked the live accessMatrix
+ rights + the sidebar nav code together — found a THIRD, previously-undiscussed
permission mechanism behind the two already documented this session (RIGHTS/
roleRights, and accessMatrix/screenEditOK): the sidebar itself
(`allowedScreens()`) doesn't consult either of those — it filters purely on a
hardcoded `owners:[...]` array per screen in the `SCREENS` constant, untouched by
anything done live in Access control.

**Found, live, right now (before this fix):**
- **Abdul Majid (Production Manager) has an EMPTY sidebar.** `owners` was never
  updated when the role was created — 'Production Manager' appears in zero
  screens' owner lists. He lands on My Actions after login (that one screen checks
  access a different way) but from there has no nav path to Production, PO
  Tracker, Dashboard, Reports, Instructions, or Data Fix — despite already holding
  full rights and an explicit Data Fix edit grant.
- **Ali Raza / Jawad Naseer (Production) are missing Lab QC and Pre-shipment QA
  from the sidebar** even though accessMatrix already explicitly grants Production
  qc (view) and qa (edit) — someone configured that access at some point but the
  nav never reflected it. This is almost certainly the "incoming/outgoing screen"
  gap Tahir was asking about — QC (COA certifying output before packing) and QA
  (pre-shipment inspection before it ships) bracket Production's own work.
- Data Fix was in the same boat for both: already access-granted, invisible in nav.

**Fixed:** added 'Production' and 'Production Manager' to the SCREENS.owners list
everywhere they were missing — qc, qa, datafix (both roles), plus dash/approvals/
tracker/prod/reports/instructions for Production Manager specifically (mirroring
what Production already had). Also added both to **Shipments (ship)** — no
existing accessMatrix grant for that one, this was a judgment call on my part
given "outgoing" — it's view-only in practice (nothing anywhere gates an actual
dispatch action by screen ownership, only by the shipment.plan/shipment.load
rights, which neither role holds), so worth flagging but low-risk; easy to remove
from Users & Access → Admin · Master Data → Access control if not wanted.

Confirmed this is nav-visibility only, not a rights change: `screenEditOK()` (the
function that actually gates edit actions) is only ever called for the Data Fix
and Users & Access screens, and both roles' accessMatrix overrides on those two
already existed and are unchanged — so no one gained an edit capability they
didn't already have live. Also confirmed `screenLoopholes()` (the test suite's
cross-department-edit-leak detector) doesn't read SCREENS.owners at all, so this
couldn't have opened a new one.

**Verified:** full suite still exactly 6,592/6,592 (17 files, 0 failures) —
matches baseline. Also ran a standalone node check against the patched SCREENS
array confirming both roles now resolve to the same 10-screen nav: dash,
approvals, tracker, prod, qc, qa, ship, reports, instructions, datafix.

**Not pushed yet.** Same GitHub Desktop step as the other changes tonight.

## 2026-08-27 (night, yet later still) — MODULE: O2S — full access audit + Ismaeel/Finance fix

Tahir asked for a full department-by-department check: does everyone see what they
need (Finance, Production, Plant included), and grant anything that's lacking.
Also cleared up the "Ismaeel" confusion and asked for a general Finance role.

**Full nav audit — every role compared against its explicit Access control
grants.** Same bug pattern as Production Manager, found in seven more places
(access was granted in the matrix but invisible in the sidebar):

- **Plant Manager (Fahim)** — biggest gap. Added Sales & Budget, Customer Master,
  New PO Entry, Production, Shipments, and Users & Access to his nav — all
  already explicitly granted in the matrix, none of it reachable before.
- **Supply Chain Officer (Zain)** — sidebar was completely empty (identical bug
  to Majid's original one). Added Dashboard, My Actions, PO Tracker, Production
  (view), Lab QC (edit), Shipments (edit), Reports (edit), Instructions.
- **QA Inspector** — added Production (view-only — this is the correct,
  already-fixed state per the loophole closed earlier; see authmodel test
  section 24) and Reports.
- **AQCM, QCM, Lab Rep** — all three added to Reports (each already had an
  explicit Reports edit grant, invisible in nav).
- **CFO (Yawar)** — added Customer Master (edit) and New PO Entry (view), both
  already explicitly granted.

**Ismaeel / Finance, sorted out.** The role at `id: finance, deptId: finance`
had its display name accidentally set to a person's name ("Ismaeel") instead of
a functional name. Tahir confirmed: Muhammad Ismail (username `ismaeel`) really
is a Finance desk officer whose job is raising POs and confirming delivery when
site sends back the paperwork — nothing to do with the broad Admin/Customer
Master/Lab QC access that role happened to carry.

- Renamed the role **"Ismaeel" → "Finance Desk Officer"**.
- Rebuilt its access matrix from scratch to match his actual job only: **New PO
  Entry** (edit — `order.create`) and **Shipments** (edit — `delivery.confirm`,
  the "mark delivered" action, which is how he confirms receipt from site — NOT
  the Plant-Manager-only DC *approval* gate, which stays untouched and hard-locked
  as it's always been), plus PO Tracker (view) and the usual Dashboard/My
  Actions/Instructions baseline. Stripped Admin edit, Customer Master edit, and
  Lab QC view — none of that matched his job.
- Reassigned Muhammad Ismail's live account from KAM → Finance Desk Officer.
- There was also a second, orphaned "Finance" access-matrix entry (Reports edit,
  My Actions + Sales & Budget view) that didn't match any role name — separate
  from the Ismaeel mess, already reasonably configured. Created a real **"Finance"**
  role against it (id `finance-2`, department Finance) so it's selectable and
  usable — nobody assigned yet, ready for when Tahir adds more finance-team
  people who just need to track budget/reports.

**Verified, not just wired:**
- Confirmed both of Ismaeel's rights actually resolve live: `may('order.create')`
  and `may('delivery.confirm')` both return true for Finance Desk Officer, and
  false for the Plant-Manager-only DC approval functions (`approveDC` etc. —
  untouched, still `hardRole(['Plant Manager'])`, not in the rights catalogue at
  all, exactly as the code's own guard rail requires).
- Ran the app's own `screenLoopholes()` check (the thing that caught the QA
  Inspector/Production loophole earlier) against every new grant this round —
  **0 loopholes**, before and after. Nothing new can reach a right it wasn't
  supposed to.
- Full suite: still exactly 6,592/6,592 (17 files, 0 failures).

**On "make sure nothing is seeded and every right is solely from the matrix":**
checked what's still hardcoded outside the rights matrix (`hardRole(...)` calls).
What's left is deliberate, not accidental: the Lab QC certification sign-off
chain (Analyst → AQCM → QCM, plus Plant Manager deviation/rework), batch
reopening, and the DC-approval/truck-release trio — all explicitly guarded by
the test suite as controls that must NEVER become matrix-delegable (the DC one
is tied to a documented 2026-07-30 incident). Did not touch any of these. Every
role's day-to-day screen access now genuinely reads off Access control — the
data-hygiene mistakes found and fixed this round were role naming (Ismaeel) and
missing nav wiring (this + the Production Manager round), not hidden rights.

**Not pushed yet.**

## 2026-08-27 (night, final) — MODULE: O2S — correction: the nav-visibility diagnosis was wrong

Correcting the record on the last two rounds of "sidebar" work.

**What was wrong:** I diagnosed Plant Manager / Supply Chain Officer / QA
Inspector / AQCM / QCM / Lab Rep / CFO as missing screens from their sidebar
by testing `allowedScreens()`. That function isn't what builds the sidebar —
`renderNav()` is, gated by `canView()` (`accessLevel()!=='none'`), which
defaults every screen to **visible** unless the access matrix has an explicit
`v:false`. `allowedScreens()` is only used for a rarely-hit post-login landing
fallback. So the "empty sidebar" / "missing screens" claims for those roles
were mostly false — checked live via `canView()` directly and confirmed most
of what I said was missing was actually already visible by default.

**Consequence:** both `SCREENS.owners` patches this session (the Production
Manager one and the 7-role one) turned out to be functionally inert — real
edits, tests still pass, nothing broken, but no observable effect on the live
app, since nav visibility never reads that array. Left in place rather than
churn more diffs for zero behavioural gain; flagged to Tahir, he didn't ask for
a revert.

**What was actually true and got fixed, live, via the real mechanism
(`accessMatrix` explicit `v:false`/`v:true`, not `owners`):**
- **Plant Manager (Fahim) really couldn't see the Dashboard** — genuine
  explicit `dash:{v:false}`, not a phantom bug. Tahir confirmed he should see
  it. Fixed: `dash:{e:false,v:true}`.
- **Finance Desk Officer defaulted to seeing Production** (view-only) because
  no explicit block existed for it and visibility defaults open. Tahir said he
  shouldn't. Fixed: `prod:{e:false,v:false}`. His other default-visible extras
  (Pre-shipment QA, Reports, Dashboard, Instructions, view-only) — Tahir said
  those are fine as they are.
- Supply Chain Officer's Dashboard block was raised in the same question but
  Tahir only confirmed Plant Manager — left Zain's `dash:{v:false}` untouched
  rather than assume.

Both changes verified live (`canView()` checked pre- and post-reload — persists
correctly). No source file change, no push needed for this part.

**Lesson for next time:** when checking "can role X see screen Y", always use
`canView(role, screenId)` (or better, spoof `state.role` and look at the
rendered sidebar directly) — never `allowedScreens()`.

## 2026-08-27 (night, truly final) — MODULE: O2S — session close-out

Tahir's calls on the two open questions, applied live and verified after reload:
- **Plant Manager**: Dashboard restored (`dash:{v:true}`).
- **Finance Desk Officer**: blocked from Production (`prod:{e:false,v:false}`);
  everything else he could already see (Pre-shipment QA, Reports, Dashboard,
  Instructions, view-only) left as is, per Tahir's "rest he can see is fine."

Then ran one more full systematic sweep — for every role, every screen where
that role is a listed default owner (i.e. it's genuinely their job), checked
for an explicit access-matrix block. Five hits:

- Lab Rep, AQCM, QCM — all explicitly blocked from Admin · Master Data. Judgment
  call, not obviously wrong (could be a deliberate later tightening) — flagged,
  NOT changed.
- Supply Chain Officer — blocked from Dashboard. Raised earlier alongside Plant
  Manager; Tahir confirmed Plant Manager only. Left alone.
- **QA Inspector — explicitly blocked from Pre-shipment QA, their own primary
  screen.** Unlike the other four, this one has no plausible deliberate
  reading — it's the literal reason the role exists. Fixed without asking:
  `qa:{e:true,v:true}`.

First save attempt for the QA Inspector fix silently didn't persist (a debounce/
navigate race — reloaded and found it still blocked). Second attempt called
`saveNow()` directly and awaited it before reloading; confirmed persisted.
Lesson: after any live accessMatrix edit, always reload and re-check before
calling it done — `save()`'s 400ms debounce can lose a change if the tab
navigates before it fires.

Final state, verified live post-reload: `screenLoopholes()` → 0. 15 user
accounts, all correctly matched to their roles (dumped and eyeballed one more
time — Ali Raza/Jawad Naseer → Production, Abdul Majid → Production Manager,
Muhammad Ismail → Finance Desk Officer, Zain → Supply Chain Officer, everyone
else on their original built-in roles). No orphaned access-matrix keys left
(the "Ismaeel" key is gone, moved to "Finance Desk Officer"; "Finance" claimed
by its new role). No code push needed for anything in this entry — all pure
live access-matrix data, verified surviving a reload.

**Open items for whenever Tahir wants to pick them up, not urgent:**
1. Lab Rep / AQCM / QCM's Admin block — confirm intentional or lift it.
2. Whether Supply Chain Officer should get Dashboard back too (parked, not
   decided).
3. Assign someone to the new "Finance" role when there's a real person for it.
4. Repeat the "retire seeded, create named accounts" pattern for another
   department when ready (Production was the template).
5. The much older HG26026/PO 0254 Humic thread (Ali Raza's "4,000 Kg" claim) —
   still untouched, unrelated to tonight's work.

## 2026-08-29 — MODULE: O2S — New PO Entry: field alignment/spacing pass, code done, not pushed

Tahir flagged three UX problems on New PO Entry (`o2s/o2s.html`, `screenEntry()` /
`renderEntryLines()` / `entryChecks()` / `validate()`) from a screenshot of the live
form, and asked for questions before any change. Four questions asked and answered:

1. "Pack" column header was ambiguous next to the "Packs" (count) column beside it.
   → Renamed header to **"Pack Size"**. No other layout change to that column.
2. "Which price goes on the pack" block (amber box, 3 buttons + a paragraph) was the
   biggest space hog in Step 2.
   → Kept the 3 buttons (list / PO price / no price) and the client-history + "not
     answered" hints on one compact header line, but moved the 3-line definitions
     of what each option means behind a small **(?) toggle** (`#e_pricehelp`,
     hidden by default). Nothing about the underlying answer/validation logic
     changed — same `entryPrintOn`/`entryPrintMode()` machinery.
3. The "envision sending this to a dealer/distributor" framing — Tahir confirmed
   this round is just about cleaning up the entry screen itself, not a new
   customer-facing output. No PO Confirmation document was built. Parked for later
   if/when he wants one (would need to hide KAM Name, FED override, invoice
   PKR/Kg, etc. — noted for whenever this comes up again).
4. Step 3 — Validation (a 16-row checklist, ✓/✗ against every rule, always visible)
   → **Removed the standalone Step 3 card entirely.** Its `may('order.create')`
     permission line moved to a small `#e_submit_note` slot next to the Submit
     button (that's an access-rights notice, not a field validation, so it's kept
     separate from field-level markers). Field-level failures now show as a red
     border (`.inv` CSS class) directly on the offending input: Channel/Client/
     Vgreen-Sub/KAM/PO-Received/Promised/PO# in the header, and per-line Pack Size/
     Invoice price/Committed date/Print price in the line-items table. The
     duplicate-PO-number case gets its own small red line under the PO# field
     (`#e_po_msg`) since a bare red border wouldn't say *why*. Header-level markers
     are gated on `entryChannel` being set, so a completely untouched form doesn't
     light up red on load — only once the KAM is actually mid-flow. Submit button
     disable logic (`ok` from `entryChecks()`) is untouched; nothing about what
     counts as valid changed, only how it's surfaced.

**Not done, deliberately:** no attachment feature (was already held back from the
2026-08-26 redesign, per Tahir — untouched here), no new customer-facing document
(per Q3 answer above).

**Verification:** `node --check`-equivalent parse of all 6 inline `<script>` blocks
in `o2s.html` — clean. Ran the full `o2s/tests/*.test.js` suite (18 files,
`poentry.test.js` included) against the live source via the existing `harness.js`
sandbox — **every file passes, 0 failures** (poentry.test.js: 24/24; full suite
totals several thousand assertions across rights/auth/production/batches/etc.,
all green). Did not get a live-browser screenshot this round — starting a local
`node server.js` for a Chrome check didn't survive the device shell's per-call
lifetime; relying on the test suite + careful source review instead. Worth a
visual eyeball next time Tahir has the app open.

**Files changed:** `o2s/o2s.html` only. Nothing in `server.js`, nothing in `pd/`.

**Not pushed** — per standing rule, Tahir commits/pushes via GitHub Desktop.

**What's next:** Tahir mentioned "pending task" to resume after settling these
issues — not yet named in this session. Also worth a real-browser look at the new
inline red markers and the (?) toggle before considering this fully done.

## 2026-08-29 (later) — MODULE: O2S — New PO Entry: real column-width bug found and fixed, not pushed

Tahir had already pushed/deployed the earlier session's change (the redesigned
"Which price goes on the pack?" box, the removed Step 3 card, inline red
markers) — confirmed live on `van-control-tower.onrender.com/o2s`, logged in
as COO. He then flagged: "field size and text is not fixed yet."

**What was actually wrong (bigger than the label text):** the line-items table
(`table.fixedtbl`, `table-layout:fixed`) has 9 columns; 8 of them carry an
explicit pixel width (originally summing to 850px) and **Brand — the single
most important field, the product picker — had no width at all.** With
`table-layout:fixed`, a column with no specified width is only supposed to
get a share of *leftover* space once the table has a definite width. But this
table has no CSS width of its own, and its flex container (`.po-main`,
`flex:1.6` in the two-column `layout2` row next to the sticky Order Summary
sidebar) only gives it **~589–780px** at a normal laptop window — already
less than the 850px the other 8 columns demanded. Brand collapsed to **0px**
(confirmed with `getBoundingClientRect()` on the live page — literally
`width: 0`), and the table silently overflowed its container rather than
shrinking, so widening or renaming a header (like "Pack" → "Pack Size" last
session) could overflow into the sidebar instead of just wrapping cleanly.
That's the real shape of "field size and text is not fixed" — it's a layout
bug, not a copy-editing one.

**Verified the fix live before writing it to source** — injected candidate
CSS widths directly into the running deployed page via the browser console
and re-measured with `getBoundingClientRect()`/`scrollWidth` (see method
below) rather than guessing:
- Gave every column an explicit width, Brand included: Brand 150 · Form 78 ·
  Pack Size 76 · Qty 74 · Packs 54 · Invoice price 188 · Committed 118 ·
  Note 125 · (remove-line button) 26 — total 889px, vs. the old 850+0.
- Shortened the Invoice-price header from "Invoice price · PKR/Kg + PKR/pack"
  to **"Invoice price · Kg + pack"** (the PKR is already on both input
  placeholders inside the cell) — freed enough room that the header stops
  fighting for space at the old width.
- **Wrapped the table in a `.linewrap{overflow-x:auto}` div.** This is the
  part that actually makes it robust: instead of tuning pixel widths to one
  window size and having it silently break again on a smaller screen (or the
  next time a label gets longer), the table now scrolls horizontally inside
  its own card on any window narrower than ~890px, and never again bleeds
  into the sticky sidebar. Stress-tested against the longest real brand name
  in the live catalog ("Naya NPK- Powder", Syngenta) — fits/clips sensibly,
  no layout breakage.

**Verification method, for next time this table needs touching:** don't
trust `scrollWidth === clientWidth` on the header `<th>` alone near the
margin (it can read as "no overflow" while still being a hair too tight and
rendering an ellipsis) — measure the *natural* text width with an offscreen
span using the header's real computed font/letter-spacing/text-transform and
compare against the column's content-box width instead.

**Files changed:** `o2s/o2s.html` only — the `.fixedtbl` CSS block (added
`.po2 .linewrap`) and the Step 2 line-items `<table>` markup (column widths +
the wrapper div). No JS logic touched. Re-ran the full `node --check`-style
parse of all inline `<script>` blocks (clean) and the full `o2s/tests/*.test.js`
suite (18 files) against the patched source — **all still pass, 0 failures**
(poentry.test.js: 24/24).

**Not pushed** — Tahir commits/pushes via GitHub Desktop as usual. Once this
one's live, worth a look on his actual laptop screen (not just the browser
window size used here) to confirm it reads comfortably.

## 2026-08-29 (later still) — MODULE: O2S — Dashboard rebuilt around the 12 questions Tahir actually asks, not pushed

Tahir's framing this round: O2S was built to replace Excel because management had
no visibility — now people use Excel *and* the system, and he still has no
visibility. He'd opened the Dashboard; it wasn't wrong, it just wasn't answering
what he asks people on the phone every day. He gave a precise list: today's
production, what was produced, what was packed, which PO was packed, what shipped
today (brand, client), which PO is running behind and why, why batches aren't
closed, why QC rejected, wastage, who's logging on time and who isn't — all for a
day, a week, or a date range he picks. Explicitly not interested in budget/target %
("this system is not meant for it, its an add on"). Decision: rebuild the whole
Dashboard, not a new tab; keep Financial as its own tab for CFO; build the two
items that needed real new logic (stuck-batch detection, full entry-timeliness)
now rather than defer them.

**What was found before writing anything:** almost everything on the list already
existed as real, dated, per-event data — `productionLog`, `packingLog` and
`shipments` are all dated and filterable; `delayReason`/`respDept` per PO line
already capture why a PO is behind; `coaReject()` already captures why QC
rejected; `batch.packReconcile` already captures wastage with a reason
(`lossReason`) and its cost/revenue impact. A full "Report Builder" already
existed under Reports with 13 date-filterable datasets — real, wired to live
data, just generic (pick a dataset, read a table) rather than answering the
question directly. The two real gaps: a batch sitting open has no "why is this
stuck" signal (only `openedDate`, no reason) — same shape as the `isOverdue`/
`isStalled` pattern already used for orders, just never applied to batches. And a
late-entry mechanism (`evStamp`/`evDateField`, capturing `recordedAt` vs the
claimed date with a reason once late) already existed but only covered packing,
lab QC and dispatch QC — not production shift logging or the shipment/dispatch
form itself, the two most important ones for "who's logging on time."

**What was built:**
- A shared date-range control (`dashRange`/`dashRangeBar()`/`dashOpsMetrics()`) —
  Today / Yesterday / Last 7 days / This week / This month / Custom — used across
  every Dashboard tab instead of each tab hardcoding "today" or "last 7 days"
  separately.
- `stuckBatches()` / `isBatchStuck()` — a batch counts as stuck once it's been
  open 7+ days with no shift logged against it in the last 3, mirroring the
  existing order-level `isStalled()`. Surfaced with age, idle days, and
  produced/planned on Overview and Production.
- Entry-timeliness extended to production and shipment logging: `evStamp`/
  `evDateField` (kinds `shift` and `ship` — thresholds already existed in
  `EV_DEFAULT_THRESHOLD`, just unused) now wired into `submitShiftLog()` and
  `saveDispatch()`. This is **soft/visibility-only, not a submission block** — a
  hard `evDateGate()` was tried first (matching lotqa/packinsp/dispqa) but broke
  9 real test cases and a full-suite crash (`certremove.test.js`) because
  historical fixtures use fixed dates that read as "late" against today's real
  clock; blocking on that would also block Tahir's own people backfilling
  yesterday's shift the next morning, which is normal, not a violation. Kept the
  warning + optional reason capture, dropped the hard block. Existing historical
  entries have no `enteredLate`/`recordedAt` (that data starts now, going
  forward) — the "who's on time" table will be empty until new entries accumulate,
  and says so rather than showing a fake number.
- **Overview tab, fully rebuilt**: dropped the budget/target-led framing (Money
  section, by-client budget chart, "% of budget" verdict) — that content now
  lives only on the Financial tab. Leads with produced/packed/shipped for the
  chosen range, then: POs running behind (live status, not range-limited, with
  reason + department), batches not closed (live, with age/idle days), QC
  rejections for the range (with why), wastage for the range (with reason per
  batch, plus the existing cost/revenue-impact figures), and who's logging late
  (by person, with reason). Kept the reconcile-breakdown and turnaround charts,
  clearly labelled all-time since they're cumulative, not range-scoped.
- **Production, Quality, Supply chain, Centers tabs**: each gets the same range
  control; Production adds the stuck-batch list and produced-by-product; Quality
  adds QC rejections with reason and late QC/inspection entries; Supply chain
  adds shipped-by-brand/by-client and the POs-behind table; Centers adds
  produced-by-product for the range. Floor-status KPIs (in production, awaiting
  QC, open load, etc.) stayed as live snapshots — a date range doesn't change
  what's on the floor right now.
- `dashNarrative()` (the one-line strip shown above every tab) no longer leads
  with "% of budget" — it's produced/packed/shipped for the range, POs behind,
  batches stuck.

**Verification:** no local live-browser check this round — trying to run the app
locally to preview against Chrome hung on `store.init()` (likely DB connectivity
in this environment) and never bound a port, so that path was dropped rather than
forced. Verified instead by: the syntax check across all inline `<script>`
blocks (clean); the full existing `o2s/tests/*.test.js` suite, now 18 files,
5219+ assertions, all still passing after fixing the two regressions the hard
date-gate caused; and a new `o2s/tests/dashboard.test.js` that loads the whole
app into the harness sandbox against the real `data/state.json` snapshot and
actually calls `dashOpsMetrics()`, `dashExecHtml()`, `dashNarrative()` and
`screenDash()` for every tab, across 7 roles and 5 date-range modes (140
checks) — confirming no exceptions, no `undefined`/`NaN`/`[object Object]`
leaking into rendered HTML, for combinations a single manual click-through would
likely have missed. Spot-checked the real numbers against the live snapshot for
a Jan–Aug 2026 range: 338,075 Kg/L produced, 501,860 packed, 370,807 shipped,
44 POs behind schedule, 48 stuck batches, 7,467 Kg/L wastage — all plausible
against real client/product names, not placeholder data.

**Files changed:** `o2s/o2s.html` only (date-range engine, stuck-batch
detection, entry-timeliness wiring, all five Dashboard tab render functions,
`dashNarrative`). `o2s/tests/dashboard.test.js` added.

**Not pushed** — Tahir commits/pushes via GitHub Desktop as usual. Worth a real
look on his screen once live, since this is a full rebuild of the screen he
actually opens every day, and the "who's logging on time" table will read empty
at first (by design — it only counts entries made after this ships) until a
few days of real entries accumulate.


## 2026-08-29 (round 2) — MODULE: O2S — Dashboard: actually looked at the rendered page, found and fixed real defects the tests couldn't see

Tahir's instruction after the first pass: stop trusting logic/test-only verification, go look at the rendered Dashboard, and honestly judge whether it looks like a real dashboard. This entry covers what that produced.

**Method.** Built a disposable, credential-free live preview entirely in the cloud sandbox (never touched the real device data): staged a tarball of the repo (o2s, pd, data, server.js, package files, node_modules) into the cloud container, ran the real server there, opened it in headless Chromium via Playwright, and reached the authenticated app by injecting `state`/`state.currentUser` directly (matching the existing test-harness pattern) instead of touching any login field — then screenshotted Overview, Supply chain, a wide Custom date range, Production, Quality, Centers, and Financial, across the COO role, and actually read the images.

**Found and fixed (round 1 of the visual pass):**
1. Two competing date-range pickers — a new one built for this rebuild, and the pre-existing global "Reporting period" control in the topbar (`state.period` / `periodWindow()`) that already existed for the Production log export. Retired the new one entirely; extended the existing control instead (added Today/Yesterday/This week/Custom, two custom-date inputs, a `syncPeriodBar()` hook wired into `render()`). One control for the whole app now, and it visibly syncs.
2. "44 POs behind" headline sitting next to a pre-existing "18 Overdue" figure on the same screen — a lines-vs-distinct-orders mismatch. Added `behindPOCount` (distinct POs) and used it in every headline/summary sentence, while the detail table stays line-level with an explicit "one row per product line" label.
3. "Where orders are sitting" panel rendering twice on the Supply chain tab (dashSupplyHtml + dashShipHtml both ran it before the rebuild added more content around it, which made the duplication obvious). Dropped it from dashSupplyHtml's return; dashShipHtml's copy (rendered right after) is kept.
4. Stale "Executive overview" page subtitle left over from before the Overview rewrite. Updated.

**Found and fixed (round 2, after re-screenshotting the round-1 fixes):**
5. In the Wastage section on Overview, a card labeled plain "Produced" (all-time total output) sat directly under the top KPI row's card also labeled "Produced" (period-scoped) — same label, different scope, easy to misread as the same number. Relabeled to "Produced (all-time)" with clearer context text. Re-ran the full test suite (17 files, 0 failures) and re-screenshotted to confirm.

**Found, not fixed — flagging for a decision:**
6. PKR figures still appear outside the Financial tab: "Value of loss · cost" / "Value of loss · invoice" in Overview's Wastage section, and "Revenue at risk" on Supply chain. These read as operational cost-of-failure numbers rather than budget/target tracking, so left in place rather than guessing — but noting it since Tahir was explicit that financial framing should stay confined to its own tab.
7. Centers tab, "Turnaround by center": QC → delivery shows **-3d** (a negative stage duration) in this data snapshot. Pre-existing `execMetrics()` per-stage timestamp logic, not touched by this rebuild — needs its own look before trusting that number anywhere.
8. Chart.js-based charts (reconcile breakdown, turnaround, dispatched/throughput trend) render blank in this cloud sandbox only, because its egress policy blocks cdnjs.cloudflare.com — confirmed by comparing against the hand-rolled SVG charts on the same screenshots, which render fine. Not a code defect; should not occur on the real Render deployment where the CDN is reachable, but flagging so it's not mistaken for a regression if seen again in a similar sandboxed context.

**Verification:** synchk-style load, all 17 pre-existing `o2s/tests/*.test.js` files (0 failures), `dashboard.test.js` (168 passed, 0 failed), plus the visual pass above across Overview/Centers/Production/Quality/Supply/Financial.

**Files changed:** `o2s/o2s.html` only (one label string this round; period-picker unification and behindPOCount/dedup/subtitle fixes were already in place from round 1 and are unchanged here).

**Not pushed** — per CLAUDE.md, Tahir pushes via GitHub Desktop.


---

## 1 Sept 2026 (later same day) — prototype gaps closed: B13, B14, B17, B18

While Tahir fills in `PD-Material-Grade-Template.xlsx`, kept building the fake-data
clickable prototype (`pd-prototype.html`, published as a Cowork Artifact — link
unchanged). Four gaps closed, all fake data, nothing from the ERP browsing session
or the real material list touched:

- **B13 — reclassification.** A Problem's type (Field problem / Product concept)
  can now be refiled from its detail screen. No reason required — the "why" shown
  to the person who filed it is auto-generated from the type's own definition, per
  `RECLASSIFICATION-RULES.md`. Permanent history (from/to/when/mover/note) shown
  on the Problem; content stays editable, history doesn't. A notification banner
  uses the spec's preferred phrasing ("Your entry became a...") with an
  "I meant something else" reply link. Scoped to converting a Problem's type only —
  the full spec's merge/split/bulk/other-record-types are named in-app as not
  demoed here, not silently skipped.
- **B14 — Run lineage.** Logging a new Run can mark it as replacing an earlier one
  (any Run, picked from a dropdown). Both Runs show the link — "replaces" and
  "replaced by" — in either direction. Both stay on record; nothing is deleted.
- **B17 — Claim directly against a Problem.** A Problem's detail screen now has
  its own "Claims directly on this Problem" section and form — for something
  already known (a literature fact, a pre-PD result) that doesn't need a Bet and
  Run invented just to hold it. Counted in the Dossier and the Report alongside
  Run-closed Claims.
- **B18 — Observation from inside a Run.** A Run's detail screen can now spawn an
  Observation door mid-run, not only from "What came in." Defaults to attaching to
  the Run's own Problem; a checkbox leaves it untriaged if it looks like it belongs
  elsewhere. Feeds the same triage queue as an intake-time Observation.

**Not done:** no schema or code against the real 9-object model — this is still
the fake-data prototype only. B2/B3/B4 (material list, assay figures, controlled
vocabularies) still await Tahir's fill of the template. B16 (cross-product
material signal) untouched. B9-B12 vocabularies still await Tahir's confirmation.


---

## 1 Sept 2026 (later still) — material list returned, B16 designed, B4 template built

**Material list, first return.** Tahir's team sent back `PD-Material-Grade-Template.xlsx`
partially filled: physical form added to every row, 11 assay figures confirmed as
real lab data on existing candidates (Sulfur S 80%, SOP/KOH/K₂CO₃/MOP K₂O
50/70/60/60%, Amino Acid N 50%, Zinc Sulfate Zn 33%, Phosphoric Acid P₂O₅
50/52/55%, Zinc Oxide Zn 80%), and 21 new materials named. Asked clarifying
questions rather than sending it back for another pass, per instruction — three
ambiguous names resolved: SPM = Sugar Press Mud, Poltary = Poultry Waste (OM),
MEA perkin = Monoethanolamine from a supplier called Perkin. Archived with those
three annotated: `combination-bank/PD-Material-Grade-Template-RETURNED-1Sep2026.xlsx`.
Grades for the 21 new rows, and for most of the original 24 candidates, are still
open — not addressed in this pass. `PENDING-DECISIONS.md` B2/B3 updated to record
this precisely.

**B16 — cross-product signal by shared material — design drafted.** Added
`combination-bank/RULES.md` §9.3: reuses the existing material-register index
(no new index, no tenth object), delivered as an auto-generated Observation
(reusing B18's mechanism) when a Challenge/Observation/Claim tagged with a
material, or an abnormal Run, matches another active Bet/Run/Problem using the
same substance. Matching is substance-level by default, scoped to active work
only. Three open questions left deliberately unresolved at the end of that
section. Not built, not confirmed — same status as B9–B12. Also fixed a stale
cross-reference in `RULES.md` §12 (“five signals” → “six”, missed when §7.1 was
corrected earlier the same day).

**B4 — controlled vocabularies template built.** New file
`combination-bank/PD-Controlled-Vocabularies-Template.xlsx` — Form, Route,
Crop/Soil/Problem tags, every value traced to the repo's own demo file
(`combination-bank-demo-v6.html`) or `MODEL.md`, nothing from the ERP. Surfaced a
real inconsistency while building it: Route is two different, partly-overlapping
lists in two different files (`RULES.md` §4.1's 4-value list vs. `MODEL.md` §3's
6-value delivery-context list) — flagged in the template for Tahir to rule on,
not resolved unilaterally.

**Not done:** grades/assays for the new materials and most of the original 24;
Route reconciliation; B16 trigger events, matching key and scope all still open
questions; controlled vocabularies still need Tahir's actual answers, not just a
template to answer them in.


_Same day, addendum:_ both templates (`PD-Material-Grade-Template-RETURNED-1Sep2026.xlsx` and `PD-Controlled-Vocabularies-Template.xlsx`) sent back to the team for the next pass. Nothing further from this side until they come back.


---

## 4 Sept 2026 — O2S: focal person, DC batch-number removal, delivery-confirm escalation, Fruitlish base fix

**MODULE: O2S** (`o2s/o2s.html`). All changes below are made, `node --check`'d,
and pass the full suite (`for t in tests/*.test.js; do node "$t"; done` — 18
files, all 0 failed; `authmodel.test.js` 5219/5219). **Not pushed** — sitting as
local changes for Tahir to push via GitHub Desktop.

- **Customer focal person at dispatch.** Both truck-creation flows
  (`openDispatch`/`renderDispatchModal`/`saveDispatch` for single-order dispatch,
  and `mpStart`/`renderMPShip`/`mpCreate` for multi-PO truck loads) now carry an
  editable "Customer focal person" field, pre-filled from the order's
  `focalPerson` when set, persisted onto the shipment record either way. Prints
  on the DC.
- **Internal batch number off the DC / Gate Pass.** `printDC()` no longer emits
  the "Internal batch" column — header and row templates both cut down by one
  cell. Pack-time batch # (customer-facing) is unaffected.
- **Delivery confirmation stays with Supply Chain, permanently.** Removed the
  `alsoOn` escalation path to Plant Manager on `delivery.confirm`
  (`RIGHTS['delivery.confirm']`). Per the COO's ruling (relayed by Tahir): this
  never hands off to another role. Instead, `acEscalation()`'s
  `'Confirm delivery'` entry re-flags to **Supply Chain itself** after 3 days —
  same owner (Saad Jamal's existing Supply Chain login), same role, just a
  louder ⚠ badge on his own row. `authmodel.test.js` §29 WANT fixture updated to
  match (`alsoOn: 'approvals:Supply Chain'`); §30 self-derives from the live
  `acEscalation` source so needed no manual edit.

**Production-floor bug report, part 1 — Fruitlish's base corrected.** Fruitlish
was registered against itself as a base (`SEED.brandMap['Fruitlish'].base ==
"Fruitlish"`), so `brandsForBase()` never offered Fruitlish as a pack target for
VL-Potash batches — blocking the pending Fruitlish order for ARYSTA LIFE
SCIENCES (PVT) LTD, PO 7500003954, from being repacked out of already-produced
VL-Potash stock. Fixed at the master-data level, both places the registration
lives: `SEED.brandMap['Fruitlish'].base` and the ARYSTA `brandsByClient` catalog
entry both now read `"base": "VL-Potash"`. Fruitlish is no longer a base in its
own right. Verified this doesn't disturb `divTargets`/`submitDivert`'s
same-base check (both key off `base`, not brand, so they pick the corrected
value up automatically) and re-ran the full suite clean.

**Production-floor bug report, part 2 — BKK / V-Transfarm, PO
PUR-ORD-2026-00592 — diagnosis only, not fixed.** V-Transfarm's master
registration is fine (`brandMap['V-Transfarm'].base == "Zinc 21%"`, matches the
`brandsByClient` BKK catalog entry exactly) — unlike Fruitlish, this is **not**
a master-data bug. Produced 300/300, Packed 300/300, QC "—" not done, invisible
in both QA and Shipment for this PO. Traced the QA-visibility chain
(`lotsFor→lotAvail/lotHasBatch→lineToInspectTotal→linesToInspect()→screenQA()`)
and the Shipment-readiness chain (`lotClearedKg→lineCleared→readyLinesFor`) —
both depend on `state.packingLog` rows matching the order by `po` (and `lid` if
set, else `brand`). Given the documented precedent (Kashmir Sugar Mills / VL-Potash
PO 06493, a same-brand two-line `lid` mismatch fixed as one-off data surgery),
the leading hypothesis is a `packingLog[].po` string mismatch or missing/mismatched
`lid` for this PO's V-Transfarm rows — not something visible without querying the
live MySQL data, which isn't reachable from here. Left Tahir a one-off browser-console
snippet to run on the live O2S page and paste back the output (dumps `state.orders`'s
PUR-ORD-2026-00592 line + every `packingLog` row that does/doesn't match it), so the
actual mismatch (if that's what it is) can be pinpointed before writing a fix.

**Not done:** BKK/V-Transfarm root cause not yet confirmed against live data;
no fix written for it this session, pending Tahir's console-snippet output.

_Same day, addendum:_ verified all four fixes live in production
(van-control-tower.onrender.com/o2s) by reading the running app's own state
after a hard reload — `SEED.brandMap['Fruitlish'].base`, the ARYSTA catalog
entry, the DC template, the focal-person field, and the `acEscalation`
Supply-Chain-only rule all match the pushed code. One rough edge hit along
the way: right after the fix was already deployed, this same browser tab
(left open from earlier in the session) still evaluated the *old* Fruitlish
base until a manual reload — the app has no build-stamp / cache-bust check
on load, so a tab open across a deploy can silently keep running stale
logic. Not something this session touched; flagging it as a real (small)
gap, not a one-off.

---

## 4 Sept 2026 (later) — stale-tab version check + a full reconciliation pass

**MODULE: O2S** (`o2s/o2s.html` + its own test, `o2s/tests/prodrender.test.js`).
`node --check` clean, full suite green (18/18 files, 0 failed;
`authmodel.test.js` still 5219/5219). **Not pushed.**

**Stale-tab detector.** The gap from earlier today (this session's own browser
tab kept running the pre-Fruitlish-fix rules until a manual reload, right
after the fix was already live) is now closed in-app, no server change:
- `BUILD_ID` stamped as the very first inline `<script>` in `<head>` (currently
  `'2026-09-04a'` — **bump this by hand on every future o2s.html edit**, there's
  no build step to do it automatically).
- `checkForNewBuild()` piggybacks on the existing `startSync()` 7s heartbeat
  (reusing its hidden/typing/modal gating for free) but only actually fetches
  at most once every 10 minutes. It re-fetches `/o2s` (already
  `Cache-Control: no-store` server-side — no new route needed), reads only the
  first ~4KB of the stream, and cancels — not the whole 1.5MB file.
- On a mismatch: a dismissible amber banner ("A newer version of O2S is
  available") — dismissing hides it but does **not** clear `_buildStale`.
- `saveNow()` now refuses to save at all while `_buildStale` is true ("A newer
  version is available — refresh to save"), rather than risk a write going
  out under old rules. This was a deliberate choice — it blocks work rather
  than silently letting a stale tab keep writing; flag it to Tahir if a
  softer version is ever wanted.
- `tests/prodrender.test.js`'s "five script blocks" sanity check updated to
  six (the new BUILD_ID block is real, on purpose) — everything else about
  that test (it loads and executes every block into a sandbox) was untouched
  and still passes.

**Reconciliation pass — same check that found PUR-ORD-2026-00592, run across
every open order.** Read-only against live production data (no records
touched). Of 175 order lines across 53 orders, **6 have packed > 0 with no
matching `packingLog` row** (or less than fully matching):

- **4 lines are all V-Mg Essential (base Mg Sulphate)** — Vgreen ×2, one
  Farmer PO, one Dealer PO (DLR-PB-JHN-001) — all already fully delivered,
  850 kg combined, zero packingLog trail on any of them. Same brand across
  three unrelated channels — this reads as a pattern in how V-Mg Essential
  gets packed, not a one-off.
- **"Maxim Old POs"** (Max Sulfur, 2000 kg) — the PO id itself suggests a
  pre-cutover import bucket, not a real order.
- **PUR-ORD-2026-00592 / V-Transfarm** — now shows **packed 600 kg against an
  order of 300**. The Data Fix backfill from earlier today correctly added
  one linked packingLog row (300 kg), but the original untraced 300 was never
  cleared first, so it landed on top instead of replacing it. Needs a
  correction before anything ships against this line.

Full detail (sortable/filterable) in the artifact sent to Tahir this session:
"Packing Trail Audit". Nothing here was fixed — flagged only, per how this
pass was scoped.

**Not done / next:** correct the PUR-ORD-2026-00592 double-count; decide what
(if anything) to do about the V-Mg Essential pattern and the Maxim Old POs
bucket — both look retrospective, not blocking, but the V-Mg Essential one in
particular is worth a real look given it spans three channels.

---

## 4 Sept 2026 (later still) — Reconciliation as a real screen, and a one-time changelog notice

**MODULE: O2S.** All in `o2s/o2s.html` plus two new tests
(`o2s/tests/recon.test.js`, `o2s/tests/whatsnew.test.js`). Full suite green:
20/20 files, 0 failed. **Not pushed.**

**Note on today's own process:** every syntax check this session up to this
point only ever `node --check`'d the single *biggest* of the file's six
`<script>` blocks — today's earlier edits (RIGHTS, acEscalation, printDC,
dispatch/focal-person, Fruitlish) all happened to land in smaller blocks that
were never actually checked. Nothing was wrong (the full test suite, which
does exercise every block, stayed green throughout), but the practice itself
was a gap. Fixed going forward — `checksyn.py` on this machine now checks
all six blocks, not just the largest.

**Reconciliation is now a real screen**, not just a one-off audit: "Setup &
admin" → **Reconciliation** (next to Data Fix, per the placement discussion —
it's diagnostic, not tied to one pipeline stage, and pairing it with Data Fix
keeps "found it → fixed it" one click apart). It calls the app's own
`lotsFor()` directly rather than a re-implementation, so it can never
disagree with what QA/Shipments themselves would show. Live on every open —
not a saved snapshot. Read-only; view access is COO/Production/Production
Manager same as Data Fix, but (unlike Data Fix) not further nav-restricted,
since there's nothing to break by looking. `tests/recon.test.js` covers the
real fixture (no throw) plus five synthetic cases: the 0.5 tolerance
boundary, a voided packingLog row correctly excluded, a wrong-PO row
correctly excluded, the overpack flag, and the same-brand pattern grouping.

**One-time "what's changed since you last logged in" notice.** Tahir asked
for this mid-session as a second, separate ask — confirmed with him first
since it forks on a real architecture question: tracked in the browser
(`localStorage`, keyed by username) rather than the account itself, by his
explicit choice, so **no server/auth change** — stays inside O2S. Trade-off
he accepted: a different computer or a cleared browser sees it again.
- `CHANGELOG` array sits right beside `BUILD_ID` in that same tiny first
  `<script>` block — **update both by hand together** on every future
  o2s.html change (bump `BUILD_ID`, push a new `{ver,date,title,items}`
  entry). No build step does this automatically.
- Fires once from `renderApp()`, right after the authenticated render.
  First time a given username has ever hit this (no localStorage key yet),
  they see the *entire* CHANGELOG so far — that's deliberate, it's how
  everyone gets told about today's changes on the first rollout of this
  feature. After that, only entries newer than the one they last dismissed.
- `tests/whatsnew.test.js` (13 assertions): shows once, never re-shows for
  the same version, stores the *latest* version on dismiss (not just "a"
  version), only the new entries render when there's an older one on record,
  and different usernames are tracked independently.
- Today's actual CHANGELOG entry (`2026-09-04a`) covers: delivery
  confirmation → Supply Chain permanently, DC/Gate Pass batch-number removal,
  the focal-person field, and the new Reconciliation screen.

**Not done / next:** nothing outstanding from this pass. Still open from the
earlier entries today: the PUR-ORD-2026-00592 double-count correction, and a
decision on the V-Mg Essential pattern / Maxim Old POs bucket.

## 2026-09-05 — Reconciliation icon fix + What's-changed modal fix

MODULE: O2S. Two small bug fixes reported by Tahir after the 09-04 session.

**1. Reconciliation nav item had no sidebar icon.** Root cause: the sidebar
icon comes from a separate `NAV_ICONS` object keyed by screen id, consumed
by `navIcon(id)` — NOT the `ic:'🧾'` field set on the `SCREENS` registry
entry (that emoji field is unused for sidebar rendering). `recon` was added
to `SCREENS`/`NAV_GROUPS`/dispatcher on 09-04 but never got a `NAV_ICONS`
entry. Fix: added a `recon:` entry to `NAV_ICONS` (checklist-style icon,
same Feather-icons stroke aesthetic as its siblings), inserted right after
`datafix`. `tests/recon.test.js` gained a wiring assertion for it (23
assertions now, was 22).

**2. "What's changed since you last logged in" modal was cramped/overlapping.**
Root cause: `renderWhatsNewHtml()` skipped the app's standard `.mh`/`.mb`/`.mf`
wrapper divs that give every other modal in the app its padding — it used a
bare `<h3>` and unpadded content divs instead, so text sat flush against the
modal edges and against the sticky footer. Fix:
- Rebuilt `renderWhatsNewHtml()` to use the standard `.mh` (header + "N
  updates since your last visit" sub-line) / `.mb` (body, real padding) /
  `.mf` (footer) structure, plus dividers and more line-height between
  changelog entries.
- Added a `.modal.whatsnew{width:660px}` CSS rule (vs. the default 580px)
  for more breathing room, following the same pattern as `.shipdrawer`/`.coa`
  — `checkWhatsNew()` now tags `$('modal')` with the `whatsnew` class, and
  `closeModal()` cleans it up (no leak onto the next modal opened).
- `tests/whatsnew.test.js` gained 8 assertions covering the mh/mb/mf
  structure and the whatsnew-class wiring (21 assertions now, was 13).

Verified: all 6 non-empty `<script>` blocks pass `node --check`; full suite
(20 files) green, 0 failures. Not pushed — sitting as local changes for
Tahir to commit via GitHub Desktop as usual.

**Not done / next:** the Instructions (in-app manual) screen is reported as
outdated and needs a content refresh — not yet scoped, next up. Still open
from earlier: the PUR-ORD-2026-00592 double-count correction, and a decision
on the V-Mg Essential pattern / Maxim Old POs bucket.

## 2026-09-05 — Instructions manual refresh

MODULE: O2S. Tahir flagged the in-app Instructions/manual screen as "written
very old." Read `screenInstructions()` in full and cross-checked it against
the actual current code (not just against memory of what changed) — found
three real gaps, all now fixed:

1. **No Production Manager role anywhere in the manual.** The Production
   department was split (27 Aug) into floor officers (still open/close
   batches, log shift output) and a Production Manager head who alone —
   alongside the Plant Manager — can void a wrongly-logged shift, and who
   alone owns the by-product/divert/rework call at Finish & reconcile. The
   manual's role table only ever had a 'Production' row. Added a
   'Production Manager' row; updated Plant Manager's row too (it was missing
   its DC-approval / truck-release duties, added below).

2. **Reconciliation screen was undocumented** — added 09-04, never made it
   into the manual. Added it to the tab reference table and to the "Monitor
   & report" step.

3. **The Shipments write-up described a pipeline that no longer exists.**
   It said "Recording sends & closes the shipment — it counts as delivered."
   Reality, confirmed by reading `saveDispatch()`/`approveDC()`/
   `issueGatePass()`/`approveRelease()`/`confirmDelivery()` directly: a
   dispatch now needs the **Plant Manager to approve the DC** before it's
   cleared to move; a multi-PO truck goes through **Loading → Gate Pass →
   Release**; and a shipment left "in transit" only becomes Delivered once
   Supply Chain **confirms delivery** later (recording how — phone/email/
   text/other) — that confirmation, not the recording, is what closes the
   PO. Also folded in the 09-04 "Customer focal person" field at dispatch.
   Rewrote step 8, added a "DC approval" row to the stage-flow table, added
   4 rows to the troubleshooting table, updated the Shipments tab-reference
   row and the Supply Chain/Plant Manager role rows, and fixed a Key Rules
   bullet that said a PO closes on "shipped" — it's "delivered" now.

New `tests/instructions.test.js` (12 assertions): renders without throwing
across roles, and locks in each of the three fixes above so they can't
silently regress. Full suite is now 21 files, all green; all 6 non-empty
`<script>` blocks pass `node --check`.

Deliberately left alone: steps 1–7 and 10, and the rest of the role/tab
tables — read them against the current code and didn't find anything else
stale enough to correct. Did not attempt to document the full escalation/
stall-threshold matrix (Acknowledge/RM Check/Load/Gate Pass/etc. all have
their own day-thresholds and escalation targets) — that's implementation
detail for My Actions, not something a process manual needs to spell out.

Not pushed — local changes only, for Tahir to commit via GitHub Desktop.

**Not done / next:** the PUR-ORD-2026-00592 double-count correction, and a
decision on the V-Mg Essential pattern / Maxim Old POs bucket, are still
open from earlier.


## 9 Sept 2026 — MODULE: PD — old gate-based app retired, new nine-object schema built, not run

Tahir: "We are working on PD... Product Development, let's develop if nothing
is developed yet. Ask me questions." Confirmed nothing of the new nine-object
model existed in code yet. Four scoping decisions from him this session:
schema first, then screens; take the old /pd app down now; include the
drafted-but-unconfirmed B9/B10/B11/B16 Combination Bank fields now, as
optional; build in the same live database O2S already uses.

**Built, not run, not pushed:**

- `pd/migrations/002_pd_core_rebuild.sql` (NEW, ~860 lines) — a pre-flight
  safety check (counts rows across everything about to be dropped/narrowed,
  aborts loudly if any database's "PD holds no real data" premise turns out
  false for it), then drops every old gate/hypothesis table not on
  REUSE-RULES.md §2's whitelist, creates the nine-object schema (Problem,
  Question, Bet, Run + readings, Claim, Challenge, Observation, Request,
  Constraint + delivery-context register), the Combination Bank register
  beneath Bet/Run, and the pd_reclassifications audit trail. Every object
  gets a permanent human-facing number (MODEL.md §4's "keep their number
  forever" rule) — pd_problems keeps the old p_number name on purpose so the
  Library's pin code needed no renaming. ALTERs pd_materials additively for
  the real HA/Cu/Fe/Mn/B/Ca/Mg/Moisture/OM/pH assay data from this week's
  material-grade return.
  **Not run against any database — nobody but Tahir, by hand, ever.**
- `pd/pd-lib.js`, `pd/pd-routes.js` — rewritten from ~2,040 combined lines to
  ~460. Kept only REUSE-RULES.md §2's whitelist: the Library (file storage +
  serve + comments + pins, adapted to pin only to a Problem) and the Drop
  box + Registrar triage (adapted so a Registrar converts an entry into a
  Challenge, Observation, or Request — the three doors — never directly into
  a Problem, per Tahir's decision). The old fulltext "similar idea?" checker
  is NOT ported — Tahir's decision: its code lives on only inside the
  Combination Bank's duplicate detector, a separate later build step.
  Everything else (idea intake, the G1-G6 gate machinery, candidates,
  samples, trials, formulations, regulatory, learnings) is deleted, not
  ported.
- `pd/pd.html` — the ~1,900-line old SPA replaced with a small static "being
  rebuilt" notice.
- `pd/drop.html` — one line fixed: it promised a "sign in to track your
  submission" flow that no longer exists on the new placeholder page.
- `server.js` — one function changed: `runPdMigration()` used to re-apply
  `001_pd_foundation.sql` on every boot (tolerating "already applied"
  errors). Self-caught in review: that would have silently recreated every
  table 002 just dropped on the very next restart, undoing the whole rebuild
  with no error and no log line anyone would think to check. Retired that
  call; kept the harmless PD-role bootstrap; dropped the old materials
  cost-seed (cost is out of PD, so not seeding it is correct, not a loss).
  The route-order mount at the bottom of the file (`/pd` before O2S's
  catch-all) was not touched.

**Independent review** (code reviewer + data-safety reviewer, per this
repo's standing "no exceptions" review rule): both ran against the actual
files on the device, not summaries. Real findings, all fixed and
re-verified by a second review pass:
  - `runPdMigration()` resurrecting the old schema on every boot (above) —
    the most severe finding, fixed.
  - The drop-box→Observation conversion had a misaligned INSERT (a literal
    landed in the `text` column, the real text in `origin`) — fixed.
  - The drop-box convert route could duplicate a record if two people
    triaged the same entry at once (no atomic claim) — restructured to a
    claim-first compare-and-swap.
  - Two now-orphaned pd_library_pins.target_type values ('hypothesis',
    'project') could make `resolvePin()` show the wrong Problem by id
    coincidence — schema narrowed, code guarded.
  - `pd_problems` had a `retired_reason` but no way to record why a Problem
    closed as `addressed` — generalized to one `closed_reason`.
  - Error text on four routes said triage was "the Registrar's" while the
    actual permission check only ever admitted Custodian/COO — reworded so
    the message never promises access the code doesn't grant (the new
    `registrar` pd_role, added by this migration, isn't wired to anything
    yet — that's a screens-milestone decision, on purpose).
  - Self-introduced while trimming the Library's pin code: the regex lost
    its second capture group but the insert still read the old two-group
    indexing, so every pin attempt inserted `target_id=NaN` and 500'd —
    fixed, both call sites.
  - The pre-flight safety check's own abort mechanism had a bug (a 115-char
    fake procedure name over MySQL's 64-char identifier limit) — it still
    halted the migration correctly, just with a confusing error instead of
    the intended one — shortened and re-verified.

**Disclosed, not fixed — flagged for Tahir, not decided here:**
  - No field-VALUE snapshot anywhere yet. `pd_reclassifications` records
    that something was refiled and by whom, but not a copy of what it said
    at the time — an ordinary edit later can still silently overwrite
    history on any of the nine objects or a Combination. Needs Tahir's
    decision on a mechanism before screens get built.
  - The claim-then-create-then-point-back sequence in drop-box convert is
    still two non-transactional statements, not one. A real failure between
    them leaves an entry stuck at `status='converted'` pointing at nothing —
    visible to a human, recoverable by hand, not currently by any route.
  - 002 only ALTERs pd_materials/pd_comments/pd_library_pins/auth_users, so
    it assumes 001 already ran once (true for production today). A brand
    new database that never had 001 applied would need 001 run by hand
    first, since 002 no longer runs it automatically.
  - Library and drop-box triage exist as working routes but have no click
    path yet — `pd.html` is a static notice, nothing calls them. Expected
    per "schema first, then screens," not a bug, but worth saying plainly:
    "kept" means the code survives, not that anyone can reach it today.

**Not done / next:** run `pd/migrations/002_pd_core_rebuild.sql` by hand
against `DATABASE_URL` (never Claude — this repo's own rule). After that's
confirmed clean, the screens milestone: an intake screen for the three
doors, a Problem/Question/Bet/Run working view, and the Combination Bank
entry form are all still unbuilt. Not pushed — local changes only, for
Tahir to review and commit via GitHub Desktop.

---

## 9–10 September 2026 — the screens milestone, plus training material

**What was built.** Four screens, which is exactly the number `MODEL.md §5`
signs off and exactly the number `REUSE-RULES.md §5`'s tripwire allows:

  - **What I owe** — the landing page. Readings due, Questions past their
    date, Runs where something abnormal was seen, and any notice that an
    entry was refiled. It exists because the audit found the system was
    changing state without ever telling the person who owned it.
  - **What came in** — the three doors (Challenge / Observation / Request)
    behind one box, plus the triage list. A door is optional and "not sure
    yet" is listed first on purpose.
  - **Problems** — the register and the dossier: Problem → Question → Bet →
    Run, with Claims and the history.
  - **The Report** — `MODEL.md §5.4`. Counts of things, never of people,
    and there is no version of it that can be pointed at one person.

**Migrations added — RUN THESE BY HAND, IN ORDER, BEFORE THE CODE:**

    pd/migrations/003_pd_history_and_notices.sql
    pd/migrations/004_material_grade_load.sql
    pd/migrations/005_pd_claim_identity.sql

  - **003** — `pd_field_history`, an append-only field-value snapshot table
    (Tahir's ruling, 9 Sept). Append-only is enforced by two triggers that
    `SIGNAL SQLSTATE '45000'` on UPDATE and on DELETE, so it is the database
    refusing, not the application. This closes the "no field-VALUE snapshot
    anywhere" item disclosed in the previous entry. Also adds `pd_notices`
    and `pd_observations.door_chosen` (backfilled to 0 for existing rows).
  - **004** — the 58 real grades from the returned 9 Sept worksheet, and it
    retires the ten placeholder seed materials. **Two things to look at:**
    the sheet carries **20.08 in the Mn % column on an iron source**, which
    is loaded with no assay and the raw cell kept in `spec_note`; and the
    `Elemental Sulfur 200 Mesh` row is commented out because the sheet marks
    it an example rather than a stocked grade.
  - **005** — `UNIQUE KEY (claim_number, version)` on `pd_claims`, with a
    pre-flight duplicate check that prints STOP rather than failing halfway.

**Also needed before anyone can sign in:** the eight pilot users need a PD
role granted in Manage Access. Nobody outside that list can reach `/pd` at
all, which is intended.

**Tests.** 362 assertions, 0 failed, across five suites:
`intake.test.js` (134) · `spine.test.js` (102) · `screens.test.js` (46) ·
`intake.browser.js` (45) · `spine.browser.js` (35). The last two drive a
real browser, because the previous PD build shipped a client-side defect the
API suite could not see. Both browser suites assert the nav is exactly four
items, so the screen-count tripwire cannot be crossed silently.

**Independent audit** (senior reviewers, per the standing rule — and this
time one reviewing adoption rather than code: whether eight real people
would use this, and why they would not). Its central verdict was that **the
system had to give something back before it asked for anything**, which is
what drove building `What I owe` and `The Report` in this pass rather than
later. Every code finding was verified against the running system before
being acted on.

**One audit claim was checked and found WRONG — do not act on it.** A
reviewer reported that an abnormal reading leaves a Run in `RUNNING`. It does
not: an abnormal reading flips the Run to `abnormal_investigation`, R-003 in
the seeded case sits in that state, and `spine.browser.js` pins it. What was
true underneath it — that nobody was ever *told* — is real and is what the
new landing page fixes.

**Fixed in this pass** (wording and flow, which Tahir authorised):
the close forms now show the kill criterion and what was expected, at the
moment the result is written; raw MySQL driver text no longer reaches any PD
screen (40 handlers, one replacement); typed drafts survive a re-render; a
chosen door is no longer a gate; a notice fires on re-parenting and is no
longer swallowed by a background fetch on another screen; and eleven
concurrency and identity defects — a move race that created two records, an
undo that did not verify the live pointer, claim-number collisions, revisions
forking the version chain, and an `/edit` path that quietly undid both hard
rules on a closed record.

**A verification pass over the training material found three more code
defects.** Rather than trust that this session had described its own build
correctly, every factual claim in the walkthrough and the Custodian briefing
(about 120 of them) was checked against the running system:

  - The filing queue was sorted **newest-first while its own hint said
    "oldest first"** — the oldest entry, the one most likely to have gone
    stale, sank to the bottom of the Custodian's list. Now oldest-first with
    a deterministic tiebreak so the list does not reshuffle between loads.
  - **A refiling notice could be silently consumed.** `GET /api/pd/intake`
    returned and marked notices seen, and `renderIntake()` never showed them.
    Delivery is what marks a notice seen (§7 allows no acknowledge button),
    so only the route that RENDERS a notice may return one — `/api/pd/mywork`.
    A test now pins that What came in can never carry one. This had shipped
    twice; that is why it is now a test rather than a comment.
  - **A banned word survived on The Report** — "a form that is asking the
    wrong thing." Not aimed at a person, but §6 is not conditional. The
    browser suite's §6 sweep runs over rendered screens and this string was
    added after the sweep last ran green on that screen.
  - A Bet on What I owe did not name the Question it tests, though the
    payload already carried it (B7). Added.

Ten claims in the documents were corrected in the same pass — most usefully
that filing an entry against a Problem with **no owner** does not take it out
of the queue (it needs both), and that a per-person refiling count is not
something the system fails to hold — it holds it and no screen may group by
it, which is a materially different sentence to put in a Custodian's mouth.

**Training material, built and published as private pages on claude.ai:**

  - *Before You Open PD* — the walkthrough, with real screenshots of the
    real screens and the V Germinator Pro case as it actually happened.
  - *The Custodian's Desk* — a separate briefing for the Data Custodian,
    because her role is filing rather than chemistry and the no-blame rules
    matter more to her than to anyone else.
  - *Seven Calls on PD* — the structural findings, written as decisions for
    Tahir rather than changes made unilaterally.
  - `PD-introduction.pptx` — the same story as a deck.

**Not done / next.** Seven structural questions are waiting on Tahir's
ruling (see *Seven Calls on PD*); two of them — **who moderates** and
**whether a Run needs a recipe** — gate the Combination Bank build, which is
the largest piece still unbuilt from the original screens request. Search
across Problems, Questions, Bets, Runs and Claims does not exist at all and
is, in this session's view, the biggest single gap in the system. Nothing is
pushed — local changes only, for Tahir to review and commit via GitHub
Desktop.

---

## 10 September 2026 — Tahir's rulings on the seven, and what they changed

Five of the seven open questions were answered. **Search ordering (1) and the
role labels (2) are still open** — 2 is waiting on Tahir's own words for the
labels, since it is an org chart question, not a technical one.

**Ruled and now built:**

  - **Constraints are written from inside the Problem dossier** (decision 3),
    not from a fifth screen. `POST /api/pd/constraints` and
    `POST /api/pd/constraints/:id/retire`, both leads-only, plus a Constraints
    card on the dossier showing the whole register grouped by delivery
    context. This closes MODEL.md §3's ninth object, which until today could
    be read but never written. The nav is still four items, so REUSE-RULES §5's
    tripwire is not crossed.
    Retiring is not deleting: it takes a written reason and is a
    compare-and-swap, so two people cannot write over each other's reason and a
    rule that stopped binding does not quietly vanish and get re-argued.
  - **The banned word in `server.js` only** (decision 6). Line 423's
    `'invalid role "x" for module y'` is now `'The X module has no role called
    "y".'` No behaviour change, no other `server.js` edits. The remaining 16
    places where raw driver text can reach a screen stay for a separate piece
    of work with its own O2S test pass — Tahir's ruling, and the right one:
    mixing a platform refactor into a PD milestone is how a live module breaks
    for a reason nobody can find.
  - **`pd/PORTING_STATUS.md` is retired** (decision 7). The file now contains
    only a pointer to this document and to `docs/pd-model/`. It was NOT
    deleted from disk — the device bridge cannot delete — so **delete it in
    GitHub Desktop if you want it gone**; leaving the stub is also fine and
    keeps the git history reachable. `CLAUDE.md` updated in two places: the PD
    file list now names `pd-routes.js` and `tests/` and drops the retired file,
    and §3 says plainly that OP-HANDOFF.md is the single status document and a
    second one should not be started.

**Ruled, and waiting on the Combination Bank build:**

  - **The moderator group is hard-coded to Custodian + Registrar + COO for the
    pilot** (decision 4), to be made configurable in Admin before anyone
    outside the eight uses it. Nothing is built for it yet — it lands with the
    bank's moderation queue.
  - **A recipe is required to CLOSE a Run, never to start one** (decision 5).
    Not yet enforced, and deliberately so: there is no way to record a recipe
    until the Combination Bank exists, so switching the check on today would
    make every Run uncloseable. It goes in with the bank, in the same change
    as the entry form.

**One more defect, found by a test that only failed when the box was slow.**
`settle`, `close-bet` and `close-run` each had an early "already closed" guard
sitting ABOVE the validation and above `writeClosingClaim()`. So whether a
person who lost a close race had their written result kept as a Claim or
silently dropped depended on how many microseconds they lost by — two
behaviours for one situation, and the wide-margin one discarded their words
while telling them nothing. The early guards are gone; the claim is written
first and the state change is a compare-and-swap in all three routes, so every
loser is treated identically and told "nothing is lost", truthfully. Pinned by
a test that closes a run long after it was closed, not just concurrently.

**Tests: 383 assertions, 0 failed** — `intake.test.js` (134) ·
`spine.test.js` (123) · `screens.test.js` (46) · `intake.browser.js` (45) ·
`spine.browser.js` (35).

**Still not done:** the Combination Bank — entry form, the six-signal duplicate
checker, the four bands and the moderation queue — is the largest piece left
from the original screens request, and it is now unblocked. Search across the
nine objects (decision 1) is unbuilt and, in this session's view, the single
biggest gap in PD. Nothing is pushed — local changes only, for Tahir to review
and commit via GitHub Desktop.

---

## 10 September 2026 (later) — search, and the role list matched to the org chart

The last two open questions were answered. **Nothing is waiting on Tahir.**

### Decision 1 — search, before the Combination Bank

`GET /api/pd/search?q=` searches **everything a person wrote**: a Problem's
title, statement, context and closing reason; a Question's title, text and
settled reason; a Bet's approach and its kill criterion; a Run's expected,
actual and replaces-reason; every reading (parameters, physical observation,
analytical result); every current Claim and its source; all three doors; and
every live constraint. Results say what kind of thing each one is, carry a
snippet showing why the row came back, and name the Problem they sit under.

**`LIKE`, not FULLTEXT, and this is deliberate.** InnoDB fulltext drops every
token shorter than `innodb_ft_min_token_size` — 3 by default and a server-wide
setting we do not control on HostGator. What this team actually searches for is
chemistry: pH, N, P, K, Zn, B, Fe, Mn, K2O, SOP, MAP, KOH, CRH, ULV. Half of
those are one or two characters, so a fulltext search would return an empty
list for "pH" — not an error, just nothing — and people would conclude PD has
no memory rather than that the search has a token floor. `LIKE '%x%'` finds all
of them and costs nothing at pilot scale. It will not scale to a hundred
thousand Runs; when that day comes the fix is an index, not a rewrite.

**§8.1 holds.** The route reads only `q`. There is no author parameter and no
way to point a search at a person, because a search box that takes an author IS
a per-person count. A test passes `&author=&owner_id=&user=&created_by=&by=`
and asserts the results are byte-identical to the plain query, and another
asserts no groupable person field appears in the payload.

**It is not a fifth screen.** The box sits in the sidebar ABOVE the nav — search
is how you reach the four screens, not a fifth one — and results render as a
panel over Problems, the same way one entry and one dossier already do. The nav
is still four items and both browser suites assert it.

### Decision 2 — the role list

`migrations/006_pd_roles.sql` — **run by hand after 005.** It extends the
`auth_users.pd_role` ENUM by two values and changes no row. The two renames are
display strings in `pd-lib.js`, not data, so nobody's access moves.

| Key | Was | Now | Who |
|---|---|---|---|
| `rta` | Plant Manager (RTA) | **R&D Manager** | Himmayat |
| `production` | Production Manager | unchanged | Majid |
| `agronomy` | Agronomy | **Agronomy Lead** | Maleeha |
| `field_agronomy` | — | **Field Agronomist** (new) | Nadeem |
| `associate_agronomy` | — | **Associate Agronomist** (new) | Erum |

The old label named the wrong job *and* collided with `production`, which is
what the real Plant Manager holds; and a compliance audit had already found
that RTA is never expanded anywhere in the system, so nobody could learn what
it meant from the software. Agronomy was one role for the whole function, so
the system could not tell the lead from the people who work to her.

**All four of Agronomy Lead, Production Manager, Field Agronomist and
Associate Agronomist are LEADS** (`LEAD_ROLES` in `pd-lib.js`), on Tahir's
ruling. A lead may name someone else the owner of a Question, Bet or Run,
settle a Question, and close work that is not their own.

**After running 006:** give Nadeem `field_agronomy` and Erum
`associate_agronomy` in Manage Access. `launcher.html`'s fallback role array
was also brought back into step — it had been missing `registrar` since 002,
though the Access screen prefers the server's list so nobody saw it.

**Tests: 408 assertions, 0 failed** — `intake.test.js` (134) ·
`spine.test.js` (123) · `screens.test.js` (64) · `intake.browser.js` (45) ·
`spine.browser.js` (42).

**Next, and now unblocked:** the Combination Bank — entry form, the six-signal
duplicate checker, the four bands, the moderation queue (Custodian + Registrar
+ COO, hard-coded for the pilot), and the close-time recipe check on a Run.
Nothing is pushed — local changes only, for Tahir to review and commit via
GitHub Desktop.
