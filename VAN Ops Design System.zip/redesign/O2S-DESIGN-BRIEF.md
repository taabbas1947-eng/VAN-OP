# O2S — Design & Build Brief (handoff for Claude Cowork)

**Goal:** make the live app (`index.html`, server-backed vanilla JS) look and behave **exactly** like the locked prototype (React, in `/redesign/`). This is a **front-end / render-layer** job: change how screens are built and styled — **never** change business logic, data model, `/api` calls, auth, sync, or master data.

**Hard rules (from the repo's MODELING-GROUND-RULES):**
- Render-only. Reuse existing data accessors (`orderBucket`, `lineBucket`, `batchStage`, `batchClearedKg`, `actionItems`, `actUrg`, `acRiskOf`, `execMetrics`, etc.). Do not invent counts or write state from display code.
- No master-data edits. No new stored fields. No new alerts/audit/action-log entries.
- Verify each screen against a data snapshot before pushing. One screen per PR.

**Reference implementation = `/redesign/`** (the prototype). Lift exact markup, classes and values from:
- `redesign/app.css` — the entire design system (tokens, components, density, responsive).
- `redesign/shell.jsx` — sidebar + topbar.
- `redesign/login.jsx` — landing/login.
- `redesign/screen-actions.jsx` — My Actions.
- `redesign/screen-tracker.jsx` — PO Tracker.
- `redesign/screen-prod.jsx` — Production.
- `redesign/screen-ops.jsx` — QC·Lab, Pre-shipment, Shipments.
- `redesign/screen-dash.jsx` — role Dashboards.
- `redesign/screen-insights.jsx` — Sales & Budget.
- `redesign/screen-setup.jsx` — New PO Entry, Admin.
- `redesign/ui.jsx` — shared primitives (Pill, Kpi, StageFlow, Drawer, etc.).
- `redesign/data.jsx` — shows the exact field shapes the screens expect (map these to the live `state`).

---

## 1. Design tokens (use everywhere — already partly applied as a `:root` override in live)

```
/* brand */
--navy:#2E4F7C; --navy2/-d:#223E66; --navy-l:#3D6098; --navy-bright:#3A6BB0;
--navy-50:#EFF3F9; --navy-100:#DEE7F3; --navy-200:#C6D5EA;
--green:#4FA84E; --green-d:#3C8B3C; --green-50:#EAF5EA;
--teal:#1F9C92; --teal-d:#177E76; --teal-50:#E5F4F2;
--red:#E03127;  --red-d:#BE251D;   --red-50:#FCEBEA;
--amber:#C77D18;--amber-d:#9E6210; --amber-50:#FBF1E0;
--blue:#2563EB; --blue-50:#EAF0FD; --purple:#7C5CFC;
/* neutrals (cool) */
--bg:#F7F8FA; --surface/panel:#FFFFFF; --surface-2:#F5F7FA; --surface-3:#EFF2F6;
--line:#E5E9EF; --line-2:#EDF0F4;
--ink/txt:#17202E; --ink-2/txt2:#586577; --ink-3/mut:#8A95A6;
/* shape — sharp/crisp */
--radius:8px; --radius-sm:5px; --r-lg:7px; pill:999px;
shadows: xs 0 1px 2px rgba(23,32,46,.05); sm …,.06; lg 0 18px 48px rgba(20,30,48,.16)
```

**Stage color-flow** (PO lifecycle, used by PO Tracker + dashboards):
`PO Created #7A8699 · RM Check #C77D18 · Production #2563EB · Lab QC #7C5CFC · QA Pre-shipment #1F9C92 · Shipment #4FA84E · Delivered #2F8F4E`

## 2. Type
- **Display/headings:** `Bricolage Grotesque` (700/800), letter-spacing −.02/−.03em.
- **UI/body:** `Geist` (400–700).
- **Data/codes/eyebrows:** `Geist Mono` (PO#, batch#, KPI eyebrows, table headers, timestamps).
- Load via Google Fonts (already added to the live `<link>`).

## 3. Density (compact = default)
Two modes on the app shell. Compact must be genuinely tight. Token deltas:
`--fs 12/13.5 · card pad 11/17 · row-py 4/10 · gap 9/15 · nav-py 5/8 · kpi-pad 11/17 · h1 16/20 · well-pad 13·16 / 22·26`. See `app.css` `[data-density]`.

## 4. Sidebar (see `shell.jsx` + `app.css .rail`)
- White rail, 212–218px; **collapsible to ~54px** via a **round toggle button on the rail's right edge** (always visible). Persist in localStorage.
- Brand: **VAN logo image** (use the real logo, not the cube) + “O2S System / ORDER → SHIPMENT” wordmark. Hide wordmark when collapsed; show a compact mark.
- Search pill (“Search PO or screen” + ⌘K). Nav groups: **WORK** (My Actions, PO Tracker) · **OPERATIONS** (Production, QC·Lab, Pre-shipment, Shipments) · **INSIGHTS** (Dashboard, Sales & Budget, Reports) · **SETUP & ADMIN** (New PO Entry, Dealer Master, Admin, Data Fix, Users).
- Nav item: 7px radius, weight 500; active = `--navy-50` bg + navy text + 3px navy left bar; count chip right-aligned (hot = red for My Actions late).
- Role switcher pinned bottom (avatar + name + role + chevron → menu).

## 5. Topbar
- Sticky, translucent white + blur. Left: crumb (mono, “GROUP · subtitle”) над H1 (Bricolage). Right: **density segmented toggle (Compact | Comfortable)**, bell.

## 6. Components (all in `app.css`)
- **Card:** white, 1px `--line`, radius 7, shadow-xs. Header: Bricolage 14px + mono hint right.
- **KPI:** mono eyebrow (9.5px, .1em), Bricolage value (24px) + small unit, foot with up/down delta chip. Optional 3px top accent.
- **Pill/badge:** soft tint by tone (navy/teal/blue/amber/red/grey/green). Risk: Late=red, RM-blocked/Watch=amber, On-track=teal, Closed=green.
- **Buttons:** primary navy (radius 7), ghost white+line; sm variant. Hover lifts 1px.
- **Segmented control** (`.seg`): used for view toggles & density.
- **Chips** (`.chip`): filter pills; active = navy fill.
- **Tables:** mono uppercase headers on `--surface-2`; row hover `--surface-2`; risk rows get inset left bar (red/amber).
- **Drawer:** right slide-in 420px; header (eyebrow + H2 + close), scroll body, footer actions.
- **Stepper / StageFlow:** 7-segment colored flow using the stage palette (see `ui.jsx StageFlow`).

## 7. Login / landing (`login.jsx`)
Full brand splash: navy→teal gradient background, centered white card with the **VAN logo** in a white tile, “O2S” (Bricolage) + “Order → Shipment Control Tower” (mono), username/password, primary Sign-in, then role quick-pick buttons. (Live login keeps real `/api/login`; only restyle.)

---

## 8. Per-screen layout & workflow (match exactly)

### My Actions (`screen-actions.jsx`) — live `screenApprovals`
Urgency-first worklist. Lede line; **risk chips** All/Late/Today/Normal (counts from `acRiskOf`); for COO a **clickable role bar** (per-role counts + late). Groups **Late · Today · Normal**. Row = short type badge (Produce/RM/Lab/Pack/Ship/Delay…) + `PO · client` + the “what” + role + pending age (`actTiming`) + primary verb button. Click → drawer with stepper. **Risk logic is already live** (`actOverdue`/`actUrg`/`acRiskOf`) — reuse verbatim. *(This screen already largely matches; just align badges/role-bar styling.)*

### PO Tracker (`screen-tracker.jsx`) — live `screenTracker`
Risk strip (open · at-risk · RM-blocked · Kg remaining) → **stage rail** (All + 7 buckets w/ counts) → controls (channel filter + **Matrix / List / Board** segmented) →
- **Matrix:** dense table; Stage cell = **colored stage chip**.
- **List:** one row per PO with a **7-segment stage color-flow bar** + legend (the net-new piece).
- **Board:** 7 stage columns, headers tinted by stage color.
Row/card click → order drawer (3 progress bars + meta). Stage = `orderBucket`. Render-only.

### Production (`screen-prod.jsx`) — live `screenProd`
1. **KPI strip (4):** In production (`producing`), Awaiting Lab QC (`qc`), Ready to pack (`pack`, + Kg cleared), Reconcile (`recon`). *(already added live.)*
2. **Reconcile · by-product pools** as **bordered cards** (By-product/Divert/Rework + Kg + note + action button) — convert the current banner lines to cards.
3. **Chips** All/In production/Awaiting QC/Ready to pack/Reconcile/Packed.
4. **VIEW segmented: Lanes / Board / Table** (live has Lanes only — add Board = kanban columns, Table = dense batch table: Batch·Product·PO·Stage·Produced/plan·Cleared·Ready·Remainder).
5. **Lanes:** stacked sections per `batchStage`; batch card = batchNo + PO/BULK tag + product + progress bar + footer (`{to go}/{waiting}/{ready}/{remainder}` by stage). Reuse `journeyCard`/`_prodLanes` data; restyle to the prototype card.
6. Tuck the **Open-a-batch form** + Orders/Log tables into collapsibles below. *(KPI strip + form-collapse already pushed.)*
Lane membership = `batchStage`; pools = `_bpPools/_dvPools/_rwPools`. Render-only.

### QC · Lab (`screen-ops.jsx ScreenQC`) — split from live `screenQC`
KPI strip (Lab QC pending · COA to review · Lots in lab · Pass rate). Segmented **Lab QC queue | COA review**. Tables of lots (state pill) / COAs (result pill). Lab → AQCM → QCM chain from batch lots’ `coa.status`.

### Pre-shipment (new tab `ScreenPreship`) — QA pack inspection
Split out of QC: KPI strip (pending inspection · passed today · holds · checklist items), “Awaiting pre-shipment inspection” table + “Recently cleared”. Source = `dispatchGroups()` qa-pending + `inspections`.

### Shipments (`screen-ops.jsx ScreenShip`) — live `screenShip`
KPI strip (ready to dispatch · in transit · delivered · avg transit) + Shipments table (status pills) + “Ready to dispatch” side list.

### Dashboard (`screen-dash.jsx`) — live `screenDash` *(biggest net-new)*
Replace the single view with **role tabs**: **Overview · Production · QC & QA · Plant Manager · Supply Chain** (segmented), auto-selecting the signed-in role’s tab. Each tab = **question cards** (“What’s at risk?”, “Cleared to pack?”, “RM-blocked POs?”) — big answer + sub + colored left accent — over 1–2 focused lists. Pure compute over existing accessors (`orderBucket`, `batchStage`, `actionItems`, `execMetrics`, shipments, pools). Keep the live Executive-overview charts available (e.g. as the Overview tab or a “Manager view”) — don’t delete working analytics.

### Sales & Budget (`screen-insights.jsx`) — live `screenBudget`
Question-card KPIs (Are we hitting budget? / Sold this month / Top client / Who’s behind?) + sales-vs-budget by client table (attainment bars) + monthly trend. Source = real `salesTargets`.

### New PO Entry / Admin (`screen-setup.jsx`)
Apply the component system (forms, tables, cards). Admin = read-only master-data viewer (channels, clients, brands→base, lead-time, groups). No master-data writes.

---

## 9. Mapping prototype data → live `state`
The prototype’s `data.jsx` was generated from your snapshot, so field names match your live accessors. Where the prototype reads e.g. `o.bucket`, compute it live with `orderBucket(o)`; `batch.stage` ↔ `batchStage(b)`; actions ↔ `actionItems()`. Do **not** copy `data.jsx` into live — it’s a frozen sample; wire the same shapes from live `state`.

## 10. Definition of done (per screen)
Matches the `/redesign/` screen in layout, components, type, color, density; uses only existing data/logic; boots clean; verified against a snapshot; one PR per screen.
