/* VAN Ops v3 — QC·Lab, Pre-shipment (QA), and Shipments. */
function ScreenQC({ toast }) {
  const [tab, setTab] = useState('lab');
  return (
    <div className="well">
      <div className="grid g-kpi" style={{ marginBottom:16 }}>
        <Kpi eyebrow="Lab QC pending" val={window.LAB_QUEUE.filter(l=>l.stage==='Lab QC pending').length} unit=" lots" foot="awaiting analysis" />
        <Kpi eyebrow="COA to review" val={window.COA_QUEUE.length} unit=" COAs" foot="AQCM → QCM" />
        <Kpi eyebrow="Lots in lab" val={window.LAB_QUEUE.length} unit=" lots" foot="across open batches" />
        <Kpi eyebrow="Pass rate" val="100" unit="%" foot="this cycle" delta="" dir="up" />
      </div>

      <div className="banner blue" style={{ marginBottom:14 }}><span className="ic"><Ic name="flask" size={16} /></span>
        <span><b>Lab</b> analyses each lot → issues a COA → <b>AQCM</b> reviews → <b>QCM</b> approves. Pre-shipment pack inspection is a separate step (QA).</span></div>

      <div className="seg" style={{ marginBottom:14 }}>
        {[['lab','flask','Lab QC queue'],['coa','reports','COA review']].map(([k,ic,l]) => (
          <button key={k} className={cx(tab===k && 'on')} onClick={()=>setTab(k)}><Ic name={ic} size={13} /> {l}</button>
        ))}
      </div>

      <div className="card" style={{ overflow:'hidden' }}><div className="tbl-wrap"><table className="tbl">
        {tab==='lab' && <>
          <thead><tr><th>Lot</th><th>Batch</th><th>Product</th><th>PO</th><th className="r">Qty</th><th>State</th><th>Age</th><th></th></tr></thead>
          <tbody>{window.LAB_QUEUE.map(l => (
            <tr key={l.lot}><td className="mono lead">{l.lot}</td><td className="mono">{l.batch}</td><td>{l.product}</td>
              <td className="mono">{l.po}</td><td className="r mono">{fmt(l.kg)} KG</td>
              <td><Pill tone={l.tone}>{l.stage}</Pill></td><td className="mono">{l.age}</td>
              <td className="r"><button className="btn btn-gh btn-sm" onClick={()=>toast('Analysis recorded for '+l.lot)}>Analyse</button></td></tr>
          ))}</tbody>
        </>}
        {tab==='coa' && <>
          <thead><tr><th>COA</th><th>Product</th><th>Lot</th><th>Result</th><th>Reviewed by</th><th>Status</th><th></th></tr></thead>
          <tbody>{window.COA_QUEUE.map(c => (
            <tr key={c.coa} className={c.result.startsWith('UNFIT')?'row-risk':''}><td className="mono lead">{c.coa}</td><td>{c.product}</td>
              <td className="mono">{c.lot}</td><td className="mono" style={{ fontSize:11.5 }}>{c.spec}</td><td>{c.by}</td>
              <td><Pill tone={c.tone}>{c.result}</Pill></td>
              <td className="r"><button className="btn btn-gh btn-sm" onClick={()=>toast('COA '+c.coa+' approved → QCM')}>Approve</button></td></tr>
          ))}</tbody>
        </>}
      </table></div></div>
    </div>
  );
}

function ScreenPreship({ toast }) {
  return (
    <div className="well">
      <div className="grid g-kpi" style={{ marginBottom:16 }}>
        <Kpi eyebrow="Pending inspection" val={window.INSPECT_QUEUE.length} unit=" lots" foot="packed, before dispatch" />
        <Kpi eyebrow="Passed today" val={window.INSPECT_DONE.filter(i=>i.pass).length} unit=" lots" foot="cleared to ship" delta="" dir="up" />
        <Kpi eyebrow="Holds" val="0" unit=" lots" foot="no QA holds open" />
        <Kpi eyebrow="Checklist items" val="8" foot="per pack inspection" />
      </div>

      <div className="banner green" style={{ marginBottom:14 }}><span className="ic"><Ic name="qc" size={16} /></span>
        <span><b>QA Inspector</b> runs the pre-shipment pack inspection — packaging, label/artwork, net weight, seal, batch & expiry, no leakage — before a lot is cleared for dispatch.</span></div>

      <div className="grid g-main">
        <Card title="Awaiting pre-shipment inspection" hint={window.INSPECT_QUEUE.length+' lots'} pad={false}>
          <div className="tbl-wrap"><table className="tbl">
            <thead><tr><th>PO</th><th>Customer</th><th>Product</th><th>Lot</th><th>Packs</th><th>Age</th><th></th></tr></thead>
            <tbody>{window.INSPECT_QUEUE.map(p => (
              <tr key={p.lot}><td className="mono lead">{p.po}</td><td>{p.client}</td><td>{p.product}</td>
                <td className="mono">{p.lot}</td><td className="mono">{p.packs}</td><td className="mono">{p.age}</td>
                <td className="r"><button className="btn btn-pri btn-sm" onClick={()=>toast('Pack inspection passed — '+p.po)}>Inspect</button></td></tr>
            ))}</tbody>
          </table></div>
        </Card>
        <Card title="Recently cleared">
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {window.INSPECT_DONE.map((i,n) => (
              <div key={n} style={{ display:'flex', alignItems:'center', gap:10, borderLeft:'3px solid var(--green)', paddingLeft:11 }}>
                <div style={{ flex:1, minWidth:0 }}>
                  <div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{i.po} · {i.date}</div>
                  <div style={{ fontWeight:600, fontSize:12.5 }}>{i.product}</div>
                  <div style={{ fontSize:11, color:'var(--ink-2)' }}>{fmt(i.kg)} KG · {i.by}</div>
                </div>
                <Pill tone="green">PASS</Pill>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function ScreenShip({ toast }) {
  const S = window.SHIPMENTS;
  const transit = S.filter(s=>s.status==='In transit');
  const kgTransit = transit.reduce((a,s)=>a+s.qty,0);
  return (
    <div className="well">
      <div className="grid g-kpi" style={{ marginBottom:16 }}>
        <Kpi eyebrow="Ready to dispatch" val={window.SHIP_READY.length} unit=" POs" foot="cleared & packed" />
        <Kpi eyebrow="In transit" val={transit.length} unit=" trucks" foot={fmt(kgTransit)+' KG on the road'} />
        <Kpi eyebrow="Delivered" val={S.filter(s=>s.status==='Delivered').length} unit=" recent" foot="last dispatches" delta="" dir="up" />
        <Kpi eyebrow="Avg transit" val="2.4" unit=" d" foot="dispatch → delivery" />
      </div>

      <div className="grid g-main">
        <Card title="Shipments" hint={S.length+' recent'} pad={false}>
          <div className="tbl-wrap"><table className="tbl">
            <thead><tr><th>Dispatch</th><th>PO</th><th>Destination</th><th>Product</th><th className="r">Qty</th><th>Status</th><th>Vehicle</th><th>Date</th></tr></thead>
            <tbody>{S.map(s => (
              <tr key={s.id}><td className="mono lead">{s.id}</td><td className="mono">{s.po}</td><td style={{ maxWidth:160, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{s.client}</td>
                <td>{s.product}</td><td className="r mono">{fmt(s.qty)}</td>
                <td><Pill tone={s.tone}>{s.status}</Pill></td><td className="mono">{s.truck}</td><td className="mono">{s.dispatched}</td></tr>
            ))}</tbody>
          </table></div>
        </Card>
        <Card title="Ready to dispatch">
          <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
            {window.SHIP_READY.map(r => (
              <div key={r.po} style={{ borderLeft:'3px solid '+(r.tone==='amber'?'var(--amber)':'var(--green)'), paddingLeft:11 }}>
                <div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{r.po}</div>
                <div style={{ fontWeight:600, fontSize:12.5 }}>{r.client}</div>
                <div style={{ fontSize:11, color:'var(--ink-2)', margin:'2px 0 7px' }}>{fmt(r.qty)} KG · {r.note}</div>
                <button className="btn btn-pri btn-sm" onClick={()=>toast('Dispatch recorded — '+r.po)}>Record dispatch</button>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
window.ScreenQC = ScreenQC; window.ScreenPreship = ScreenPreship; window.ScreenShip = ScreenShip;
