/* VAN Ops v2 — New PO Entry and Admin · Master Data. */
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function addDays(days) { const d = new Date(2026,5,21); d.setDate(d.getDate()+days); return MONTHS[d.getMonth()]+' '+String(d.getDate()).padStart(2,'0'); }
function committedDays(qty, brand) {
  const lt = window.MASTERS.leadTime; const b = window.MASTERS.brands.find(x=>x.brand===brand);
  const rate = b ? b.rate : 5000;
  const days = lt.rmProcureDays + Math.ceil((qty||0)/rate) + lt.qcDays + lt.dispatchDays;
  return Math.max(lt.minDays, days);
}

function ScreenEntry({ toast }) {
  const [client, setClient] = useState(window.MASTERS.clients[0]);
  const [channel, setChannel] = useState(window.MASTERS.channels[0]);
  const [po, setPo] = useState('');
  const [lines, setLines] = useState([{ brand:window.MASTERS.brands[0].brand, qty:5000, promise:'Jul 05' }]);
  const setLine = (i,k,v) => setLines(ls => ls.map((l,j)=> j===i?{...l,[k]:v}:l));
  const addLine = () => setLines(ls => [...ls, { brand:window.MASTERS.brands[0].brand, qty:5000, promise:'Jul 10' }]);
  const rmLine = i => setLines(ls => ls.filter((_,j)=>j!==i));
  const totalKg = lines.reduce((a,l)=>a+(+l.qty||0),0);

  return (
    <div className="well">
      <div className="grid g-main">
        <div>
          <Card title="Order header" rule>
            <div className="formgrid">
              <div className="field"><label>Customer</label>
                <select className="inp" value={client} onChange={e=>setClient(e.target.value)}>{window.MASTERS.clients.map(c=><option key={c}>{c}</option>)}</select></div>
              <div className="field"><label>Channel</label>
                <select className="inp" value={channel} onChange={e=>setChannel(e.target.value)}>{window.MASTERS.channels.map(c=><option key={c}>{c}</option>)}</select></div>
              <div className="field"><label>Customer PO #</label>
                <input className="inp" placeholder="e.g. 6595010500" value={po} onChange={e=>setPo(e.target.value)} /></div>
              <div className="field"><label>Received date</label>
                <input className="inp" defaultValue="Jun 21, 2026" /></div>
            </div>
          </Card>

          <SectionTitle count={lines.length+' line'+(lines.length>1?'s':'')}>Order lines</SectionTitle>
          <div className="card" pad={false}>
            <table className="tbl">
              <thead><tr><th>Brand → base</th><th style={{ width:110 }}>Qty</th><th style={{ width:120 }}>Promised</th><th>Committed (auto)</th><th></th></tr></thead>
              <tbody>{lines.map((l,i) => {
                const b = window.MASTERS.brands.find(x=>x.brand===l.brand);
                const cd = committedDays(+l.qty, l.brand);
                return (<tr key={i}>
                  <td><select className="inp" style={{ padding:'6px 9px' }} value={l.brand} onChange={e=>setLine(i,'brand',e.target.value)}>
                      {window.MASTERS.brands.map(x=><option key={x.brand}>{x.brand}</option>)}</select>
                    <div className="mono" style={{ fontSize:10, color:'var(--ink-3)', marginTop:4 }}>{b.base} · {b.packs}</div></td>
                  <td><input className="inp" style={{ padding:'6px 9px' }} value={l.qty} onChange={e=>setLine(i,'qty',e.target.value.replace(/\D/g,''))} />
                    <div className="mono" style={{ fontSize:10, color:'var(--ink-3)', marginTop:4 }}>KG</div></td>
                  <td><input className="inp" style={{ padding:'6px 9px' }} value={l.promise} onChange={e=>setLine(i,'promise',e.target.value)} /></td>
                  <td><span className="mono lead">{addDays(cd)}</span>
                    <div className="mono" style={{ fontSize:10, color:'var(--teal-d)', marginTop:4 }}>auto · {cd}d lead · incl {window.MASTERS.leadTime.rmProcureDays}d RM</div></td>
                  <td className="r">{lines.length>1 && <button className="iconbtn" style={{ width:30, height:30 }} onClick={()=>rmLine(i)}><Ic name="x" size={14} /></button>}</td>
                </tr>);
              })}</tbody>
            </table>
            <div style={{ padding:'12px 16px', borderTop:'1px solid var(--line-2)' }}>
              <button className="btn btn-gh btn-sm" onClick={addLine}><Ic name="plus" size={14} /> Add line</button>
            </div>
          </div>
        </div>

        <div>
          <Card title="Summary" rule>
            <div className="kv" style={{ marginBottom:16 }}>
              <dt>Customer</dt><dd style={{ fontSize:11.5 }}>{client}</dd>
              <dt>Channel</dt><dd>{channel}</dd>
              <dt>PO #</dt><dd className="mono">{po||'—'}</dd>
              <dt>Lines</dt><dd className="mono">{lines.length}</dd>
              <dt>Total qty</dt><dd className="mono">{fmt(totalKg)} KG</dd>
            </div>
            <button className="btn btn-pri" style={{ width:'100%', justifyContent:'center' }}
              onClick={()=> po ? toast('PO '+po+' registered · SO queued') : toast('Enter a PO number first') }>Register PO</button>
            <div className="banner teal" style={{ marginTop:14 }}><span className="ic"><Ic name="info" size={16} /></span>
              <span>Committed dates are computed per line from the lead-time model. Override any line if you have a firmer date.</span></div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function ScreenAdmin() {
  const [tab, setTab] = useState('brands');
  const M = window.MASTERS;
  return (
    <div className="well">
      <div className="banner amber" style={{ marginBottom:18 }}><span className="ic"><Ic name="admin" size={16} /></span>
        <span><b>COO only.</b> This is the single source of truth — channels, clients, brands→base products, recipes, pack sizes and the lead-time model. Edits here flow app-wide. Shown read-only in this prototype.</span></div>

      <div className="seg" style={{ marginBottom:16 }}>
        {[['brands','Brands → base'],['lead','Lead-time & groups'],['channels','Channels & clients']].map(([k,l]) => (
          <button key={k} className={cx(tab===k && 'on')} onClick={()=>setTab(k)}>{l}</button>
        ))}
      </div>

      {tab==='brands' && (
        <Card title="Brands → base products" hint={M.brands.length+' brands · 13 bases'} pad={false}>
          <div className="tbl-wrap"><table className="tbl">
            <thead><tr><th>Brand</th><th>Base product</th><th>Pack sizes</th><th>Production group</th><th className="r">Rate KG/day</th></tr></thead>
            <tbody>{M.brands.map(b => (
              <tr key={b.brand}><td className="lead">{b.brand}</td><td>{b.base}</td><td className="mono">{b.packs}</td>
                <td><span className="tag">{b.group}</span></td><td className="r mono">{fmt(b.rate)}</td></tr>
            ))}</tbody>
          </table></div>
        </Card>
      )}
      {tab==='lead' && (
        <div className="grid g-2">
          <Card title="Delivery lead-time" rule>
            <div className="kv">
              <dt>RM procurement</dt><dd className="mono">{M.leadTime.rmProcureDays} d</dd>
              <dt>QC</dt><dd className="mono">{M.leadTime.qcDays} d</dd>
              <dt>Dispatch</dt><dd className="mono">{M.leadTime.dispatchDays} d</dd>
              <dt>Minimum</dt><dd className="mono">{M.leadTime.minDays} d</dd>
            </div>
            <div className="banner teal" style={{ marginTop:16 }}><span className="ic"><Ic name="info" size={16} /></span>
              <span>Committed = received + procurement + ⌈qty ÷ group rate⌉ + QC + dispatch, floored at minimum.</span></div>
          </Card>
          <Card title="Production groups" hint="daily rate" rule>
            <table className="tbl" style={{ marginTop:-4 }}>
              <thead><tr><th>Group</th><th className="r">Rate KG/day</th></tr></thead>
              <tbody>{M.groups.map(g => (<tr key={g.group}><td className="lead">{g.group}</td><td className="r mono">{fmt(g.rate)}</td></tr>))}</tbody>
            </table>
          </Card>
        </div>
      )}
      {tab==='channels' && (
        <div className="grid g-2">
          <Card title="Channels" hint={M.channels.length} rule>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>{M.channels.map(c => (
              <div key={c} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 4px', borderBottom:'1px solid var(--line-2)' }}>
                <span className="sdot d-teal" /><span style={{ fontWeight:600, fontSize:13 }}>{c}</span></div>
            ))}</div>
          </Card>
          <Card title="Clients" hint={M.clients.length} rule>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>{M.clients.map(c => (
              <div key={c} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 4px', borderBottom:'1px solid var(--line-2)' }}>
                <span className="mono" style={{ fontSize:12 }}>{c}</span></div>
            ))}</div>
          </Card>
        </div>
      )}
    </div>
  );
}
window.ScreenEntry = ScreenEntry; window.ScreenAdmin = ScreenAdmin;
