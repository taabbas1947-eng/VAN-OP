/* VAN Ops v3 — My Actions (Action Center). Exact live actionItems + risk buckets. */
const BADGE = { Acknowledge:'Ack','RM Check':'RM',Receive:'GRN','Open Production':'Produce','Pack QC':'Pack',Ship:'Ship','Lab QC':'Lab',Review:'Review',Approve:'Approve','Approve PR':'PR','Add reason':'Delay',Inspect:'QA',Correct:'Fix' };
const VERB = { Acknowledge:'Acknowledge','RM Check':'RM check',Receive:'Receive','Open Production':'Log output','Pack QC':'Inspect',Ship:'Dispatch','Lab QC':'Open lab',Review:'Review',Approve:'Approve','Approve PR':'Approve','Add reason':'Add reason',Inspect:'Inspect',Correct:'Correct' };
const BADGE_BG = { amber:'var(--amber-50)', teal:'var(--teal-50)', blue:'var(--blue-50)', red:'var(--red-50)', grey:'var(--surface-3)', navy:'var(--navy-50)' };
const BADGE_FG = { amber:'var(--amber-d)', teal:'var(--teal-d)', blue:'var(--blue)', red:'var(--red-d)', grey:'var(--ink-2)', navy:'var(--navy-d)' };

function ScreenActions({ role, openDrawer }) {
  const [risk, setRisk] = useState('all');
  const [roleF, setRoleF] = useState('all');
  const all = window.ACTIONS;
  const visible = role.sees === 'all' ? all : all.filter(a => role.sees.includes(a.role));
  const base = (role.sees==='all' && roleF!=='all') ? visible.filter(a=>a.role===roleF) : visible;
  const counts = { all:base.length, late:base.filter(a=>a.risk==='late').length,
    today:base.filter(a=>a.risk==='today').length, normal:base.filter(a=>a.risk==='normal').length };
  const rows = risk==='all' ? base : base.filter(a => a.risk===risk);
  const groups = [
    ['late','Late · blocked', rows.filter(r=>r.risk==='late')],
    ['today','Today', rows.filter(r=>r.risk==='today')],
    ['normal','Normal', rows.filter(r=>r.risk==='normal')],
  ].filter(g => g[2].length);

  const AC_ROLEORDER = ['Supply Chain','CFO','Production','Lab Rep','AQCM','QCM','QA Inspector','Plant Manager'];
  const roleColor = lbl => (window.ROLES.find(r=>r.role===lbl) || window.ROLES.find(r=>r.sees!=='all'&&r.sees.includes(lbl)) || {}).color || '#7A8699';
  const roleCounts = AC_ROLEORDER.map(lbl => {
    const list = visible.filter(a => a.role===lbl);
    return { role:lbl, color:roleColor(lbl), n:list.length, late:list.filter(a=>a.risk==='late').length };
  }).filter(r => r.n);

  return (
    <div className="well">
      <div className="screen-head">
        <div className="lede">
          {role.sees==='all' ? <>Viewing <b>all roles</b> as COO — {base.length} open items, {counts.late} late, {counts.today} due today.</>
            : <>{base.length} items waiting on <b>{role.role}</b>, oldest {base[0]?.age||'—'}.</>}
        </div>
      </div>

      {/* risk chips */}
      <div className="chips" style={{ marginBottom:14 }}>
        {[['all','All',counts.all,''],['late','Late',counts.late,'late'],['today','Today',counts.today,''],['normal','Normal',counts.normal,'']].map(([k,l,c,cls]) => (
          <button key={k} className={cx('chip', cls, risk===k && 'on')} onClick={()=>setRisk(k)}>{l}<span className="c-ct mono">{c}</span></button>
        ))}
      </div>

      {/* COO role bar (click to filter) */}
      {role.sees==='all' && (
        <div className="card" style={{ marginBottom:16, padding:'4px 5px', display:'flex', gap:3, overflowX:'auto' }}>
          <button onClick={()=>setRoleF('all')} style={{ display:'flex', alignItems:'center', gap:7, padding:'7px 11px', borderRadius:6, whiteSpace:'nowrap', border:'none', background:roleF==='all'?'var(--navy-50)':'transparent', color:roleF==='all'?'var(--navy-d)':'var(--ink-2)', fontWeight:600, fontSize:12 }}>All<span className="mono" style={{ fontSize:10.5, opacity:.8 }}>{visible.length}</span></button>
          {roleCounts.map(r => (
            <button key={r.role} onClick={()=>setRoleF(roleF===r.role?'all':r.role)} style={{ display:'flex', alignItems:'center', gap:7, padding:'7px 11px', borderRadius:6, whiteSpace:'nowrap', border:'none', background:roleF===r.role?'var(--navy-50)':'transparent', cursor:'pointer' }}>
              <span className="avatar" style={{ width:20, height:20, fontSize:8.5, background:r.color }}>{r.role.split(' ').map(w=>w[0]).slice(0,2).join('')}</span>
              <span style={{ fontSize:12, fontWeight:600, color:'var(--ink)' }}>{r.role}</span>
              <span className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{r.n}</span>
              {r.late>0 && <span className="mono" style={{ fontSize:10.5, color:'var(--red)' }}>· {r.late}</span>}
            </button>
          ))}
        </div>
      )}

      {groups.length===0 && <Empty>Nothing waiting on you. The queue is clear.</Empty>}
      {groups.map(([k,label,list]) => (
        <div className="wl-group" key={k}>
          <div className="wl-ghead"><span className="gl">{label}</span><span className="gc mono">{list.length}</span><div className="gline" /></div>
          {list.map((a,i) => {
            const tone = a.tone||'grey';
            return (
              <div key={i} className={cx('wlrow', a.risk)} onClick={()=>openDrawer(a)}>
                <div className="wl-badge" style={{ background:BADGE_BG[tone], color:BADGE_FG[tone] }}>{BADGE[a.type]||a.type}</div>
                <div className="wl-mid">
                  <div className="wl-po mono">{a.po}{a.client && a.client!=='—' ? ' · '+a.client : ''}</div>
                  <div className="wl-ttl">{a.waiting}</div>
                  <div className="wl-meta">{a.role}</div>
                </div>
                <div className="wl-wait">
                  <div className="wl-since mono" style={a.risk==='late'?{ color:'var(--red)' }:null}>{a.age}</div>
                  <div className="wl-rolepill"><Pill tone={tone}>{BADGE[a.type]||a.type}</Pill></div>
                </div>
                <button className="btn btn-pri btn-sm" onClick={(e)=>{e.stopPropagation();openDrawer(a);}}>{VERB[a.type]||a.act}</button>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

function ActionDrawer({ a, onClose, toast }) {
  return (
    <Drawer eyebrow={a.po + (a.client && a.client!=='—' ? ' · '+a.client : '')} title={a.waiting} onClose={onClose}
      footer={<><button className="btn btn-pri" style={{ flex:1, justifyContent:'center' }}
        onClick={()=>{ toast((VERB[a.type]||a.act)+' recorded'); onClose(); }}>{VERB[a.type]||a.act}</button>
        <button className="btn btn-gh" onClick={onClose}>Open full PO</button></>}>
      <div className="kv" style={{ marginBottom:18 }}>
        <dt>Action</dt><dd>{a.type}</dd>
        <dt>Owner role</dt><dd>{a.role}</dd>
        {a.product && a.product!==a.waiting ? <><dt>Product</dt><dd>{a.product}</dd></> : null}
        <dt>Pending</dt><dd className="mono">{a.age}</dd>
        <dt>Risk</dt><dd>{a.risk==='late'?<Pill tone="red">Late</Pill>:a.risk==='today'?<Pill tone="amber">Today</Pill>:<Pill tone="teal">Normal</Pill>}</dd>
      </div>
      <div className="keyebrow" style={{ marginBottom:8, color:'var(--ink-3)', fontFamily:'var(--font-mono)', fontSize:9.5, letterSpacing:'.1em', textTransform:'uppercase' }}>Pipeline position</div>
      <Stepper stage={a.stage} />
    </Drawer>
  );
}
window.ScreenActions = ScreenActions; window.ActionDrawer = ActionDrawer;
