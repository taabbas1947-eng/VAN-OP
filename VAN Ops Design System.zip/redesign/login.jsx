/* VAN Ops v3 — login: full brand splash with logo. */
const Login = ({ onEnter }) => {
  return (
    <div className="login-wrap" style={{ minHeight:'100%', display:'grid', placeItems:'center', position:'relative', overflow:'hidden',
      background:'linear-gradient(135deg,#23406A 0%,#2E4F7C 46%,#1F8478 100%)' }}>
      {/* soft brand glows */}
      <div style={{ position:'absolute', inset:0, background:'radial-gradient(720px 420px at 78% 8%, rgba(79,168,78,.20), transparent 60%), radial-gradient(680px 460px at 12% 92%, rgba(31,156,146,.22), transparent 60%)' }} />
      <div style={{ position:'relative', zIndex:1, width:'100%', maxWidth:404, padding:'0 22px' }}>
        {/* logo tile */}
        <div style={{ display:'flex', justifyContent:'center', marginBottom:22 }}>
          <div style={{ background:'#fff', borderRadius:14, padding:'16px 22px', boxShadow:'0 18px 48px rgba(10,22,42,.32)' }}>
            <img src="assets/van-logo.jpg" alt="VAN" style={{ height:46, display:'block' }} />
          </div>
        </div>
        <div style={{ textAlign:'center', marginBottom:22 }}>
          <div className="mono" style={{ fontSize:10, letterSpacing:'.22em', color:'#9FE3D6', textTransform:'uppercase' }}>Order → Shipment Control Tower</div>
          <h1 style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:30, letterSpacing:'-.02em', color:'#fff', margin:'10px 0 0' }}>O2S</h1>
        </div>

        {/* sign-in card */}
        <div style={{ background:'rgba(255,255,255,.98)', borderRadius:14, padding:'22px 22px 20px', boxShadow:'0 20px 56px rgba(10,22,42,.34)' }}>
          <div className="field"><label>Username</label><input className="inp" defaultValue="tahir" /></div>
          <div className="field" style={{ marginBottom:16 }}><label>Password</label><input className="inp" type="password" defaultValue="vanops" /></div>
          <button className="btn btn-pri" style={{ width:'100%', justifyContent:'center', padding:'10px' }} onClick={()=>onEnter()}>Sign in <Ic name="arrow" size={15} /></button>
          <div style={{ display:'flex', alignItems:'center', gap:10, margin:'18px 0 14px' }}>
            <div style={{ flex:1, height:1, background:'var(--line)' }} />
            <span className="mono" style={{ fontSize:9.5, color:'var(--ink-3)', letterSpacing:'.12em' }}>OR ENTER AS</span>
            <div style={{ flex:1, height:1, background:'var(--line)' }} />
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:7 }}>
            {window.ROLES.map(r => (
              <button key={r.id} className="btn btn-gh btn-sm" style={{ justifyContent:'flex-start', gap:8 }} onClick={()=>onEnter(r)}>
                <span className="avatar" style={{ width:20, height:20, fontSize:8.5, background:r.color }}>{r.name.split(' ').map(w=>w[0]).slice(0,2).join('')}</span>
                {r.role}</button>
            ))}
          </div>
        </div>
        <div className="mono" style={{ textAlign:'center', fontSize:10, color:'rgba(255,255,255,.6)', marginTop:18, letterSpacing:'.04em' }}>VITAL AGRI NUTRIENTS · INTERNAL OPERATIONS</div>
      </div>
    </div>
  );
};
window.Login = Login;
