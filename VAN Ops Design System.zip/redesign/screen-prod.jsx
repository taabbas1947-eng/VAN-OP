/* VAN Ops v3 — Production. Mirrors live batchStage lanes + reconcile pools. */
const LANE_META = {
  'In production':           { dot:'d-navy',  desc:'producing the planned quantity' },
  'Awaiting Lab QC':         { dot:'d-amber', desc:'produced — COA pending' },
  'Ready to pack':           { dot:'d-green', desc:'QC-cleared, awaiting packing' },
  'Reconcile':               { dot:'d-red',   desc:'finished — route the remainder' },
  'Packed — ready to close': { dot:'d-grey',  desc:'fully packed' },
};
const STAGE_OF_LANE = { 'In production':'producing','Awaiting Lab QC':'qc','Ready to pack':'pack','Reconcile':'recon','Packed — ready to close':'done' };

function ScreenProduction({ openBatch, toast }) {
  const [chip, setChip] = useState('all');
  const [view, setView] = useState(() => localStorage.getItem('vanops-prodview') || 'lanes');
  useEffect(() => { localStorage.setItem('vanops-prodview', view); }, [view]);
  const B = window.BATCHES, LANES = window.LANES;
  const n = st => B.filter(b => b.stage===st).length;
  const readyKg = B.filter(b=>b.stage==='pack').reduce((a,b)=>a+b.ready,0);

  const kpis = [
    { eyebrow:'In production', val:n('producing'), unit:' batches', foot:'producing now' },
    { eyebrow:'Awaiting Lab QC', val:n('qc'), unit:' lots', foot:'COA pending' },
    { eyebrow:'Ready to pack', val:n('pack'), unit:' batches', foot:fmt(readyKg)+' KG cleared' },
    { eyebrow:'Reconcile', val:n('recon'), unit:' batches', foot:'remainder to route' },
  ];

  const lanesToShow = chip==='all' ? LANES : LANES.filter(l => STAGE_OF_LANE[l]===chip);

  return (
    <div className="well">
      <div className="grid g-kpi" style={{ marginBottom:16 }}>{kpis.map(k => <Kpi key={k.eyebrow} {...k} />)}</div>

      {/* reconcile / by-product pools */}
      {window.POOLS.length>0 && <>
        <SectionTitle count="off the main board">Reconcile · by-product pools</SectionTitle>
        <div className="grid g-3" style={{ marginBottom:6 }}>
          {window.POOLS.map(p => (
            <div key={p.product+p.kind} className="card" style={{ borderLeft:'3px solid var(--amber)' }}>
              <div className="card-pad">
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:7 }}>
                  <Pill tone={p.kind==='Divert'?'teal':p.kind==='Rework'?'red':'amber'}>{p.kind}</Pill>
                  <span className="mono" style={{ fontSize:11, color:'var(--ink-3)', marginLeft:'auto' }}>{fmt(p.kg)} KG</span>
                </div>
                <div style={{ fontWeight:600, fontSize:13.5 }}>{p.product}</div>
                <div style={{ fontSize:11.5, color:'var(--ink-2)', margin:'3px 0 11px' }}>{p.note}</div>
                <button className="btn btn-gh btn-sm" onClick={()=>toast(p.action+' — opening')}>{p.action} <Ic name="arrow" size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </>}

      {/* toolbar: chips + view toggle */}
      <div style={{ display:'flex', alignItems:'center', gap:12, margin:'20px 0 14px', flexWrap:'wrap' }}>
        <div className="chips">
          {[['all','All',B.length],['producing','In production',n('producing')],['qc','Awaiting QC',n('qc')],['pack','Ready to pack',n('pack')],['recon','Reconcile',n('recon')],['done','Packed',n('done')]].map(([k,l,c]) => (
            <button key={k} className={cx('chip', chip===k && 'on')} onClick={()=>setChip(k)}>{l}<span className="c-ct mono">{c}</span></button>
          ))}
        </div>
        <div className="tb-spacer" style={{ flex:1 }} />
        <div className="viewwrap">
          <span className="vlbl">View</span>
          <div className="seg">
            {[['lanes','rows','Lanes'],['board','grid','Board'],['table','list','Table']].map(([k,ic,l]) => (
              <button key={k} className={cx(view===k && 'on')} onClick={()=>setView(k)}><Ic name={ic} size={13} /> {l}</button>
            ))}
          </div>
        </div>
      </div>

      {/* LANES (stacked) */}
      {view==='lanes' && lanesToShow.map(lane => {
        const list = B.filter(b => b.lane===lane);
        const meta = LANE_META[lane];
        return (
          <div key={lane} style={{ marginBottom:18 }}>
            <div style={{ display:'flex', alignItems:'center', gap:9, marginBottom:10 }}>
              <span className={cx('sdot', meta.dot)} />
              <span style={{ fontFamily:'var(--font-display)', fontWeight:700, fontSize:13 }}>{lane}</span>
              <span className="mono" style={{ fontSize:10.5, fontWeight:600, background:'var(--surface-3)', color:'var(--ink-2)', borderRadius:999, padding:'1px 8px' }}>{list.length}</span>
              <span style={{ fontSize:11.5, color:'var(--ink-3)' }}>{meta.desc}</span>
            </div>
            {list.length===0
              ? <div style={{ fontSize:12, color:'var(--ink-3)', padding:'10px 13px', background:'var(--surface-2)', border:'1px dashed var(--line)', borderRadius:8 }}>None right now.</div>
              : <div className="grid" style={{ gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:10 }}>
                  {list.map(b => <BatchCard key={b.batch} b={b} onClick={()=>openBatch(b)} />)}
                </div>}
          </div>
        );
      })}

      {/* BOARD (kanban columns) */}
      {view==='board' && (
        <div className="pboard">
          {lanesToShow.map(lane => {
            const list = B.filter(b => b.lane===lane);
            const meta = LANE_META[lane];
            return (
              <div className="lane" key={lane}>
                <div className="lane-h"><span className={cx('sdot', meta.dot)} /><span className="ln">{lane}</span><span className="lc mono">{list.length}</span></div>
                <div className="lane-body">
                  {list.map(b => <BatchCard key={b.batch} b={b} onClick={()=>openBatch(b)} />)}
                  {list.length===0 && <div style={{ fontSize:11, color:'var(--ink-3)', padding:'6px 4px' }}>None right now.</div>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TABLE (dense) */}
      {view==='table' && (
        <div className="card" style={{ overflow:'hidden' }}><div className="tbl-wrap"><table className="tbl">
          <thead><tr><th>Batch</th><th>Product</th><th>PO</th><th>Stage</th>
            <th className="r">Produced</th><th className="r">Cleared</th><th className="r">Ready</th><th className="r">Remainder</th></tr></thead>
          <tbody>{B.filter(b => chip==='all'||b.stage===chip).map(b => (
            <tr key={b.batch} className="clk" onClick={()=>openBatch(b)}>
              <td className="mono lead">{b.batch}</td><td>{b.product}</td><td className="mono">{b.po}</td>
              <td><Pill tone={b.stage==='qc'?'amber':b.stage==='pack'?'green':b.stage==='recon'?'red':b.stage==='producing'?'navy':'grey'}>{b.lane}</Pill></td>
              <td className="r mono">{fmt(b.produced)}/{fmt(b.plan)}</td><td className="r mono">{fmt(b.cleared)}</td>
              <td className="r mono">{fmt(b.ready)}</td><td className="r mono">{fmt(b.rem)}</td></tr>
          ))}</tbody>
        </table></div></div>
      )}
    </div>
  );
}

function BatchCard({ b, onClick }) {
  const foot = b.stage==='producing' ? fmt(b.plan-b.produced)+' KG to go'
    : b.stage==='qc' ? fmt(b.waiting)+' KG waiting QC'
    : b.stage==='pack' ? fmt(b.ready)+' KG ready'
    : b.stage==='recon' ? fmt(b.rem)+' KG remainder'
    : 'packed';
  const tone = b.stage==='qc'?'amber':b.stage==='pack'?'green':b.stage==='recon'?'red':b.done<100?'amber':'';
  return (
    <div className="bcard" onClick={onClick} style={{ borderLeft: b.stage==='recon'?'3px solid var(--red)':'' }}>
      <div className="bc-h"><span className="bc-b mono">{b.batch}</span>
        <span className="tag">{b.kind==='po'?'PO':'BULK'}</span></div>
      <div className="bc-p">{b.product}</div>
      <Bar pct={b.done} tone={tone} />
      <div className="bc-f"><span className="mono">{fmt(b.produced)}/{fmt(b.plan)} KG</span><span>{foot}</span></div>
    </div>
  );
}

function BatchDrawer({ b, onClose, toast }) {
  const act = b.stage==='producing'?'Log shift output':b.stage==='pack'?'Pack cleared stock':b.stage==='qc'?'Open in Lab QC':b.stage==='recon'?'Reconcile remainder':'Close batch';
  return (
    <Drawer eyebrow={'Batch '+b.batch+(b.po!=='—'?' · PO '+b.po:'')} title={b.product} onClose={onClose}
      footer={<button className="btn btn-pri" style={{ flex:1, justifyContent:'center' }} onClick={()=>{toast(act+' recorded');onClose();}}>{act}</button>}>
      <div style={{ display:'flex', gap:8, marginBottom:16 }}>
        <Pill tone={b.stage==='qc'?'amber':b.stage==='pack'?'green':b.stage==='recon'?'red':b.stage==='producing'?'navy':'grey'}>{b.lane}</Pill>
        <Pill tone="grey">{b.kind==='po'?'PO batch':'Bulk → stock'}</Pill>
      </div>
      <div style={{ marginBottom:16 }}>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:6 }}>
          <span style={{ color:'var(--ink-2)' }}>Produced</span><span className="mono" style={{ fontWeight:600 }}>{fmt(b.produced)} / {fmt(b.plan)} KG</span></div>
        <Bar pct={b.done} tone={b.done<100?'amber':''} />
      </div>
      <div className="kv" style={{ marginBottom:18 }}>
        <dt>Stage</dt><dd>{b.lane}</dd>
        <dt>Owner</dt><dd>{b.owner}</dd>
        <dt>Planned</dt><dd className="mono">{fmt(b.plan)} KG</dd>
        <dt>Produced</dt><dd className="mono">{fmt(b.produced)} KG</dd>
        <dt>QC-cleared</dt><dd className="mono">{fmt(b.cleared)} KG</dd>
        <dt>Packed</dt><dd className="mono">{fmt(b.packed)} KG</dd>
        <dt>Waiting QC</dt><dd className="mono">{fmt(b.waiting)} KG</dd>
        <dt>Ready to pack</dt><dd className="mono">{fmt(b.ready)} KG</dd>
        <dt>Remainder</dt><dd className="mono">{fmt(b.rem)} KG</dd>
      </div>
      <div className="banner navy"><span className="ic"><Ic name="info" size={16} /></span>
        <span>Cleared lots are packable while the batch keeps producing the remainder. Leftover after packing routes to reconcile (loss / by-product / divert / rework).</span></div>
    </Drawer>
  );
}
window.ScreenProduction = ScreenProduction; window.BatchDrawer = BatchDrawer;
