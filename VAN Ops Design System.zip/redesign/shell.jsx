/* VAN Ops v3 — shell: collapsible white rail + topbar (density + collapse). */
const Rail = ({ screen, setScreen, role, setRole, counts, onSearch, collapsed, setCollapsed }) => {
  const [menu, setMenu] = useState(false);
  const initials = role.name.split(' ').map(w => w[0]).slice(0,2).join('');
  return (
    <nav className="rail">
      <button className="rail-toggle" onClick={() => setCollapsed(c => !c)} title={collapsed ? 'Expand' : 'Collapse'}>
        <Ic name="chevr" size={14} />
      </button>
      <div className="rail-brand">
        <img className="brand-logo" src="assets/van-logo.jpg" alt="VAN" />
        <img className="brand-mark" src="assets/van-mark.jpg" alt="VAN" />
      </div>
      <button className="rail-search" onClick={onSearch} title="Search">
        <Ic name="search" size={14} /> <span className="stxt">Search PO or screen</span> <span className="kbd">⌘K</span>
      </button>
      <div className="rail-nav">
        {window.NAV_GROUPS.map(g => (
          <div className="navgrp" key={g.label}>
            <div className="navgrp-lbl">{g.label}</div>
            {g.items.map(it => {
              const c = counts[it.id];
              return (
                <button key={it.id} className={cx('navitem', screen===it.id && 'on')} onClick={() => setScreen(it.id)} title={it.name}>
                  <span className="ic"><Ic name={it.icon} size={17} /></span><span className="ntxt">{it.name}</span>
                  {c ? <span className={cx('ct', it.id==='approvals' && counts.lateActions && 'hot')}>{c}</span> : null}
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <div className="rail-role">
        {menu && (
          <div className="rolemenu">
            <div className="rolemenu-h">View as role</div>
            {window.ROLES.map(r => (
              <button key={r.id} className={cx('roleopt', r.id===role.id && 'on')} onClick={() => { setRole(r); setMenu(false); }}>
                <span className="avatar" style={{ width:22, height:22, fontSize:9, background:r.color }}>{r.name.split(' ').map(w=>w[0]).slice(0,2).join('')}</span>
                <span>{r.role}</span>
                {r.id===role.id && <span className="tick"><Ic name="check" size={14} /></span>}
              </button>
            ))}
          </div>
        )}
        <button className="rolebtn" onClick={() => setMenu(m => !m)} title={role.role}>
          <span className="avatar" style={{ background: role.color }}>{initials}</span>
          <span className="who"><div className="nm">{role.name}</div><div className="rl">{role.role}</div></span>
          <span className="chev"><Ic name="chev" size={15} /></span>
        </button>
      </div>
    </nav>
  );
};

const Topbar = ({ meta, density, setDensity, onBurger }) => (
  <header className="topbar">
    <button className="tb-burger" onClick={onBurger}><Ic name="menu" size={18} /></button>
    <div className="tb-title">
      <div className="tb-crumb">{meta.crumb} · {meta.sub}</div>
      <h1>{meta.title}</h1>
    </div>
    <div className="tb-spacer" />
    <div className="tb-actions">
      <div className="dens" title="Layout density">
        <button className={cx(density==='compact' && 'on')} onClick={()=>setDensity('compact')}><Ic name="list" size={13} /> <span className="dlbl">Compact</span></button>
        <button className={cx(density==='comfortable' && 'on')} onClick={()=>setDensity('comfortable')}><Ic name="rows" size={13} /> <span className="dlbl">Comfortable</span></button>
      </div>
      <button className="iconbtn"><span className="dot" /><Ic name="bell" size={17} /></button>
    </div>
  </header>
);

window.Rail = Rail; window.Topbar = Topbar;
