/* VAN Ops v2 — Reports and Sales & Budget. */
function ScreenReports() {
  const maxFlow = Math.max(...window.STAGE_FLOW.map(s=>s.n));
  const exceptions = window.ORDERS.filter(o=>o.risk==='late'||o.risk==='rm');
  return (
    <div className="well">
      <div className="grid g-3" style={{ marginBottom:18 }}>{window.REPORT_KPIS.map(k => <Kpi key={k.eyebrow} {...k} />)}</div>

      <div className="grid g-main">
        <Card title="Pipeline distribution" hint="orders by stage" rule>
          <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
            {window.STAGE_FLOW.map((s,i) => (
              <div key={s.stage} style={{ display:'flex', alignItems:'center', gap:12 }}>
                <div style={{ width:104, fontSize:11.5, color:'var(--ink-2)', textAlign:'right' }}>{s.stage}</div>
                <div style={{ flex:1, height:24, background:'var(--surface-2)', borderRadius:6, overflow:'hidden' }}>
                  <div style={{ width:(s.n/maxFlow*100)+'%', height:'100%', borderRadius:6,
                    background:'var(--navy)', display:'flex', alignItems:'center', justifyContent:'flex-end', paddingRight:8 }}>
                    <span className="mono" style={{ fontSize:11, color:'#fff', fontWeight:600 }}>{s.n}</span></div>
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card title="Throughput" hint="KG index · 12 mo" rule>
          <div className="minibars">{window.PROD_TREND.map((v,i) => (
            <div key={i} className={cx('mb', i<2 && 'dim')} style={{ height:v+'%' }} />
          ))}</div>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:10, color:'var(--ink-3)', marginTop:8 }} className="mono">
            <span>JUL</span><span>JUN</span></div>
          <div style={{ marginTop:14, paddingTop:14, borderTop:'1px solid var(--line-2)', display:'flex', justifyContent:'space-between' }}>
            <div><div className="keyebrow" style={{ fontFamily:'var(--font-mono)', fontSize:9, color:'var(--ink-3)', letterSpacing:'.1em' }}>JUN</div>
              <div className="mono" style={{ fontSize:20, fontWeight:600 }}>612k <span style={{ fontSize:11, color:'var(--ink-3)' }}>KG</span></div></div>
            <div style={{ textAlign:'right' }}><div className="keyebrow" style={{ fontFamily:'var(--font-mono)', fontSize:9, color:'var(--ink-3)', letterSpacing:'.1em' }}>VS MAY</div>
              <div className="mono" style={{ fontSize:20, fontWeight:600, color:'var(--teal-d)' }}>+5.5%</div></div>
          </div>
        </Card>
      </div>

      <SectionTitle count={exceptions.length+' open'}>Exceptions · needs attention</SectionTitle>
      <div className="card" pad={false}><div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>PO</th><th>Customer</th><th>Product</th><th>Stage</th><th>Owner</th><th className="r">Remaining</th><th>Age</th><th>Risk</th></tr></thead>
        <tbody>{exceptions.map(o => (
          <tr key={o.po} className={o.risk==='late'?'row-risk':'row-warn'}>
            <td className="mono lead">{o.po}</td><td>{o.client}</td><td>{o.product}</td>
            <td><Pill tone="grey">{window.STAGES[o.stage-1]}</Pill></td><td style={{ color:'var(--ink-2)' }}>{o.owner}</td>
            <td className="r mono">{fmt(o.remaining)} {o.unit}</td><td className="mono">{o.age}</td><td><RiskPill risk={o.risk} /></td></tr>
        ))}</tbody>
      </table></div></div>
    </div>
  );
}

function ScreenBudget() {
  const C = window.CHANNELS_BUDGET;
  const totB = C.reduce((a,c)=>a+c.budget,0), totA = C.reduce((a,c)=>a+c.actual,0);
  const top = [...C].sort((a,b)=>b.actual-a.actual)[0]||{channel:'—',actual:0};
  const over = C.filter(c=>c.actual>c.budget);
  const maxM = Math.max(...window.BUDGET_MONTHS.flatMap(m=>[m.b,m.a]));
  return (
    <div className="well">
      <div className="grid g-kpi" style={{ marginBottom:18 }}>
        <QCard icon="budget" q="Are we hitting budget?" a={Math.round(totA/totB*100)+'%'} sub={'₨'+totA.toFixed(1)+' cr of ₨'+totB.toFixed(1)+' cr target'} accent={totA>=totB?'var(--green)':'var(--amber)'} />
        <QCard icon="trend" q="Sold this month?" a={'₨'+totA.toFixed(1)} u="cr" sub={'Jun · '+((totA/totB-1)*100).toFixed(0)+'% vs budget'} accent="var(--navy)" />
        <QCard icon="user" q="Top client?" a={top.channel.length>13?top.channel.slice(0,12)+'…':top.channel} sub={'₨'+top.actual.toFixed(1)+' cr · '+Math.round(top.actual/totA*100)+'% of sales'} />
        <QCard icon="alert" q="Who's behind budget?" a={C.length-over.length} u="clients" sub={C.filter(c=>c.actual<c.budget).slice(0,2).map(c=>c.channel.split(' ')[0]).join(' · ')||'none'} accent={C.length-over.length?'var(--amber)':'var(--green)'} />
      </div>

      <div className="grid g-main">
        <Card title="Sales vs budget by channel" hint="PKR crore · Jun" rule>
          <table className="tbl" style={{ marginTop:-4 }}>
            <thead><tr><th>Client</th><th>KAM</th><th className="r">Budget</th><th className="r">Actual</th><th style={{ width:150 }}>Attainment</th></tr></thead>
            <tbody>{C.map(c => {
              const pct = Math.round(c.actual/c.budget*100), over = c.actual>=c.budget;
              return (<tr key={c.channel}><td className="lead">{c.channel}</td><td style={{ color:'var(--ink-2)' }}>{c.kam}</td>
                <td className="r mono">₨{c.budget.toFixed(1)}</td><td className="r mono">₨{c.actual.toFixed(1)}</td>
                <td><div style={{ display:'flex', alignItems:'center', gap:8 }}>
                  <div style={{ flex:1 }}><Bar pct={Math.min(100,pct)} tone={over?'':'amber'} /></div>
                  <span className="mono" style={{ fontSize:11, width:34, textAlign:'right', color:over?'var(--teal-d)':'var(--amber)' }}>{pct}%</span></div></td></tr>);
            })}</tbody>
          </table>
        </Card>
        <Card title="Monthly trend" hint="budget vs actual" rule>
          <div style={{ display:'flex', alignItems:'flex-end', gap:10, height:150, padding:'8px 0' }}>
            {window.BUDGET_MONTHS.map(m => (
              <div key={m.m} style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', gap:6 }}>
                <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:120, width:'100%', justifyContent:'center' }}>
                  <div title="budget" style={{ width:'34%', height:(m.b/maxM*100)+'%', background:'var(--line)', borderRadius:'3px 3px 0 0' }} />
                  <div title="actual" style={{ width:'34%', height:(m.a/maxM*100)+'%', background:'var(--navy)', borderRadius:'3px 3px 0 0' }} />
                </div>
                <span className="mono" style={{ fontSize:10, color:'var(--ink-3)' }}>{m.m}</span>
              </div>
            ))}
          </div>
          <div style={{ display:'flex', gap:16, marginTop:6, fontSize:11, color:'var(--ink-2)' }}>
            <span style={{ display:'flex', alignItems:'center', gap:6 }}><span style={{ width:10, height:10, borderRadius:3, background:'var(--line)' }} /> Budget</span>
            <span style={{ display:'flex', alignItems:'center', gap:6 }}><span style={{ width:10, height:10, borderRadius:3, background:'var(--navy)' }} /> Actual</span>
          </div>
        </Card>
      </div>
    </div>
  );
}
window.ScreenReports = ScreenReports; window.ScreenBudget = ScreenBudget;
