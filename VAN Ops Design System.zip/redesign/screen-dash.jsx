/* VAN Ops v3 — Dashboards. Role-aware: each answers the questions that role needs.
   Replaces the old generic Reports. Pure compute over the live-mirrored data. */
const QCard = ({ icon, q, a, u, sub, accent }) => (
  <div className="qcard" style={accent?{ borderLeft:'3px solid '+accent }:null}>
    <div className="q"><span className="ic"><Ic name={icon} size={14} /></span>{q}</div>
    <div className="a">{a}{u && <span className="u"> {u}</span>}</div>
    {sub && <div className="sub">{sub}</div>}
  </div>
);

const DASH_VIEWS = [
  { id:'overview', name:'Overview', icon:'dash' },
  { id:'prod',     name:'Production', icon:'prod' },
  { id:'qc',       name:'QC & QA', icon:'qc' },
  { id:'plant',    name:'Plant Manager', icon:'admin' },
  { id:'supply',   name:'Supply Chain', icon:'truck' },
];
const ROLE_DASH = { prod:'prod', lab:'qc', qa:'qc', pm:'plant', sc:'supply', coo:'overview', kam:'overview', cfo:'overview' };

function ScreenDashboard({ role }) {
  const [view, setView] = useState(() => ROLE_DASH[role.id] || 'overview');
  useEffect(() => { setView(ROLE_DASH[role.id] || 'overview'); }, [role.id]);

  const O = window.ORDERS, B = window.BATCHES;
  const openO = O.filter(o=>o.bucket!=='Delivered');
  const overdue = O.filter(o=>o.risk==='late');
  const rmBlocked = O.filter(o=>o.bucket==='RM Check');
  const atRisk = O.filter(o=>o.bucket!=='Delivered'&&(o.risk==='late'||o.bucket==='RM Check'));
  const nb = st => B.filter(b=>b.stage===st);
  const readyKg = nb('pack').reduce((a,b)=>a+b.ready,0);
  const poolKg = window.POOLS.reduce((a,p)=>a+p.kg,0);
  const dispKg = window.SHIPMENTS.reduce((a,s)=>a+s.qty,0);
  const onTime = Math.round((1 - overdue.length/Math.max(1,openO.length))*100);

  const exTable = (list) => (
    <Card title="Exceptions · needs attention" hint={list.length+' open'} pad={false}>
      <div className="tbl-wrap"><table className="tbl">
        <thead><tr><th>PO</th><th>Customer</th><th>Stage</th><th>Owner</th><th className="r">Remaining</th><th>Risk</th></tr></thead>
        <tbody>{list.map(o => (
          <tr key={o.po} className={o.risk==='late'?'row-risk':'row-warn'}>
            <td className="mono lead">{o.po}</td><td>{o.client}</td>
            <td><StageChip stage={window.STAGES[o.stage-1]} /></td><td style={{ color:'var(--ink-2)' }}>{o.owner}</td>
            <td className="r mono">{fmt(o.remaining)} {o.unit}</td><td><RiskPill risk={o.risk} /></td></tr>
        ))}</tbody>
      </table></div>
    </Card>
  );

  const pipeline = (
    <Card title="Where orders are sitting" hint="by stage">
      <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
        {window.STAGE_FLOW.map((s,i) => {
          const max = Math.max(...window.STAGE_FLOW.map(x=>x.n))||1;
          return (
            <div key={s.stage} style={{ display:'flex', alignItems:'center', gap:10 }}>
              <div style={{ width:108, fontSize:11, color:'var(--ink-2)', textAlign:'right' }}>{s.stage}</div>
              <div style={{ flex:1, height:20, background:'var(--surface-2)', borderRadius:5, overflow:'hidden' }}>
                <div style={{ width:(s.n/max*100)+'%', height:'100%', background:stageColor(i), borderRadius:5, display:'flex', alignItems:'center', justifyContent:'flex-end', paddingRight:7, minWidth:22 }}>
                  <span className="mono" style={{ fontSize:10.5, color:'#fff', fontWeight:600 }}>{s.n}</span></div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );

  const queueCard = (title, rows, cols) => (
    <Card title={title} hint={rows.length+''} pad={false}>
      <div className="tbl-wrap"><table className="tbl">
        <thead><tr>{cols.map(c=><th key={c[0]} className={c[2]?'r':''}>{c[0]}</th>)}</tr></thead>
        <tbody>{rows.map((r,i)=>(<tr key={i}>{cols.map(c=><td key={c[0]} className={cx(c[2]&&'r', c[3]&&'mono', c[3]&&'lead')}>{c[1](r)}</td>)}</tr>))}</tbody>
      </table></div>
    </Card>
  );

  return (
    <div className="well">
      {/* dashboard selector */}
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16, flexWrap:'wrap' }}>
        <div className="seg">
          {DASH_VIEWS.map(v => (
            <button key={v.id} className={cx(view===v.id && 'on')} onClick={()=>setView(v.id)}><Ic name={v.icon} size={13} /> {v.name}</button>
          ))}
        </div>
        <span style={{ fontSize:11.5, color:'var(--ink-3)' }}>
          {view===ROLE_DASH[role.id] ? <>Tuned for <b style={{ color:'var(--ink-2)' }}>{role.role}</b></> : 'Manager view'}
        </span>
      </div>

      {view==='overview' && <>
        <div className="grid g-kpi" style={{ marginBottom:14 }}>
          <QCard icon="tracker" q="Are we on track?" a={onTime+'%'} sub={onTime+'% of open POs on time'} accent="var(--green)" />
          <QCard icon="alert" q="What's at risk?" a={atRisk.length} u="POs" sub={overdue.length+' overdue · '+rmBlocked.length+' RM-blocked'} accent="var(--red)" />
          <QCard icon="cube" q="How many open orders?" a={openO.length} u="POs" sub={'of '+O.length+' total'} />
          <QCard icon="truck" q="Shipped recently?" a={(dispKg/1000).toFixed(0)+'k'} u="KG" sub={window.SHIPMENTS.length+' shipments'} accent="var(--navy)" />
        </div>
        <div className="grid g-main">{exTable(atRisk)}{pipeline}</div>
      </>}

      {view==='prod' && <>
        <div className="grid g-kpi" style={{ marginBottom:14 }}>
          <QCard icon="prod" q="What's producing now?" a={nb('producing').length} u="batches" sub={fmt(nb('producing').reduce((a,b)=>a+(b.plan-b.produced),0))+' KG to go'} accent="var(--navy)" />
          <QCard icon="box" q="Cleared to pack?" a={nb('pack').length} u="batches" sub={fmt(readyKg)+' KG ready'} accent="var(--green)" />
          <QCard icon="flask" q="Waiting on lab QC?" a={nb('qc').length} u="lots" sub="COA pending" accent="var(--amber)" />
          <QCard icon="layers" q="Anything to reconcile?" a={window.POOLS.length} u="pools" sub={fmt(poolKg)+' KG pooled'} accent={window.POOLS.length?'var(--amber)':null} />
        </div>
        <div className="grid g-main">
          {queueCard('In production now', nb('producing'), [['Batch',b=>b.batch,0,1],['Product',b=>b.product],['PO',b=>b.po],['Produced',b=>fmt(b.produced)+'/'+fmt(b.plan),1],['To go',b=>fmt(b.plan-b.produced),1]])}
          <Card title="Ready-to-pack stock" hint={nb('pack').length+' batches'}>
            <div style={{ display:'flex', flexDirection:'column', gap:9 }}>
              {nb('pack').slice(0,7).map(b => (
                <div key={b.batch} style={{ display:'flex', alignItems:'center', gap:10, borderLeft:'3px solid var(--green)', paddingLeft:10 }}>
                  <div style={{ flex:1, minWidth:0 }}><div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{b.batch} · {b.po}</div>
                    <div style={{ fontWeight:600, fontSize:12.5 }}>{b.product}</div></div>
                  <span className="mono" style={{ fontSize:12, fontWeight:600, color:'var(--green-d)' }}>{fmt(b.ready)} KG</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </>}

      {view==='qc' && <>
        <div className="grid g-kpi" style={{ marginBottom:14 }}>
          <QCard icon="flask" q="Lots waiting for lab QC?" a={window.LAB_QUEUE.length} u="lots" sub="analysis → COA" accent="var(--amber)" />
          <QCard icon="reports" q="COAs to review?" a={window.COA_QUEUE.length} u="COAs" sub="AQCM → QCM" accent="var(--blue)" />
          <QCard icon="qc" q="Pre-ship inspections?" a={window.INSPECT_QUEUE.length} u="lots" sub="before dispatch" accent="var(--green)" />
          <QCard icon="check" q="Pass rate" a="100%" sub={window.INSPECT_DONE.length+' recent · 0 holds'} accent="var(--green)" />
        </div>
        <div className="grid g-main">
          {queueCard('Lab QC queue', window.LAB_QUEUE, [['Lot',l=>l.lot,0,1],['Product',l=>l.product],['PO',l=>l.po],['Qty',l=>fmt(l.kg)+' KG',1],['State',l=><Pill tone={l.tone}>{l.stage}</Pill>]])}
          {queueCard('Pre-shipment inspections', window.INSPECT_QUEUE, [['PO',p=>p.po,0,1],['Customer',p=>p.client],['Packs',p=>p.packs],['Age',p=>p.age,1]])}
        </div>
      </>}

      {view==='plant' && <>
        <div className="grid g-kpi" style={{ marginBottom:14 }}>
          <QCard icon="trend" q="Throughput this month?" a={(dispKg/1000).toFixed(0)+'k'} u="KG" sub="dispatched · Jun" accent="var(--navy)" />
          <QCard icon="alert" q="Delays / overdue?" a={overdue.length} u="POs" sub="committed date passed" accent={overdue.length?'var(--red)':null} />
          <QCard icon="layers" q="Reconcile remainder?" a={fmt(poolKg)} u="KG" sub={window.POOLS.length+' pools open'} accent="var(--amber)" />
          <QCard icon="prod" q="Lines running?" a={nb('producing').length} u="batches" sub="in production" />
        </div>
        <div className="grid g-main">
          {exTable(atRisk)}
          <Card title="Reconcile · by-product pools" hint={window.POOLS.length+''}>
            {window.POOLS.length===0 ? <Empty>No pools to route right now.</Empty> :
            <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
              {window.POOLS.map(p => (
                <div key={p.product} style={{ borderLeft:'3px solid var(--amber)', paddingLeft:11 }}>
                  <div style={{ display:'flex', justifyContent:'space-between' }}>
                    <span style={{ fontWeight:600, fontSize:12.5 }}>{p.product}</span>
                    <span className="mono" style={{ fontSize:12, color:'var(--amber-d)' }}>{fmt(p.kg)} KG</span></div>
                  <div style={{ fontSize:11, color:'var(--ink-2)', marginTop:2 }}>{p.kind} · {p.note}</div>
                </div>
              ))}
            </div>}
          </Card>
        </div>
      </>}

      {view==='supply' && <>
        <div className="grid g-kpi" style={{ marginBottom:14 }}>
          <QCard icon="alert" q="RM-blocked POs?" a={rmBlocked.length} u="POs" sub="awaiting material" accent={rmBlocked.length?'var(--amber)':null} />
          <QCard icon="box" q="Ready to dispatch?" a={window.SHIP_READY.length} u="POs" sub="cleared & packed" accent="var(--green)" />
          <QCard icon="truck" q="In transit?" a={window.SHIPMENTS.filter(s=>s.status==='In transit').length} u="trucks" sub="on the road" accent="var(--navy)" />
          <QCard icon="cube" q="Open orders?" a={openO.length} u="POs" sub={atRisk.length+' need attention'} />
        </div>
        <div className="grid g-main">
          {queueCard('RM-blocked — confirm materials', rmBlocked, [['PO',o=>o.po,0,1],['Customer',o=>o.client],['Product',o=>o.product],['Remaining',o=>fmt(o.remaining)+' '+o.unit,1]])}
          <Card title="Ready to dispatch">
            <div style={{ display:'flex', flexDirection:'column', gap:11 }}>
              {window.SHIP_READY.map(r => (
                <div key={r.po} style={{ borderLeft:'3px solid '+(r.tone==='amber'?'var(--amber)':'var(--green)'), paddingLeft:11 }}>
                  <div className="mono" style={{ fontSize:10.5, color:'var(--ink-3)' }}>{r.po}</div>
                  <div style={{ fontWeight:600, fontSize:12.5 }}>{r.client}</div>
                  <div style={{ fontSize:11, color:'var(--ink-2)' }}>{fmt(r.qty)} KG · {r.note}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </>}
    </div>
  );
}
window.ScreenDashboard = ScreenDashboard; window.QCard = QCard;
